package com.elx.common;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

public class EnvSpecificConfigValues {

	Object[][] sheetData = null;
	Hashtable<String, String> table = null;
	FileOutputStream fileOut;

	public EnvSpecificConfigValues() {
	}

	public void createPropertyFile(String envname) throws IOException {
		try {

			ExcelManager xls1 = new ExcelManager(System.getProperty("user.dir")
					+ "\\environment\\" + "Environments.xlsx");

			table = xls1.getEnvData1(envname, "ENVIRONMENTS");
			Properties properties = new Properties();
			Enumeration e = table.keys();

			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				System.out.println(key + " : " + table.get(key));
				properties.setProperty(key, table.get(key));

			}

			File file = new File(System.getProperty("user.dir")
					+ "\\environment\\" + "env.properties");
			fileOut = new FileOutputStream(file);
			properties.store(fileOut, envname + " specific env details");
			fileOut.close();
			System.out.println("Created Env Properties file successfully at "
					+ System.getProperty("user.dir") + "\\environment\\"
					+ "env.properties");
			// System.out.println("Property file for " + envname +
			// " has been created at " + file.getPath());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			fileOut.close();
		}

	}

	// }
}
