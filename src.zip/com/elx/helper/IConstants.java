/**
 * 
 */
package com.elx.helper;

/**
 * @author pts-macbook
 *
 */
public interface IConstants {
	static final String CAPABILITY_PROP_FILEPATH = "src/test/resources/capability.properties";
	static final String ENV_PROP_FILEPATH = "src/test/resources/env.properties";
	static final String BASE_ELEMENTS_FILEPATH="/elements/baseElements.properties";
	static final String IE_BROWSER_EXE_PATH="src/main/resources/exe/windowsdriver/IEDriverServer.exe";
	static final String CHROME_BROWSER_EXE_PATH="src/main/resources/exe/windowsdriver/chromedriver.exe";
	static final String HEADLESS_BROWSER_EXE_PATH="src\\main\\resources\\exe\\windowsdriver\\phantomjs.exe";
	static final String CHROME_MAC_BROWSER_EXE_PATH="src/main/resources/exe/macdriver/chromedriver";
	static final String PHANTOMJS_MAC_BROWSER_EXE_PATH="src/main/resources/exe/macdriver/phantomjs";
	static final String REPORTS_LOCATION="Reports";
	static final String SCREENSHOTS_LOCATION="Screenshots";
	static final String JMETER_HOME="/src/main/resources/exe/apache-jmeter-3.2";
	static final String MASTER_ENV_PROPS="/src/test/resources/testdata/masterbox_testdata.properties";
	static final String QA_ENV_PROPS="/src/test/resources/testdata/qa_testdata.properties";
	public static final int LOW_WAIT_TIME=120;
	public static final int MEDIUM_WAIT_TIME=300;
	public static final int HIGH_WAIT_TIME=1500;
	public static final int SYS_WAIT_TIME=40000;
}