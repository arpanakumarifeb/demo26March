package com.web.elx.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import com.elx.common.Common;
import com.elx.core.util.PropertyElementReader;
import com.elx.dto.handler.EnvirnomentHandler;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class AprisoCommonPage {

	@SuppressWarnings("static-access")
	private String locale = EnvirnomentHandler.getInstance().getEnvirnoment().getLocale();
	@SuppressWarnings("unused")
	private PropertyElementReader elementReader = PropertyElementReader.getInstance(locale);

	@FindBy(xpath ="//button[@class='ToolButton CREATE_NC_OUTOFCONTEXT T1 ']")
	private WebElement createNCButton;

	@FindBy(xpath ="//li[@title='NCM-020']")
	private WebElement createNCTitle;

	@FindBy(xpath ="//h2[@class='Label FormHead Collapsed']")
	private WebElement NCInfoPageTitle;

	@FindBy(xpath = ".//span[@title='Home']")
	private  WebElement homeIcon	;
	
	@FindBy(xpath = ".//span[@title='Return']")
	private  WebElement ReturnIcon	;
	
	
	
	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";
	String dashboard="//*[@id='DashboardAlert']/div/div/div[1]/a";


	private WebDriver driver;
	private Common common;

	public AprisoCommonPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}



	/**
	 * Method To click Create NC Button
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String clickCreateNCButton(String ScreenshotRequire) throws InterruptedException{
		String img=null;
		System.out.println("inside clickCreateNCButton function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(dashboard),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, createNCButton, IConstants.LOW_WAIT_TIME);
			common.clickOnObject(createNCButton,"createNCButton");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(4000);
			img=common.captureScreenshot(ScreenshotRequire);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Create Button is clicked successfuly"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}

	//Order# Verification
	@SuppressWarnings("static-access")
	public void validateCreateNCPageTitle(String orderId, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, createNCTitle, IConstants.LOW_WAIT_TIME);
		driver.switchTo().defaultContent();
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Crete NC page loaded"+ common.captureScreenshot(ScreenshotRequire));
		driver.switchTo().defaultContent();

	}

	@SuppressWarnings("static-access")
	public void validateNCPageTitle(String orderId, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, NCInfoPageTitle, IConstants.LOW_WAIT_TIME);
		driver.switchTo().defaultContent();
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Non-Conformity Information page loaded"+ common.captureScreenshot(ScreenshotRequire));
	}

	/**
	 * Method To click Home Icon
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void clickHomeIcon(String ScreenshotRequire) throws InterruptedException{
		try{
		System.out.println("inside click homeIcon function");
		common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
		common.isElementDisplayed(driver, homeIcon, IConstants.LOW_WAIT_TIME);
		Assert.assertTrue(homeIcon.isDisplayed(), "Home Icon not displayed");			
		common.clickOnObject(homeIcon, "homeIcon");
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
		System.out.println("homeIcon clicked");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Home page is appearing"+ common.captureScreenshot(ScreenshotRequire));
		driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}
	
	@SuppressWarnings("static-access")
	public void clickReturnIcon(String ScreenshotRequire) throws InterruptedException{
		try{
		System.out.println("inside click ReturnIcon function");
		common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
		Thread.sleep(3000);
		common.isElementDisplayed(driver, ReturnIcon, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(ReturnIcon.isDisplayed(), "ReturnIcon Icon not displayed");			
		common.clickOnObject(ReturnIcon, "ReturnIcon");
		System.out.println("ReturnIcon clicked");
		driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

}
