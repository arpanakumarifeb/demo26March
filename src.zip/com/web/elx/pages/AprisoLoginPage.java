package com.web.elx.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class AprisoLoginPage {

	@FindBy(xpath = "//h1/name[text()='Welcome to ']")
	//@FindBy(xpath = "//div[@class='heading']/h1")
	private WebElement welcomeTo;

	@FindBy(xpath = "//h2[text()='Log In to DELMIA Apriso Portal' or text()='Standard Login']")
	private WebElement delmiaPortalLogin;

	@FindBy(xpath = "(//h2)[1]")
	private WebElement standardLogin;

	@FindBy(xpath = "//input[@type='text' and @class='PopupInput input']")
	private WebElement userName;
	@FindBy(xpath = "//input[@type='password' and @class='PopupInput input']")
	private WebElement password;
	@FindBy(xpath = "//input[@type='submit']")
	private WebElement login;
	
	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	private WebDriver driver;
	private Common common;

	public AprisoLoginPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}
	/**
	 * Method To check login page
	 * @author 
	 * @throws InterruptedException
	 * @throws IOException
	 */

	public void isWelcomePage(String ScreenshotRequire){

		try{

			Assert.assertTrue(welcomeTo.isDisplayed(),"Welcome Page Not Displayed");
			System.out.println("Welcome Page Displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Welcome Page Displayed" + common.captureScreenshot(ScreenshotRequire));
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * This method is used to enter the user credential into Authorization window popup.
	 * @param userName
	 * @param pwd
	 * @throws AWTException
	 * @throws InterruptedException
	 * @throws IOException 
	 */
	public void enterAuthWindowCredentials(String userName,String pwd, String ScreenshotRequire) throws AWTException, InterruptedException, IOException{
		System.out.println(userName+"----"+ pwd);
		/*Robot robot = new Robot();
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		StringSelection stringSelection = new StringSelection(userName);
		clipboard.setContents(stringSelection, stringSelection);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(4000);
		StringSelection stringSelection1 = new StringSelection(pwd);
		clipboard.setContents(stringSelection1, stringSelection1);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(20000);*/
		
		/*WebDriverWait wait = new WebDriverWait(driver, IConstants.HIGH_WAIT_TIME);
		Alert alert= wait.until(ExpectedConditions.alertIsPresent());
		alert.authenticateUsing(new UserAndPassword(userName,pwd));
		alert.accept();*/
		
		/*Credentials credentials = new UserAndPassword(userName, pwd);
		Alert alert = driver.switchTo().alert();

		alert.authenticateUsing(credentials);*/
		
		/*driver.switchTo().alert().sendKeys("username" + Keys.TAB + "pwd");
		driver.switchTo().alert().accept();
		Thread.sleep(10000);
	    */
	    
		/*String exePath=System.getProperty("user.dir")+"\\masterboxPopUPHandler.exe\\";
		Runtime.getRuntime().exec(exePath);
		Thread.sleep(10000);
		
		System.out.println("Successfully Entered model credentials...........");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified -login into masterbox"+ common.captureScreenshot(ScreenshotRequire));*/
	}

	/**
	 * This method is used to click Login To Delmia link.
	 * @Author 
	 * @throws AWTException
	 * @throws InterruptedException
	 */
	public String clickLoginToDelmia(String ScreenshotRequire) throws InterruptedException{
		String img=null;
		try{Thread.sleep(4000);
		Assert.assertTrue(delmiaPortalLogin.isDisplayed());
		img=common.captureScreenshot(ScreenshotRequire);
		common.clickOnObject(delmiaPortalLogin, "delmiaPortalLogin");
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
		Thread.sleep(4000);
		System.out.println("click Login To Delmia link");
		/*String actualTitle = "DELMIA Apriso";
		Assert.assertEquals(driver.getTitle(), actualTitle);*/
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;

	}

	public String standardLoginsecondex(String ScreenshotRequire) throws AWTException, InterruptedException{
		Thread.sleep(10000);
		String img=null;
		img=common.captureScreenshot(ScreenshotRequire);
		Common.isElementDisplayed(driver, standardLogin, 180);
		Assert.assertTrue(standardLogin.isDisplayed(),"Standard Login Not Displayed");
		common.clickOnObject(standardLogin, "standardLogin");
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Thread.sleep(7000);		
		WebTestCase.getTest().log(LogStatus.PASS, "Standard login clicked"+ img);
		System.out.println("standardLogin clicked for other env");
		return img;
	}


	public String standardLogin(String userid, String pass,String status,String ScreenshotRequire) throws AWTException, InterruptedException{
		Thread.sleep(4000);
		String img=null;
		try{
			if(status.contains("Y")) {
				enterAuthWindowCredentials(userid,pass,ScreenshotRequire);
			}
			Thread.sleep(8000);
			Common.isElementDisplayed(driver, standardLogin, 180);
			Assert.assertTrue(standardLogin.isDisplayed(),"Standard Login Not Displayed");
			System.out.println("Standard Login button Displayed");
			img=common.captureScreenshot(ScreenshotRequire);
			common.clickOnObject(standardLogin,"standardLogin");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(4000);		
			WebTestCase.getTest().log(LogStatus.PASS, "Standard login clicked"+ img);
			System.out.println("standardLogin clicked");
		}catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		return img;
	}
	public String loginToElx(String username,String pwd,String ScreenshotRequire) throws InterruptedException{
		String img=common.captureScreenshot(ScreenshotRequire);
		System.out.println("loginToElx function");
		try{
			String title= driver.getTitle();
			if(title.contains("DELMIA Apriso 2017")) {
				Common.isElementDisplayed(driver, standardLogin, 180);
				Assert.assertTrue(standardLogin.isDisplayed(),"Standard Login Not Displayed");
				common.clickOnObject(standardLogin, "standardLogin");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(7000);		
				WebTestCase.getTest().log(LogStatus.PASS, "Standard login clicked"+ img);
			}
			Common.isElementDisplayed(driver, userName, 180);
			userName.clear();
			common.setObjectValue(userName, "userName", username);
			//userName.sendKeys(username);
			Common.isElementDisplayed(driver, password, 180);
			password.clear();
			//password.sendKeys(pwd);
			common.setObjectValue(password, "password", pwd);
			common.clickOnObject(login, "login");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(10000);

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:"+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		return img;
	}
	/**
	 * Methos To Login
	 * @author Chinmay
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public boolean EnterUserDetailsAndPassword(String username, String passWord, String ScreenshotRequire)
			throws IOException {

		if (common.setObjectValue(userName, "username",username) == false) {
			/*ReportLog.writeLogs(driver, userName,
					"username Should enter",
					"username not entered", "Fail");*/

			return false;
		}
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - username entered successfully"+ common.captureScreenshot(ScreenshotRequire));
		if (common.setObjectValue(password, "password",passWord) == false) {
			/*ReportLog.writeLogs(driver, pwd, "Password Should enter",
					"Password not entered", "Fail");
			Assert.assertFalse(false, "Page not loaded");*/

			return false;
		}
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Password entered successfully"+ common.captureScreenshot(ScreenshotRequire));

		/*ReportLog.writeLogs(driver, pwd, "Password Should enter",
				"Password entered correctly", "Pass");
		 */
		if (common.clickOnObject(login,
				"Login in") == false) {
			/*ReportLog.writeLogs(driver, btnSubmit,
					"Should Click on Login in Button", "Not Clicked on Login in Button", "Fail");*/
			return false;
		}

		/*ReportLog.writeLogs(driver, null,
				"Should Click on Login in Button",
				" Clicked Successfully on Login in button", "Pass");*/
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - login button clicked successfully"+ common.captureScreenshot(ScreenshotRequire));
		return true;

	}
}
