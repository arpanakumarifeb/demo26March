package com.web.elx.pages;

import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.elx.common.Common;
import com.elx.helper.*;
import com.relevantcodes.extentreports.LogStatus;

public class BuildPalletPage {

	public WebDriver driver;
	private Common common;
	ReadConfig testData = new ReadConfig();

	public BuildPalletPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}

	@FindBy(xpath = "//li[@title='MCS_BuildPallet']")
	private WebElement palletPageTitle;
	
	@FindBy(xpath = ".//div[@id='OrderSelected2']")
	private WebElement OrderDetailsHeader;

	@FindBy(xpath = ".//select[contains(@class,'OrderList  binding_Screen')]")
	private WebElement selectOrderDropDown;

	@FindBy(xpath = ".//select[contains(@class,'OrderList  binding_Screen')]/option[@value!='']")
	private List<WebElement> buildPlletOrderList;

	@FindBy(xpath = ".//div[contains(@id,'OrderSelected2')]/span")
	private WebElement OrderSelectedDetails;

	@FindBy(xpath = ".//input[contains(@class,'PalletQty')]")
	private WebElement PalletQty;

	@FindBy(xpath = ".//button[@value='BUILD']")
	private WebElement BUILDBtn;
	String BUILDbtn=".//button[@value='BUILD']";
	
	@FindBy(xpath = ".//div[@class='apr-message-error']")
	private WebElement errMessage;
	
	@FindBy(xpath = ".//div[contains(@id,'OrderSelected2')]/span/span[3]")
	private WebElement completedQty;
	
	
	@FindBy(xpath = ".//div[contains(@id,'OrderSelected2')]/span/span[5]")
	private WebElement targetQty;
	
	

	String iframepage = "//iframe[@class='apr-fullscreen-tab']";
	String toolbox = "//div[@class='Toolbox Top Loading']";

	/**
	 * Method To validate buildpallet page
	 * 
	 * @author Arpana
	 * @throws InterruptedException
	 */
	@SuppressWarnings("static-access")
	public void validateBuildPalletPage(String title) throws InterruptedException {
		try {
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME);
			common.isElementDisplayed(driver, palletPageTitle, IConstants.HIGH_WAIT_TIME);
			Assert.assertEquals(palletPageTitle.getText(), title, "MCS pallet page not displayed");
			WebTestCase.getTest().log(LogStatus.PASS,
					"Verified - MCS Pallet Screen is displayed");
			driver.switchTo().defaultContent();
		} catch (java.lang.AssertionError exp1) {
			System.out.println("Got Assertion Error.." + exp1);
			WebTestCase.getTest().log(LogStatus.FAIL, exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		} catch (Exception exp2) {
			WebTestCase.getTest().log(LogStatus.FAIL, exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To validate parts number on pallet page
	 * 
	 * @author Arpana
	 * @throws InterruptedException
	 */
	@SuppressWarnings("static-access")
	public void validatePartsDetailsOnBuildPalletPage(String[][] hm2, HashMap<String, String> orderCount, int rowCount, String ScreenshotRequire)
			throws InterruptedException {
		try {
			System.out.println("validatePartsDetailsOnBuildPalletPage function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME);
			common.isElementDisplayed(driver, palletPageTitle, IConstants.HIGH_WAIT_TIME);
			Select selectDropDown = new Select(selectOrderDropDown);
			int i = 0;
			for (int j = 1; j < buildPlletOrderList.size(); j++) {
				selectDropDown.selectByIndex(j);
				Thread.sleep(4000);
				// String selectedValue = selectDropDown.getFirstSelectedOption().getText();
				String selectedValue = OrderSelectedDetails.getAttribute("innerText");
				String[] splits = common.splitValues(selectedValue, "\\/");
				String partsId = splits[1].substring(0, 10).trim();
				String complQty = completedQty.getText().trim();
				//String tarQty = targetQty.getText().trim();
				System.out.println("parts id UI " + partsId);
				System.out.println("complQty UI " + complQty);

				for (int p = 0; p < 6; p++) {
					for (int k = 1; k < 2; k++) {
						if (hm2[p][k] != null) {
							if (hm2[p][i].contentEquals(partsId)) {
								System.out.println("parts ids are equal: " + hm2[p][i] + ">>" + partsId);
								if (hm2[p][k].contentEquals(PalletQty.getAttribute("value"))) {
									System.out.println(
											"qty ids are equal: " + hm2[p][k] + ">>" + PalletQty.getAttribute("value"));
									WebTestCase.getTest().log(LogStatus.PASS,
											"Max container default quantity is appearing correctly in build pallet screen with respect to Parts id :"
													+ partsId + ">>>" + PalletQty.getAttribute("value")
													+ common.captureScreenshot(ScreenshotRequire));
									break;
								}
							}
						}
					}

				}

			}
			driver.switchTo().defaultContent();
		} catch (java.lang.AssertionError exp1) {
			System.out.println("Got Assertion Error.." + exp1);
			WebTestCase.getTest().log(LogStatus.FAIL, exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		} catch (Exception exp2) {
			WebTestCase.getTest().log(LogStatus.FAIL, exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To validate quantity changed after building pallets 
	 * 
	 * @author Arpana Kumari
	 * @throws InterruptedException
	 */
	@SuppressWarnings({ "static-access" })
	public String validateQuantityOnBuildPalletPage(String title, HashMap<String, String> orderDetails, String ScreenshotRequire) throws InterruptedException {
		String afterPalleyCompletedQty=null;
		String orderId=null;
		System.out.println("validateQuantityOnBuildPalletPage function----");
		try {
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME);
			common.isElementDisplayed(driver, palletPageTitle, IConstants.HIGH_WAIT_TIME);
			Assert.assertEquals(palletPageTitle.getText(), title, "MCS Build pallet page not displayed");
			if(OrderDetailsHeader.getText().length()>0) {
				Assert.assertTrue(OrderDetailsHeader.getText().contains(orderDetails.get("StartedDisplayOrder")),"Started order details not matching in build paller page");
			}
			String selectedValue = OrderSelectedDetails.getAttribute("innerText");
			String[] splits = common.splitValues(selectedValue, "\\/");
			String beforePalletCompletedQty = completedQty.getText().trim();
			String targetPalleyQty = targetQty.getText().trim();
			orderId = splits[0].substring(33).trim();
			
			int compleqtyMCS= Integer.parseInt(orderDetails.get("QCompleted"));
			int trgtqtyMCS= Integer.parseInt(orderDetails.get("QTarget"));
			
			Assert.assertEquals(Integer.parseInt(beforePalletCompletedQty), compleqtyMCS,"completed qty not matching in build pallet page");
			Assert.assertEquals(Integer.parseInt(targetPalleyQty), trgtqtyMCS,"trgtqty qty not matching in build pallet page");
			System.out.println("completed qty UI before build order id " + orderId + "<<" + beforePalletCompletedQty);
			
			if ((Integer.parseInt(targetPalleyQty) > 0)
					&& ((Integer.parseInt(targetPalleyQty)) > (Integer.parseInt(beforePalletCompletedQty)))) {
				common.clickOnObject(BUILDBtn, "BUILD Btn");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME);
				common.elementToBeClickable(By.xpath(BUILDbtn),10);
				Thread.sleep(10000);
				WebTestCase.getTest().log(LogStatus.INFO,"Verified - build pallet button clicked for order id "+orderId);
				common.isElementDisplayed(driver, palletPageTitle, IConstants.HIGH_WAIT_TIME);
				afterPalleyCompletedQty = completedQty.getText().trim();
				
				System.out.println("qty UI after build : " + completedQty.getText().trim());
				Assert.assertEquals(Integer.parseInt(completedQty.getText().trim()) - Integer.parseInt(beforePalletCompletedQty),(Integer.parseInt(PalletQty.getAttribute("value"))),
						"build pallet quantity not decreased correctly");
				WebTestCase.getTest().log(LogStatus.INFO,"Verified - Pallet quantity has been changed for order id "+orderId+", beforePalleyQty was :" + beforePalletCompletedQty
						+ " after builing pallet quantity changed to :" + afterPalleyCompletedQty+ common.captureScreenshot(ScreenshotRequire));
			} else if ((Integer.parseInt(beforePalletCompletedQty)) == (Integer.parseInt(targetPalleyQty))) {
				WebTestCase.getTest().log(LogStatus.INFO,
						"Verified - completed and target qty are same"+ common.captureScreenshot(ScreenshotRequire));
			}
			driver.switchTo().defaultContent();
		} catch (java.lang.AssertionError exp1) {
			System.out.println("Got Assertion Error.." + exp1);
			WebTestCase.getTest().log(LogStatus.FAIL, exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		} catch (Exception exp2) {
			WebTestCase.getTest().log(LogStatus.FAIL, exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return  afterPalleyCompletedQty+"_"+orderId;
		
	}
	
	public void validateOrderDetailsBuildPalletPage(String title, String[][] hm2, HashMap<String, String> orderDetails, int rowCount)
			throws InterruptedException {
		try {
			System.out.println("validateOrderDetailsBuildPalletPage function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME);
			
			System.out.println("started order count::  "+orderDetails.get("Started") );
			System.out.println("map size  "+orderDetails.size() );
			if(buildPlletOrderList.size()>0) {
				Assert.assertEquals(buildPlletOrderList.size(), Integer.parseInt(orderDetails.get("StartedCount")),"Started order count not matching in build paller page");
			}
			driver.switchTo().defaultContent();
		} catch (java.lang.AssertionError exp1) {
			System.out.println("Got Assertion Error.." + exp1);
			WebTestCase.getTest().log(LogStatus.FAIL, exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		} catch (Exception exp2) {
			WebTestCase.getTest().log(LogStatus.FAIL, exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

}
