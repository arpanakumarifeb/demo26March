package com.web.elx.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;

import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class CancelNCPage {


	public WebDriver driver;
	private Common common;

	public CancelNCPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}


	//NC Title
	@FindBy(xpath = "//li[text()='Non-Conformity List']")
	private WebElement ncTitle;

	//NC Textbox
	@FindBy(xpath = "//input[@data-field='ncno']")
	private WebElement ncTextbox; 

	//Select NC number from grid
	@FindBy(xpath = "//*[contains(@id, 'content_BC_')]/tr[2]/td[1]")
	private WebElement ncIdNum;

	//Status Help
	@FindBy(xpath ="//*[contains(@id, 'content_BC_')]/tr[2]/td[13]")
	private WebElement NCStatus;

	//Cancel
	@FindBy(xpath ="//span[text()='Cancel NC']")
	private WebElement cancelButton;

	@FindBy(xpath="//div[@class='ui-dialog-buttonset']/button[1]")
	private WebElement yes;

	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	public void validateNCNumber(String ncNum, String ScreenshotRequire)
	{
		try
		{
			//Enter NC#
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, ncTextbox, IConstants.SYS_WAIT_TIME);
			Assert.assertTrue(ncTextbox.isDisplayed(), "NC# Textbox not displayed");
			WebTestCase.getTest().log(LogStatus.INFO, "Enter the NC Number:" + ncNum);
			Thread.sleep(10000);
			common.setObjectValue(ncTextbox,"ncTextbox",ncNum);
			//ncTextbox.sendKeys(ncNum);
			Common.isElementDisplayed(driver, ncTextbox, IConstants.SYS_WAIT_TIME);
			ncTextbox.sendKeys(Keys.ENTER);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertEquals(ncIdNum.getText(), ncNum,  "NC Number is not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Number is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
		}

		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	public void validateStatus(String status, String ScreenshotRequire)
	{
		try
		{
			//Validate Status New
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.scrollIntoViewPage(NCStatus);
			Common.isElementDisplayed(driver, NCStatus, IConstants.SYS_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.INFO, "Verify the NC Status" + status);
			Assert.assertEquals(NCStatus.getText(), status,  "Expected NC status is not displayed.");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Status " + status + " is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){	
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}
	public void validateCancelNC(String cancelStatus, String ScreenshotRequire)
	{
		try
		{
			//Cancel NC 
			Thread.sleep(8000);
			common.clickOnObject(ncIdNum,"ncIdNum");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			WebTestCase.getTest().log(LogStatus.INFO, "Verify the Cancel NC button is enabled");
			Assert.assertTrue(cancelButton.isEnabled(),  "Cancel NC button not enabled");
			WebTestCase.getTest().log(LogStatus.PASS, "Verifyed - the Cancel NC button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
			common.clickOnObject(cancelButton,"cancelButton");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			WebTestCase.getTest().log(LogStatus.INFO, "Verifyed - the popup is appeard with Yes and No button"+ common.captureScreenshot(ScreenshotRequire));
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor)driver; 
			js.executeScript("arguments[0].click();", yes);
			WebTestCase.getTest().log(LogStatus.INFO, "Verifyed - Clicked on Yes option"+ common.captureScreenshot(ScreenshotRequire));

			Thread.sleep(8000);
			//validateStatus(cancelStatus);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}
	
	
	
}
