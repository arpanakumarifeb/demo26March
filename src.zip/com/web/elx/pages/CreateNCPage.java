package com.web.elx.pages;

import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;


public class CreateNCPage {


	@FindBy(xpath = "(//td[@class='Label fl_NCStatus'][text()='Status']/../td/span)[2]")
	private WebElement status;


	@FindBy(xpath = "//td[@class='Label fl_WipOrderNo']/../td[@class='Control fc_WipOrderNo Bold']/span")
	private WebElement orderNumber;


	@FindBy(xpath = "//td[@class='Label fl_NCCreatedBy'][text()='Created By']/../td[@class='Control fc_NCCreatedBy Bold']/span")
	private WebElement createdBy;


	//@FindBy(xpath = "//li[text()='Reason:']")
	@FindBy(xpath = "//div[@id='NCMBreadCrumb']//li")
	private WebElement reason;

	@FindBy(xpath = ".//div[@class='apr-message-error']")
	private WebElement errMessage;

	@FindBy(xpath = "//span[text()='NRFT CODES']")
	private WebElement nrftCodes;


	@FindBy(xpath = "//span[text()='Electrical']")
	private WebElement electrical;


	@FindBy(xpath = "//td[@class='Label fl_NCCriticality']/..//../select")
	private WebElement criticality;


	@FindBy(xpath = "//button[@value='SAVE']/span")
	private WebElement save;

	@FindBy(xpath = ".//span[@class='fa fa-close ELX_RPC_window-close']")
	private WebElement cancel;

	@FindBy(xpath = "//td[@class='Control fc_Serial']/input")
	private WebElement inputSerialNumber;

	@FindBy(xpath = ".//iframe[@id='fake']")
	private WebElement iframeReasonCode;

	@FindBy(xpath = "(//select[contains(@class,'FC4')])[3]")
	private WebElement workCenterDropDown;


	@FindBy(xpath = ".//button[contains(@class,'ELX_NCM_RPC_ReasonCode')]")
	private List <WebElement> reasonCodeLevel;



	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";



	//span[text()='Harness']
	//span[contains(text(),'SCREW SHOT IN HARNESS')]
	private WebDriver driver;
	private Common common;

	public CreateNCPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}

	public String getOrderStatus(String order, String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), 30);
		Common.isElementDisplayed(driver, status, 30);
		String img=common.captureScreenshot(ScreenshotRequire);
		System.out.println("status.getText()..>"+status.getText());
		System.out.println("orderNumber.getText()..>"+orderNumber.getText());
		//Assert.assertTrue(status.getText().equals("New"));
		//Assert.assertTrue(orderNumber.getText().equals(order));
		//Assert.assertTrue(createdBy.getText().equals("Supervisor"));
		driver.switchTo().defaultContent();
		return img;

	}
	/**
	 * Method To enter reason Codes
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String reasonCodes(String code,String code1,String code2,String code3, String ScreenshotRequire) throws InterruptedException{

		try{
			System.out.println("inside reason code function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, reason, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//span[text()='"+code+"']")), 30);
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//span[text()='"+code+"']")));
			Thread.sleep(5000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+code+ common.captureScreenshot(ScreenshotRequire));	

			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//span[text()='"+code1+"']")),  IConstants.HIGH_WAIT_TIME);
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//span[text()='"+code1+"']")));
			Thread.sleep(5000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+code1+ common.captureScreenshot(ScreenshotRequire));


			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//span[text()='"+code2+"']")),  IConstants.HIGH_WAIT_TIME);
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//span[text()='"+code2+"']")));
			Thread.sleep(5000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+code2+ common.captureScreenshot(ScreenshotRequire));

			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//span[contains(text(),'"+code3+"')]")),  IConstants.HIGH_WAIT_TIME);
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//span[contains(text(),'"+code3+"')]")));
			Thread.sleep(5000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+code3+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);	

	}
	/**
	 * Method To select reason codes in create NC page.
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String reasonCodesSelection(String code,String ScreenshotRequire) throws InterruptedException{
		String reasonCodeVal=null;
		try{
			System.out.println("inside reason code function:"+ code);

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, reason, IConstants.HIGH_WAIT_TIME);
			Thread.sleep(5000);
			
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//span[text()='"+code+"']")), IConstants.HIGH_WAIT_TIME);
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//span[text()='"+code+"']")));
			Thread.sleep(5000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code level1:"+code+ common.captureScreenshot(ScreenshotRequire));
			int reasonCodeL2=generateRandomIntIntRange(0,(reasonCodeLevel.size()-2));
			System.out.println("RandomIntegerNumberlevel2 = "+reasonCodeL2);
			Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL2), 30);
			String reasonCode2=reasonCodeLevel.get(reasonCodeL2).getText();
			js.executeScript("arguments[0].click();", reasonCodeLevel.get(reasonCodeL2));
			Thread.sleep(5000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level2:"+reasonCode2+ common.captureScreenshot(ScreenshotRequire));
			reasonCodeVal=reasonCode2;

			if(reasonCodeLevel.size()>0) {
				String reasoncode3=null;
				if(reasonCodeLevel.size()>1) {
					int reasonCodeL3=generateRandomIntIntRange(0,(reasonCodeLevel.size()-1));
					System.out.println("RandomIntegerNumberlevel3 = "+reasonCodeL3);
					Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL3), 30);
					reasoncode3=reasonCodeLevel.get(reasonCodeL3).getText();
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(reasonCodeL3));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level3:"+ reasoncode3+common.captureScreenshot(ScreenshotRequire));
				}else {
					reasoncode3=reasonCodeLevel.get(0).getText();
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level3:"+ reasoncode3+common.captureScreenshot(ScreenshotRequire));
				}
				reasonCodeVal=reasonCodeVal+"_"+reasoncode3;
			}
			if(reasonCodeLevel.size()>0) {
				String reasoncode4=null;
				if(reasonCodeLevel.size()>1) {
					int reasonCodeL4=generateRandomIntIntRange(0,(reasonCodeLevel.size()-1));
					Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL4), 30);
					reasoncode4=reasonCodeLevel.get(reasonCodeL4).getText();
					System.out.println("RandomIntegerNumberlevel4 = "+reasoncode4);
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(reasonCodeL4));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code level4:"+ reasoncode4+common.captureScreenshot(ScreenshotRequire));
				}else {
					reasoncode4= reasonCodeLevel.get(0).getText();
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
					System.out.println("RandomIntegerNumberlevel4 = "+reasoncode4);
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code level4:"+ reasoncode4+common.captureScreenshot(ScreenshotRequire));
				}
				reasonCodeVal=reasonCodeVal+"_"+reasoncode4;
			}
			if(reasonCodeLevel.size()>0) {
				String reasoncode5=null;
				if(reasonCodeLevel.size()>1) {
					int reasonCodeL5=generateRandomIntIntRange(0,(reasonCodeLevel.size()-1));
					System.out.println("RandomIntegerNumberlevel4 = "+reasonCodeL5);
					Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL5), 30);
					reasoncode5=reasonCodeLevel.get(reasonCodeL5).getText();
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(reasonCodeL5));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code level5:"+ reasoncode5+common.captureScreenshot(ScreenshotRequire));
				}else {
					reasoncode5= reasonCodeLevel.get(0).getText();
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code level5:"+ reasoncode5+common.captureScreenshot(ScreenshotRequire));
				}
				reasonCodeVal=reasonCodeVal+"_"+reasoncode5;
			}
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return reasonCodeVal;	

	}

	public String criticalityAndSave(String name, String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), 30);
		Common.isElementDisplayed(driver, criticality, 30);
		Select select = new Select(criticality);
		select.selectByVisibleText(name);
		String img=common.captureScreenshot(ScreenshotRequire);
		save.click();
		driver.switchTo().defaultContent();
		return img;
	}
	//***************************************************************************************************
	//*	NAME		    	: enterSerialNumber
	//*	DESCRIPTION	    	: Enter Serial Number
	//*	CREATED RELEASE 	: 
	//*	LAST MODIFIED IN 	: 
	//*	AUTHOR				: Arpana Kumari
	//*	INPUT PARAMS		: 
	//*	RETURN VALUE		: 
	//* UPDATED ON 			: 30/08/2019
	//***************************************************************************************************
	@SuppressWarnings("static-access")
	public void enterSerialNumber(String sNo, String sharedFlag, String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside enterSerialNumber function");
			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			if(sharedFlag!=null) {
			if(sharedFlag.contains(";")) {
				Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
				Thread.sleep(5000);
				common.clickOnObject(save,"save");
				WebTestCase.getTest().log(LogStatus.PASS, "Save Button clicked successfully"+ common.captureScreenshot(ScreenshotRequire));
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Thread.sleep(8000);
				Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without Entering serial number"+ common.captureScreenshot("true"));
				common.setObjectValue(inputSerialNumber, "inputSerialNumber", sNo);
				inputSerialNumber.sendKeys(Keys.RETURN);
				System.out.println("Serial number entered for shared WC::" + sNo);
				WebTestCase.getTest().log(LogStatus.PASS, "Serial Number entered successfully for shared WC: "+sNo+ common.captureScreenshot("true"));
				Thread.sleep(5000);
			}else {
				Thread.sleep(5000);
				common.setObjectValue(inputSerialNumber, "inputSerialNumber", sNo);
				inputSerialNumber.sendKeys(Keys.RETURN);
				System.out.println("Serial number entered for non shared WC::" + sNo);
				WebTestCase.getTest().log(LogStatus.PASS, "Serial Number entered successfully for non-shared WC: "+sNo+ common.captureScreenshot(ScreenshotRequire));
				Thread.sleep(10000);
			}
			}else {
				Thread.sleep(5000);
				common.setObjectValue(inputSerialNumber, "inputSerialNumber", sNo);
				inputSerialNumber.sendKeys(Keys.RETURN);
				System.out.println("Serial number entered for non shared WC::" + sNo);
				WebTestCase.getTest().log(LogStatus.PASS, "Serial Number entered successfully for non-shared WC: "+sNo+ common.captureScreenshot(ScreenshotRequire));
				Thread.sleep(10000);
			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}
	//***************************************************************************************************
	//*	NAME		    	: selectWorkCenter
	//*	DESCRIPTION	    	: Select work center from dropdown
	//*	CREATED RELEASE 	: 
	//*	LAST MODIFIED IN 	: 
	//*	AUTHOR				: Arpana Kumari
	//*	INPUT PARAMS		: 
	//*	RETURN VALUE		: 
	//* UPDATED ON 			: 23/10/2018
	//***************************************************************************************************
	public String selectWorkCenterAndClickSave(String workCenter, String ScreenshotRequire) throws InterruptedException{
		String img=null;
		try{
			System.out.println("inside selectWorkCenter function: "+workCenter);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			Common.isElementDisplayed(driver, workCenterDropDown, IConstants.SYS_WAIT_TIME);
			Select select = new Select(workCenterDropDown);		
			common.clickOnObject(workCenterDropDown, "workCenterDropDown");
			select.selectByVisibleText(workCenter);
			System.out.println("work center selected:" +workCenter);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, workCenterDropDown, IConstants.SYS_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "Work Center selected successfully: "+workCenter+ common.captureScreenshot(ScreenshotRequire));
			img=common.captureScreenshot(ScreenshotRequire);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			WebTestCase.getTest().log(LogStatus.FAIL,exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}
	
	//***************************************************************************************************
		//*	NAME		    	: selectWorkCenter
		//*	DESCRIPTION	    	: Select work center from dropdown
		//*	CREATED RELEASE 	: 
		//*	LAST MODIFIED IN 	: 
		//*	AUTHOR				: Arpana Kumari
		//*	INPUT PARAMS		: 
		//*	RETURN VALUE		: 
		//* UPDATED ON 			: 23/10/2018
		//***************************************************************************************************
		public String selectWorkCenter(String workCenter, String ScreenshotRequire) throws InterruptedException{
			String img=null;
			try{
				System.out.println("inside selectWorkCenter function: "+workCenter);
				common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
				Common.isElementDisplayed(driver, workCenterDropDown, IConstants.SYS_WAIT_TIME);
				Select select = new Select(workCenterDropDown);		
				common.clickOnObject(workCenterDropDown, "workCenterDropDown");
				select.selectByVisibleText(workCenter);
				System.out.println("work center selected:" +workCenter);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Common.isElementDisplayed(driver, workCenterDropDown, IConstants.SYS_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.PASS, "Work Center selected successfully: "+workCenter+ common.captureScreenshot(ScreenshotRequire));
				img=common.captureScreenshot(ScreenshotRequire);
				driver.switchTo().defaultContent();
			}
			catch(java.lang.AssertionError exp1){
				System.out.println("Got Assertion Error..");
				WebTestCase.getTest().log(LogStatus.FAIL,
						exp1.getMessage() + common.captureScreenshot("true"));
				Assert.fail(exp1.getMessage());
			}
			catch(Exception exp2){
				WebTestCase.getTest().log(LogStatus.FAIL,exp2.getMessage() + common.captureScreenshot("true"));
				Assert.fail(exp2.getMessage());
			}
			return img;
		}
	
	//***************************************************************************************************
		//*	NAME		    	: clickSaveBtn
		//*	DESCRIPTION	    	: clickSaveBtn
		//*	CREATED RELEASE 	: 
		//*	LAST MODIFIED IN 	: 
		//*	AUTHOR				: Arpana Kumari
		//*	INPUT PARAMS		: 
		//*	RETURN VALUE		: 
		//* UPDATED ON 			: 30/08/2019
		//***************************************************************************************************
		public String ClickSaveBtn(String ScreenshotRequire) throws InterruptedException{
			String img=null;
			try{
				System.out.println("inside ClickSaveBtn function: ");
				common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
				Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
				Thread.sleep(10000);
				common.clickOnObject(save,"save");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				WebTestCase.getTest().log(LogStatus.PASS, "Save Button clicked successfully"+ common.captureScreenshot(ScreenshotRequire));
				driver.switchTo().defaultContent();
			}
			catch(java.lang.AssertionError exp1){
				System.out.println("Got Assertion Error..");
				WebTestCase.getTest().log(LogStatus.FAIL,
						exp1.getMessage() + common.captureScreenshot("true"));
				Assert.fail(exp1.getMessage());
			}
			catch(Exception exp2){
				WebTestCase.getTest().log(LogStatus.FAIL,exp2.getMessage() + common.captureScreenshot("true"));
				Assert.fail(exp2.getMessage());
			}
			return img;
		}
	/**
	 * Method To verify reason codes selection in create NC page.
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String verifyReasonCodesSelection(String code, String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("verifyReasonCodesSelection function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(5000);
			Common.isElementDisplayed(driver, reason, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//span[text()='"+code+"']")), IConstants.HIGH_WAIT_TIME);
			Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
			common.clickOnObject(save, "save button");
			Thread.sleep(10000);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code Level1."+ common.captureScreenshot(ScreenshotRequire));
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//span[text()='"+code+"']")));
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code level1:"+code+ common.captureScreenshot(ScreenshotRequire));

			Thread.sleep(5000);
			System.out.println("reason code size2:"+ reasonCodeLevel.size());
			int reasonCodeL2=generateRandomIntIntRange(0,(reasonCodeLevel.size()-2));
			Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL2), IConstants.HIGH_WAIT_TIME);
			String reasonCode2=reasonCodeLevel.get(reasonCodeL2).getText();
			System.out.println("RandomIntegerNumberlevel2 = "+reasonCode2);
			
			if(reasonCodeLevel.size()>8) {
				Common.isElementDisplayed(driver, cancel, IConstants.SYS_WAIT_TIME);
				common.clickOnObject(cancel, "cancel button");
				Thread.sleep(5000);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
				common.clickOnObject(save, "save button");
				Thread.sleep(5000);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code Level2."+ common.captureScreenshot(ScreenshotRequire));
				common.clickOnObject(driver.findElement(By.xpath("//li[@title='"+code+"']")), "code");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(5000);
			}else {
				Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
				common.clickOnObject(save, "save button");
				Thread.sleep(5000);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code Level3."+ common.captureScreenshot(ScreenshotRequire));
			}
			
			
			/*Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
			common.clickOnObject(save, "save button");
			Thread.sleep(5000);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code Level2."+ common.captureScreenshot());
			*/
			js.executeScript("arguments[0].click();", reasonCodeLevel.get(reasonCodeL2));
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level2:"+reasonCode2+ common.captureScreenshot(ScreenshotRequire));
			
			
			int reasonCodeL3=0;
			String reasoncode3=null;
			Thread.sleep(5000);
			if(reasonCodeLevel.size()>0) {
				if(reasonCodeLevel.size()>1) {
					System.out.println("reason code size3:"+ reasonCodeLevel.size());
					reasonCodeL3=generateRandomIntIntRange(0,(reasonCodeLevel.size()-1));
					Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL3), 30);
					reasoncode3=reasonCodeLevel.get(reasonCodeL3).getText();
					System.out.println("RandomIntegerNumberlevel = "+reasoncode3);
					if(reasonCodeLevel.size()>8) {
						Common.isElementDisplayed(driver, cancel, IConstants.SYS_WAIT_TIME);
						common.clickOnObject(cancel, "cancel button");
						Thread.sleep(5000);
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
						Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
						common.clickOnObject(save, "sav		e button");
						Thread.sleep(5000);
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
						Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
						WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code Level3."+ common.captureScreenshot(ScreenshotRequire));
						common.clickOnObject(driver.findElement(By.xpath("//li[@title='"+reasonCode2+"']")), "reasonCodeL2");
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
						Thread.sleep(5000);
					}else {
						Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
						common.clickOnObject(save, "save button");
						Thread.sleep(5000);
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
						Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
						WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code Level3."+ common.captureScreenshot(ScreenshotRequire));
					}
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(reasonCodeL3));
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level3:"+ reasoncode3+common.captureScreenshot(ScreenshotRequire));

				}else {
					reasoncode3=reasonCodeLevel.get(0).getText();
					System.out.println("RandomIntegerNumberlevel3 = "+reasoncode3);
					Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
					common.clickOnObject(save, "save button");
					Thread.sleep(5000);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
					WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code level3."+ common.captureScreenshot(ScreenshotRequire));
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level3:"+ reasoncode3+common.captureScreenshot(ScreenshotRequire));
				}
			}

			Thread.sleep(5000);
			if(reasonCodeLevel.size()>0) {
				int reasonCodeL4=0;
				String reasoncode4=null;
				if(reasonCodeLevel.size()>1) {
					System.out.println("reason code size4:"+ reasonCodeLevel.size());
					reasonCodeL4=generateRandomIntIntRange(0,(reasonCodeLevel.size()-1));
					
					Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL4), 30);
					reasoncode4=reasonCodeLevel.get(reasonCodeL4).getText();
					System.out.println("RandomIntegerNumberlevel4 = "+reasoncode4);
					if(reasonCodeLevel.size()>8) {
						Common.isElementDisplayed(driver, cancel, IConstants.SYS_WAIT_TIME);
						common.clickOnObject(cancel, "cancel button");
						Thread.sleep(5000);
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
						Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
						common.clickOnObject(save, "save button");
						Thread.sleep(5000);
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
						Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
						WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code Level4."+ common.captureScreenshot(ScreenshotRequire));
						common.clickOnObject(driver.findElement(By.xpath("//li[@title='"+reasoncode3+"']")), "reasonCodeL3");
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					}else {
						Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
						common.clickOnObject(save, "save button");
						Thread.sleep(5000);
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
						Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
						WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code Level4."+ common.captureScreenshot(ScreenshotRequire));
					}
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(reasonCodeL4));
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level4:"+ reasoncode4+common.captureScreenshot(ScreenshotRequire));

				}else {
					reasoncode4=reasonCodeLevel.get(0).getText();
					System.out.println("RandomIntegerNumberlevel4 = "+reasonCodeL4);
					Common.isElementDisplayed(driver, save, IConstants.SYS_WAIT_TIME);
					common.clickOnObject(save, "save button");
					Thread.sleep(5000);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
					WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code level4."+ common.captureScreenshot(ScreenshotRequire));
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level4:"+ reasoncode4+common.captureScreenshot(ScreenshotRequire));
				}
			}
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);	

	}
	public static int generateRandomIntIntRange(int min, int max) {
		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}

}
