package com.web.elx.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;

import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class CreateNCfromNCMPage {
	
	
	@FindBy(xpath = "//li[text()='Non-Conformity List']")
	private WebElement ncTitle;
	
	
	@FindBy(xpath ="//button[@class='ToolButton CREATE_NC_OUTOFCONTEXT T1 ']")
	private WebElement createNCButton;
	
	
	@FindBy(xpath ="//button[@name='NRFT']")
	private WebElement NRFT;
	
	@FindBy(xpath ="//button[@name='DFP']")
	private WebElement DFP;
	
	
	@FindBy(xpath ="//button[@name='AESTHETIC']")
	private WebElement aesthetic;
	
	@FindBy(xpath ="//button[@name='Aesthetic-Console']")
	private WebElement aestheticOpt;
	
	@FindBy(xpath ="//td[@class='Control fc_Serial']")
	private WebElement serialNo;
	
	@FindBy(xpath = "//input[@data-field='productionordernolist']")
	private WebElement orderTextbox;
	
	@FindBy(xpath ="//td[@data-field='productionordernolist']//span[@class='display']")
	private WebElement ordId;
	
	@FindBy(xpath ="//*[text()='Operations']")
	private WebElement labelOperator;
	
	@FindBy(xpath ="//span[@class='TabNotify']")
	private WebElement tabNonConformance;
	
	
	
	private WebDriver driver;
	private Common common;
	
	public CreateNCfromNCMPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}
	

	public void validateNonConformance(String orderId, String oprLabel, String ScreenshotRequire) throws InterruptedException{
				
	try {
		common.switchToFrame(By.xpath("//iframe[@class='apr-fullscreen-tab']"), IConstants.MEDIUM_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath("//div[@class='Toolbox Top Loading']"), IConstants.SYS_WAIT_TIME);
		Common.isElementDisplayed(driver, orderTextbox, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(orderTextbox.isDisplayed(), "Order# Textbox not displayed");
		common.setObjectValue(orderTextbox, "orderTextbox", orderId);
		//orderTextbox.sendKeys(orderId);
		orderTextbox.sendKeys(Keys.RETURN);
		Thread.sleep(20000);
		common.waitTillElementDisappears(By.xpath("//div[@class='Toolbox Top Loading']"), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, ordId, IConstants.HIGH_WAIT_TIME);
		Assert.assertEquals(ordId.getText(), orderId, "Order# is not in the list");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
		Thread.sleep(15000);
		Common.isElementDisplayed(driver, labelOperator, IConstants.HIGH_WAIT_TIME);
		Assert.assertEquals(labelOperator.getText(), oprLabel,  "ORD20 screen is not displayed");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD20 screen is displayed successfuly"+ common.captureScreenshot(ScreenshotRequire));			
			
		}
	catch(java.lang.AssertionError exp1){
		System.out.println("Got Assertion Error");
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp1.getMessage() + common.captureScreenshot("true"));
				Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}		
	
	}
	public void validateTitle(String title, String op1, String ScreenshotRequire) throws InterruptedException{
		try
		{
		common.switchToFrame(By.xpath("//iframe[@class='apr-fullscreen-tab']"), IConstants.MEDIUM_WAIT_TIME);
		//Thread.sleep(30000);
		common.waitTillElementDisappears(By.xpath("//div[@class='Toolbox Top Loading']"), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, ncTitle, IConstants.HIGH_WAIT_TIME);
		Assert.assertEquals(ncTitle.getText(), title,  "Order Cockpit page not displayed");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD Screen is displayed successfully"+ common.captureScreenshot(ScreenshotRequire));
		WebTestCase.getTest().log(LogStatus.INFO, "Click on CreateNC button"+ common.captureScreenshot(ScreenshotRequire));
		common.click(createNCButton);
		common.waitTillElementDisappears(By.xpath("//*[@class='apr-ctspinner']"), IConstants.SYS_WAIT_TIME );
		Thread.sleep(15000);
		Common.isElementDisplayed(driver, NRFT, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(NRFT.isDisplayed(), "NRFT is not displayed");
			if(op1.contains(NRFT.getText()))
			{
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - NRFT is displayed successfully"+ common.captureScreenshot(ScreenshotRequire));
				WebTestCase.getTest().log(LogStatus.INFO, "Click on NRFT OPTION");
				common.click(NRFT);
			}else if(op1.contains(DFP.getText()))
			{
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - DFP is displayed successfully"+ common.captureScreenshot(ScreenshotRequire));
				WebTestCase.getTest().log(LogStatus.INFO, "Click on DFP OPTION");
				common.click(DFP);
			}
		
		
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
					Assert.fail(exp1.getMessage());
			}
			catch(Exception exp2){
				
				WebTestCase.getTest().log(LogStatus.FAIL,
						exp2.getMessage() + common.captureScreenshot("true"));
				Assert.fail(exp2.getMessage());
			}	}
	
	
	public void validatePopup(String opt1, String opt2, String opt3, String serialNum, String ScreenshotRequire) throws InterruptedException{
		try
		{
			common.waitTillElementDisappears(By.xpath("//*[@class='apr-ctspinner']"), IConstants.SYS_WAIT_TIME );
			Thread.sleep(10000);
			
			WebTestCase.getTest().log(LogStatus.INFO, "Verify Aesthetic Option is displayed");
			Assert.assertTrue(aesthetic.isDisplayed(), "Aesthetic is not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified Aesthetic Option is displayed as expected"+common.captureScreenshot(ScreenshotRequire));
			if(opt1.contains(aesthetic.getText()))
				{
					WebTestCase.getTest().log(LogStatus.INFO, "Click on Aesthetic Option");
					common.click(aesthetic);
					Common.isElementDisplayed(driver, aestheticOpt , IConstants.HIGH_WAIT_TIME);
					WebElement popup3=driver.findElement(By.xpath("//button[@value='"+opt2+"']"));
					Common.isElementDisplayed(driver, popup3 , IConstants.HIGH_WAIT_TIME);
					WebTestCase.getTest().log(LogStatus.INFO, "Verify the Option " +popup3.getText()+ " is displayed");
					Assert.assertTrue(popup3.isDisplayed(), "Option " +popup3.getText()+ " is not displayed");
					WebTestCase.getTest().log(LogStatus.PASS, "Verified Option " +popup3.getText()+  " is displayed as expected"+common.captureScreenshot(ScreenshotRequire));
					WebTestCase.getTest().log(LogStatus.INFO, "Click on Option " +popup3.getText());
					popup3.click();
					Thread.sleep(15000);
					WebElement popup4=driver.findElement(By.xpath("//button[@value='"+opt3+"']"));
					Common.isElementDisplayed(driver, popup4 , IConstants.HIGH_WAIT_TIME);
					WebTestCase.getTest().log(LogStatus.INFO, "Verify the Option " +popup4.getText()+ " is displayed");
					Assert.assertTrue(popup4.isDisplayed(), "Option " +popup4.getText()+ " is not displayed");
					WebTestCase.getTest().log(LogStatus.PASS, "Verified Option " +popup4.getText()+  " is displayed as expected"+common.captureScreenshot(ScreenshotRequire));
					WebTestCase.getTest().log(LogStatus.INFO, "Click on Option " +popup4.getText());
					popup4.click();
					WebTestCase.getTest().log(LogStatus.PASS, "Verified Option " +popup4.getText()+  " is selected"+common.captureScreenshot(ScreenshotRequire));
					/*Common.isElementDisplayed(driver, serialNo, IConstants.HIGH_WAIT_TIME);
					Thread.sleep(5000);
					Assert.assertTrue(serialNo.isDisplayed(), "Serial textbox not displayed");
					WebTestCase.getTest().log(LogStatus.INFO, "Enter serial number");
					serialNo.sendKeys(serialNum);
					WebTestCase.getTest().log(LogStatus.INFO, "Serial number entered successfully");
					Thread.sleep(10000);*/
				}
					
			
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
					Assert.fail(exp1.getMessage());
			}
			catch(Exception exp2){
				
				WebTestCase.getTest().log(LogStatus.FAIL,
						exp2.getMessage() + common.captureScreenshot("true"));
				Assert.fail(exp2.getMessage());
			}	}

}
