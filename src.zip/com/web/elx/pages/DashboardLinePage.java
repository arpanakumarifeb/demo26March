package com.web.elx.pages;
import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;
public class DashboardLinePage {


	@FindBy(xpath = "//tr[@data-class='ELX_GridColorCode_Red']")
	private List<WebElement> orders;



	@FindBy(xpath = "//*[@id='DashboardAlert']/div/div/div[1]/a")
	private WebElement altmess;

	@FindBy(xpath = "//*[@id='DashboardAlert']/div/div/div[2]/div/table/tbody/tr/td")
	private WebElement helpdefect;

	@FindBy(xpath = "//*[@id='header']/div/div")
	private WebElement dshmain;

	@FindBy(xpath = "//*[@id='DashboardContent']")
	private WebElement colorheader;

	@FindBy(xpath = ".//span[@id='ELX_Header_Information']")
	private WebElement ELXHeader;

	@FindBy(xpath = ".//span[@id='spanOrderName']")
	private WebElement orderName;

	@FindBy(xpath = ".//span[@id='spanToDoQty']")
	private WebElement spanToDoQty;

	@FindBy(xpath = ".//span[@id='spanDoneQty']")
	private WebElement spanDoneQty;

	@FindBy(xpath = ".//span[@id='spanPlannedQty']")
	private WebElement spanPlannedQty;

	@FindBy(xpath = ".//span[text()='STOP']")
	private WebElement stopButton;

	@FindBy(xpath = ".//div[contains(text(),'REASON')]")
	private WebElement reasonText;

	@FindBy(xpath = ".//span[contains(@id,'spanProductNo')]")
	private WebElement spanProductNo;

	@FindBy(xpath = ".//span[@id='spanRemainingTime']")
	private WebElement spanRemainingTime;

	@FindBy(xpath = ".//span[@id='spanProductionLineNo']")
	private List<WebElement> ProductionLineNo;


	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";


	private WebDriver driver;
	private Common common;

	public DashboardLinePage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}

	public void dashboardValidate(String ScreenshotRequire)
	{
		try
		{
			common.switchToFrame(By.xpath("//iframe[@class='apr-fullscreen-tab']"), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath("//*[@id='DashboardAlert']/div/div/div[1]/a"),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, dshmain, IConstants.LOW_WAIT_TIME);
			Assert.assertTrue(dshmain.isDisplayed(),"Pass");
			System.out.println("PASS--->"+dshmain.getText());
			Common.isElementDisplayed(driver, altmess, 100);


			if(!(common.isElementVisible(By.xpath("//*[@id='DashboardAlert']/div/div/div[1]/a"))))
			{
				System.out.println("Fail alert message");
				Common.isElementDisplayed(driver, altmess, 100);
				Assert.assertFalse(common.isElementVisible(By.xpath("//*[@id='DashboardAlert']/div/div/div[1]/a")),"fail");
				System.out.println("Not showing Alert mess");
				WebTestCase.getTest().log(LogStatus.FAIL, "failed not found alert message"+ common.captureScreenshot(ScreenshotRequire));

			}
			else
			{
				System.out.println("Pass Alert message");
				Common.isElementDisplayed(driver, altmess, 100);
				String helpraised=altmess.getText();
				System.out.println("Showing Alert Message:"+helpraised);
				System.out.println("Showing :"+helpdefect.getText());
				Assert.assertTrue(helpdefect.isDisplayed(),"Pass");
				Assert.assertEquals(altmess.getText(),helpraised , "Not Shown Alert mess");
				/*String actualColor = Common.isElementDisplayed(driver, colorheader,100).getCssValue("color");
				System.out.println("PASS"+actualColor);
				Assert.assertEquals("#FFFF00", actualColor,"Not shown yellow Color");*/
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - text displayed::"+helpraised+" "+"\n"+helpdefect.getText()+ common.captureScreenshot(ScreenshotRequire));
			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error");
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	/**
	 * Method To validate Operation Page Title
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String validateOperationPageTitle(String Line,String wc, String sharedWC, String ScreenshotRequire) throws InterruptedException{
		try
		{	
			System.out.println("inside validate operation page title function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(4000);
			Common.isElementDisplayed(driver, ELXHeader, IConstants.MEDIUM_WAIT_TIME);
			if(sharedWC!=null) {
				if(sharedWC.contains(";")) {
					if(!ELXHeader.getText().contains(Line)) {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Main operation page is displayed successfuly for Shared WC"+ common.captureScreenshot(ScreenshotRequire));
						System.out.println("Main operation title:"+ELXHeader.getText());
					}else {
						WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Main operation page is not displayed successfuly for Shared WC"+ common.captureScreenshot(ScreenshotRequire));
						System.out.println("Main operation title:"+ELXHeader.getText());
					}
				}else if(ELXHeader.getText().contains(Line)) {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - Main operation page is  displayed successfuly for non shared WC"+ common.captureScreenshot(ScreenshotRequire));
					System.out.println("Main operation title:"+ELXHeader.getText());
				}
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Main operation page is  displayed successfuly for non shared WC"+ common.captureScreenshot(ScreenshotRequire));
				System.out.println("Main operation title:"+ELXHeader.getText());
			}
			driver.switchTo().defaultContent();
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);
	}

	/**
	 * Method To select Order Number
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String selectOrderNumber(String Line, String ScreenshotRequire) throws InterruptedException{
		String orderDetails=null;
		try
		{	
			System.out.println("inside selectOrderNumber function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(4000);
			Common.isElementDisplayed(driver, ELXHeader, IConstants.MEDIUM_WAIT_TIME);
			orderDetails=driver.findElement(By.xpath(".//span[contains(text(),'"+Line+"')]/../span[@id='spanOrderName']")).getText();
			if(orderDetails.length()>0) {
				System.out.println("complete list display:"+orderDetails);
				WebTestCase.getTest().log(LogStatus.PASS,"complete details of operator page:" +orderDetails);
			}else {
				System.out.println("No Order for the Line");
				WebTestCase.getTest().log(LogStatus.PASS,"Order unavailable for Line: :"+Line+common.captureScreenshot(ScreenshotRequire) );
			}
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

		return orderDetails;
	}

	/**
	 * Method To selectAndersonPlantOrderNumber
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String selectAndersonPlantOrderNumber(String ScreenshotRequire) throws InterruptedException{
		String orderAndQuan=null;
		try
		{	
			System.out.println("inside selectAndersonPlantOrderNumber function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(4000);
			Common.isElementDisplayed(driver, ELXHeader, IConstants.MEDIUM_WAIT_TIME);
			Assert.assertTrue(orderName.isEnabled(),  "order number not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - order number is displayed successfuly:"+orderName.getText()+ common.captureScreenshot(ScreenshotRequire));
			System.out.println("order number:"+orderName.getText());
			orderAndQuan=orderName.getText()+"_"+spanProductNo.getText();
			System.out.println("complete list display:"+orderAndQuan);
			WebTestCase.getTest().log(LogStatus.PASS,"complete details of operator page:" +orderAndQuan);
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

		return orderAndQuan;
	}
	/**
	 * Method To click On Button
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String clickOnButton(String val, String ScreenshotRequire) throws InterruptedException{
		String img=common.captureScreenshot(ScreenshotRequire);
		System.out.println("clickOnButton method : selecting button "+val);
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			WebElement clickOption=driver.findElement(By.xpath("//span[contains(text(),'"+val+"')]"));
			Common.isElementDisplayed(driver, clickOption, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(clickOption.isDisplayed(),clickOption.getText()+" Button not available");
			WebTestCase.getTest().log(LogStatus.INFO, "Verified the " +val +" item is present"+ common.captureScreenshot(ScreenshotRequire));
			common.clickOnObject(clickOption,"click on:"+ val);
			Thread.sleep(5000);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			System.out.println("clicked On Button");
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return img;
	}

	public String ValidateButton(String val, String ScreenshotRequire) throws InterruptedException{
		String img=common.captureScreenshot(ScreenshotRequire);
		System.out.println("clickOnButton method : selecting button "+val);
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			WebElement clickOption=driver.findElement(By.xpath("//span[contains(text(),'"+val+"')]"));
			Common.isElementDisplayed(driver, clickOption, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(clickOption.isDisplayed(),clickOption.getText()+" Button not available");
			WebTestCase.getTest().log(LogStatus.INFO, "Verified the " +val +" item is present"+ common.captureScreenshot(ScreenshotRequire));
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return img;
	}
	/**
	 * Method To validate Product Line
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String validateProductLine(String Line,String wc, String sharedWC, String ScreenshotRequire) throws InterruptedException{
		try
		{	
			System.out.println("inside validateProductLine function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(4000);
			Common.isElementDisplayed(driver, ELXHeader, IConstants.MEDIUM_WAIT_TIME);
			String [] splits=null;
			if(sharedWC.contains(";")) {

				splits=common.splitValues(sharedWC,";");
				for(int i=0;i<splits.length;i++) {
					Assert.assertTrue(ProductionLineNo.get(i).getText().trim().contains(splits[i].trim()),"Line Details are not matching");
					WebTestCase.getTest().log(LogStatus.INFO, "Verified the Line details are appearing for shared WC:: "+ProductionLineNo.get(i).getText()+ common.captureScreenshot(ScreenshotRequire));

				}

			}else if(ELXHeader.getText().contains(Line)) {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Main operation page is  displayed successfuly for non shared WC"+ common.captureScreenshot(ScreenshotRequire));
				System.out.println("Main operation title:"+ELXHeader.getText());
			}
			driver.switchTo().defaultContent();
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);
	}

}