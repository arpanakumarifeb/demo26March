package com.web.elx.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import com.elx.common.Common;

import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class HelpPOPage {
	String getOrderNumber;
	//-----Help Request from PO login-----
	@FindBy(xpath = "//span[@id='ELX_Header_Information']")
	private WebElement pageTitle;
	
	@FindBy(xpath = "//span[@id='spanOrderName']")
	private WebElement orderNumber;
	
	@FindBy(xpath = "//div[@class='ELX_Button_Help']")
	private WebElement helpButton;
	
	@FindBy(xpath ="//div[@class='ELX_Header']")
	private WebElement helpReasonTitle;
	
	@FindBy(xpath ="//*[@class='Content Level1']/div/div[2]/div/span")
	private WebElement meterialIssuesTab;
	
	@FindBy(xpath = "//div[@class='ELX_Header']/div/span")
	private WebElement titleMaterialIssue;
	
	@FindBy(xpath ="//*[@class='Content Level2']/div/div[2]/div/span")
	private WebElement wrongMaterialTab;
	

	
	public WebDriver driver;
	private Common common;
	
	public HelpPOPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}
	
	//Help request from PO login
	
	public void clickHelp(String title, String ScreenshotRequire){
		
		try {
		common.switchToFrame(By.xpath("//iframe[@class='apr-fullscreen-tab']"), IConstants.HIGH_WAIT_TIME);
		common.waitForElementToBeDisplayed(pageTitle, IConstants.SYS_WAIT_TIME);
		Thread.sleep(10000);
		//Validate Title
		Common.isElementDisplayed(driver, pageTitle, IConstants.SYS_WAIT_TIME);
		WebTestCase.getTest().log(LogStatus.INFO, "Verify the page title");
		Assert.assertEquals(pageTitle.getText(), title,  "Screen is not displayed");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Help request screen is displayed successfully"+ common.captureScreenshot(ScreenshotRequire));
		//Click Help button
		Common.isElementDisplayed(driver, orderNumber, IConstants.SYS_WAIT_TIME);
		WebTestCase.getTest().log(LogStatus.INFO, "Verify order number is displayed");
		Assert.assertTrue(orderNumber.isDisplayed(),  "Order Number is not displayed");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number is displayed successfully"+ common.captureScreenshot(ScreenshotRequire));
		Common.isElementDisplayed(driver, helpButton, IConstants.SYS_WAIT_TIME);
		WebTestCase.getTest().log(LogStatus.INFO, "Verify Help button is displayed");
		Assert.assertTrue(helpButton.isDisplayed(), "Help button not displayed");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Help button is displayed successfully"+ common.captureScreenshot(ScreenshotRequire));
		helpButton.click();
		Thread.sleep(10000);
		//Validate Help Reason screen is displayed
		Common.isElementDisplayed(driver, helpReasonTitle, IConstants.SYS_WAIT_TIME);
		WebTestCase.getTest().log(LogStatus.INFO, "Verify Help Reason screen is displayed");
		Assert.assertTrue(helpReasonTitle.isDisplayed(), "Help-Reason screen not displayed");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Help-Reason screen is displayed successfully"+ common.captureScreenshot(ScreenshotRequire));
		WebTestCase.getTest().log(LogStatus.INFO, "Verify Meterial Issues Tab is displayed");
		Assert.assertTrue(meterialIssuesTab.isDisplayed(), "Meterial Issues Tab is not displayed");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Meterial Issues Tab is displayed successfully"+ common.captureScreenshot(ScreenshotRequire));
		meterialIssuesTab.click();
		Thread.sleep(10000);
		//Validate Help-Reason Issue screen is displayed
		Common.isElementDisplayed(driver, titleMaterialIssue, IConstants.SYS_WAIT_TIME);
		Assert.assertTrue(titleMaterialIssue.isDisplayed(), "Help-Reason Issue screen not displayed.");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Help-Reason Issue screen is displayed "+ common.captureScreenshot(ScreenshotRequire));
		Common.isElementDisplayed(driver, wrongMaterialTab, IConstants.SYS_WAIT_TIME);
		Assert.assertTrue(wrongMaterialTab.isDisplayed(), "Wrong Material Tab is not displayed.");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Meterial Issues Tab is displayed "+ common.captureScreenshot(ScreenshotRequire));
		wrongMaterialTab.click();
		Thread.sleep(10000);
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Help request raised successfully"+ common.captureScreenshot(ScreenshotRequire));
		
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
					Assert.fail(exp1.getMessage());
			}
			catch(Exception exp2){
				
				WebTestCase.getTest().log(LogStatus.FAIL,
						exp2.getMessage() + common.captureScreenshot("true"));
				Assert.fail(exp2.getMessage());
			}
	}
	


}
