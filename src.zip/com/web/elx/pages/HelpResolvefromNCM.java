package com.web.elx.pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;

import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class HelpResolvefromNCM {
	
	public WebDriver driver;
	private Common common;
	
	public HelpResolvefromNCM(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}
	//-----Help Resolve from SV login-----
		//NC Title
		@FindBy(xpath = "//li[text()='Non-Conformity List']")
		private WebElement ncTitle;
		
		//Reason Code
		@FindBy(xpath = "//span[@class='NoValue']")
		private WebElement reasonCode;
		
		//Reason class Help 
		@FindBy(xpath = "//span[text()='HELP']")
		private WebElement reason;
		
		//Line
		@FindBy(xpath ="//*[contains(@id, 'content_BC_')]/tr[2]/td[7]")
		private WebElement line;
		
		//Work Center
		@FindBy(xpath ="//*[contains(@id, 'content_BC_')]/tr[2]/td[8]")
		private WebElement workCenter;
		
		//ordNum Textbox
			@FindBy(xpath = "//input[@data-field='productionordernolist']")
			private WebElement ordTextbox;
		
		//Order Number first row
			@FindBy(xpath = "//*[contains(@id, 'content_BC_')]/tr[2]/td[9]")
			private WebElement ordNumber;

		//Reason Class Help Textbox
			@FindBy(xpath = "//input[@data-field='reasonclass']")
			private WebElement reasonClassTextbox;
			
		//Reason Class Help status from first row	
		@FindBy(xpath = "//*[contains(@id, 'content_BC_')]/tr[2]/td[6]")
		private WebElement help;
		
		//Status Help
		@FindBy(xpath ="//*[contains(@id, 'content_BC_')]/tr[2]/td[13]")
		private WebElement helpStatus;
		
		
		//NC Rumber First row
		@FindBy(xpath = "//*[contains(@id, 'content_BC_')]/tr[2]/td")
		private WebElement ncIdnum;
		
		//Create On Date
		@FindBy(xpath = "//*[contains(@id, 'BC_')]/div[2]/div[1]/table/thead/tr[2]/td[14]/div[1]/span[1]/span/input")
		private WebElement createOnButton;
		
		
		//NC Detail Button
			@FindBy(xpath ="//*[@class='ToolButton DETAILS ELX_BigSize Primary']")
			private WebElement ncDetailButton;
		
		//NC Detail Button;
		@FindBy(xpath ="//*[text()='NC Details']")
		private WebElement ncDetailsButton;
		
		//Resolve Button
			@FindBy(xpath ="//button[@value='RESOLVE_VALIDATION']")
			private WebElement resolveButton;
			
		//Popup No button	
			@FindBy(xpath ="//*[@id='ctl03_ClientSFContainer']/div[4]/div/div[2]/div/div/div[3]/button/span")
			private WebElement noButton;
			
		//Popup Yes button	
			@FindBy(xpath ="//*[@class='ButtonList ELX_BigSize']")
			private WebElement yesButton;
			
		//Return
			@FindBy(xpath ="//span[@title='Return']")
			private WebElement returnButton;
			
		
		//Reason Cause
			@FindBy(xpath ="//input[@data-field='rootcausereasoncodelist']")
			private WebElement reasonCauseTestbox;
			
		//Order No
		@FindBy(xpath="//*[@class='Control fc_WipOrderNo Bold']")
		private WebElement orderNo;		
			
			//Status Filter	
			@FindBy(xpath ="//tr[@class='HeadF']/td[13]/div/span/span/a")
			private WebElement statusFilter;
			
			@FindBy(xpath ="//*[@class='Items']/tr[1]/td/div")
			private WebElement statusNew;
			
			@FindBy(xpath ="//*[@class='Items']/tr[4]/td/div")
			private WebElement statusClosed;
			
			@FindBy(xpath ="//*[@aria-describedby='ui-id-1']/div[2]/div/div/button")
			private WebElement statusFilterButton;
			
			@FindBy(xpath ="//*[@aria-describedby='ui-id-1']/div[3]/div/button")
			private WebElement statusOkButton;
			
			
	
	//Validate Help request in NCM screen
			
			public void validateHelpinNCM(String reasonCls, String OrdNum, String lineArea, String workArea, String newSts, String closeSts, String ScreenshotRequire) throws InterruptedException{
			//public void validateHelpinNCM(String OrdNum) throws InterruptedException{
			try {
			common.switchToFrame(By.xpath("//iframe[@class='apr-fullscreen-tab']"), IConstants.HIGH_WAIT_TIME);
				common.waitTillElementDisappears(By.xpath("//div[@class='Toolbox Top Loading']"), IConstants.SYS_WAIT_TIME );
				//Enter the Reason Class
				Common.isElementDisplayed(driver, reasonClassTextbox, IConstants.SYS_WAIT_TIME);
				Assert.assertTrue(reasonClassTextbox.isDisplayed(), "Reason Class Textbox not displayed");
				WebTestCase.getTest().log(LogStatus.INFO, "Enter the Reason Class");
				reasonClassTextbox.sendKeys(reasonCls);
				WebTestCase.getTest().log(LogStatus.INFO, "Reason Class value is entered "+ common.captureScreenshot(ScreenshotRequire));
				
				//Enter Order#
				Common.isElementDisplayed(driver, ordTextbox, IConstants.SYS_WAIT_TIME);
				Assert.assertTrue(ordTextbox.isDisplayed(), "Order# Textbox not displayed");
				WebTestCase.getTest().log(LogStatus.INFO, "Enter the Order Number");
				ordTextbox.sendKeys(OrdNum);
				WebTestCase.getTest().log(LogStatus.INFO, "Order Number is entered");
				Common.isElementDisplayed(driver, ordTextbox, IConstants.SYS_WAIT_TIME);
				ordTextbox.sendKeys(Keys.ENTER);
				common.waitTillElementDisappears(By.xpath("//div[@class='Toolbox Top Loading']"), IConstants.SYS_WAIT_TIME );
				Assert.assertEquals(ordNumber.getText(), OrdNum,  "Order Number is not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order Number is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
				//Validate Line Number
				common.waitTillElementDisappears(By.xpath("//div[@class='Toolbox Top Loading']"), IConstants.SYS_WAIT_TIME );
				Common.isElementDisplayed(driver, line, IConstants.SYS_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.INFO, "Verify the Line");
				Assert.assertEquals(line.getText(), lineArea,  "Line is not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Line is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
			
				//Validate Work Center Number
				common.waitTillElementDisappears(By.xpath("//div[@class='Toolbox Top Loading']"), IConstants.SYS_WAIT_TIME );
				Common.isElementDisplayed(driver, workCenter, IConstants.SYS_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.INFO, "Verify the Work Center");
				Assert.assertEquals(workCenter.getText(), workArea,  "Work Center is not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Work Center is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
				//Validate Status New
				common.waitTillElementDisappears(By.xpath("//div[@class='Toolbox Top Loading']"), IConstants.SYS_WAIT_TIME );
				common.scrollIntoViewPage(helpStatus);
				Common.isElementDisplayed(driver, helpStatus, IConstants.SYS_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.INFO, "Verify the Order Status");
				Assert.assertEquals(helpStatus.getText(), newSts,  "Status is not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Status 'New' is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
				//Resolve the Help
				common.waitTillElementDisappears(By.xpath("//div[@class='Toolbox Top Loading']"), IConstants.HIGH_WAIT_TIME );
				Common.isElementDisplayed(driver, help, IConstants.HIGH_WAIT_TIME);
				Assert.assertTrue(help.isDisplayed(), "Help not available");
				common.click(help);
				Common.isElementDisplayed(driver, ncDetailsButton, IConstants.SYS_WAIT_TIME);
				Assert.assertTrue(ncDetailsButton.isEnabled(), "NC Details button is disabled");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Details button is enabled"+ common.captureScreenshot(ScreenshotRequire));
				WebTestCase.getTest().log(LogStatus.INFO, "Click on NC Details button");
				common.click(ncDetailsButton);
				Common.isElementDisplayed(driver, orderNo, IConstants.SYS_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.INFO, "Verify the Order Number");
				Assert.assertEquals(orderNo.getText(), OrdNum, "Order Number is invalid");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order Number is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
				Common.isElementDisplayed(driver, resolveButton, IConstants.HIGH_WAIT_TIME);
				//Thread.sleep(10000);
				Assert.assertTrue(resolveButton.isDisplayed(),"Resolve button is not displayed");
				//WebTestCase.getTest().log(LogStatus.PASS, "Verified - Resolve button is displayed as expected"+ common.captureScreenshot());
				WebTestCase.getTest().log(LogStatus.INFO, "Select Resolve button");
				common.click(resolveButton);
				Common.isElementDisplayed(driver, yesButton, IConstants.SYS_WAIT_TIME);
				Assert.assertTrue(yesButton.isDisplayed(),"Reslove confirmation button is not displayed");
				yesButton.click();
				Thread.sleep(18000);
				//Validate Status after resolved
				common.waitTillElementDisappears(By.xpath("//div[@class='Toolbox Top Loading']"), IConstants.SYS_WAIT_TIME );
				common.scrollIntoViewPage(helpStatus);
				Common.isElementDisplayed(driver, helpStatus, IConstants.MEDIUM_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.INFO, "Verify the Order status after resolve the help request");
				Assert.assertEquals(helpStatus.getText(), closeSts,  "Status is not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Status 'Closed' is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
				WebTestCase.getTest().log(LogStatus.INFO, "Help request resolved successfully");
				}
				catch(java.lang.AssertionError exp1){
					System.out.println("Got Assertion Error..");
					WebTestCase.getTest().log(LogStatus.FAIL,
							exp1.getMessage() + common.captureScreenshot("true"));
							Assert.fail(exp1.getMessage());
					}
					catch(Exception exp2){
						
						WebTestCase.getTest().log(LogStatus.FAIL,
								exp2.getMessage() + common.captureScreenshot("true"));
						Assert.fail(exp2.getMessage());
					}
			
			}


}
