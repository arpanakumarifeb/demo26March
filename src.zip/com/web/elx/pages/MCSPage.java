package com.web.elx.pages;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.elx.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;


public class MCSPage {


	public WebDriver driver;
	private Common common;
	ReadConfig testData = new ReadConfig();
	SoftAssert softAssert = new SoftAssert();

	public MCSPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}


	@FindBy(xpath = "//li[@title='MCS']")
	private WebElement mcsPageTitle;

	@FindBy(xpath = ".//i[@class='wux-ui-3ds wux-ui-3ds-flow-cascade']")
	private WebElement leftTreeLink; 

	@FindBy(xpath =".//td[@data-value='KI']//span[not(contains(@class, 'ExpandIcon close'))]")
	private WebElement KILink;

	@FindBy(xpath = ".//div[@class='ELX_MCS_ActualProduction_Numbers']//span[not(@id)]")
	private List <WebElement> ActualProduction_NumbersList;


	@FindBy(xpath = ".//div[@class='Container vpBody']/table//tr/td[@data-field='displaywiporderno']//span")
	private List <WebElement> displaywipordernoList;

	@FindBy(xpath = ".//div[@class='Container vpBody']")
	private WebElement ContainerList;



	@FindBy(xpath = ".//tr[@class='HeadT']/td[@data-field='displaywiporderno']/div[contains(@class,'auto')]")
	private WebElement wipOrder;

	@FindBy(xpath = ".//tr[@class='HeadT']/td[@data-field='operationstatusdesc']/div[not(contains(@class, 'gripper'))]")
	private WebElement OprStatus;

	@FindBy(xpath = ".//button[@data-key='RefreshData']")
	private WebElement RefreshDataLink;	

	@FindBy(xpath = ".//tr/td[@data-field='operationstatusdesc']//span[text()='On Hold']/../../..//td[@data-field='productno']//span")
	private WebElement onHoldProductNo;	

	@FindBy(xpath = ".//tr/td[@data-field='operationstatusdesc']//span[text()='On Hold']/../../..//td[@data-field='productno']//span")
	private List <WebElement> onHoldProductNoList;

	@FindBy(xpath = ".//tr/td[@data-field='operationstatusdesc']//span[text()='New']/../../..//td[@data-field='productno']//span")
	private List <WebElement> NewProductNoList;

	@FindBy(xpath = ".//div[@class='Container vpBody']/table//tr/td[@data-field='operationstatusdesc']//span")
	private  List <WebElement> operationstatusdescList;

	@FindBy(xpath = ".//div[@class='Container vpBody']/table//tr/td[@data-field='productno']//span")
	private  List <WebElement> operationProductList;

	@FindBy(xpath = ".//td[@class='Control fc_DisplayWipOrderNo']/span")
	private WebElement DisplayWipOrderNo;

	@FindBy(xpath = ".//td[@class='Control fc_OprSequenceNo']/span")
	private WebElement OprSequenceNo;

	@FindBy(xpath = ".//td[@class='Control fc_ProductNo']/span")
	private WebElement fc_ProductNo;

	@FindBy(xpath = ".//td[@class='Control fc_QuantityCompletedTarget']/span")
	private WebElement QuantityCompletedTarget;

	@FindBy(xpath = ".//button[@value='REPORT_SCRAP']")
	private WebElement REPORT_Btn_homepage;

	@FindBy(xpath = ".//div[@class='ELX_MCS_ActualProduction_Numbers']")
	private WebElement ELX_MCS_ActualProduction_Numbers;

	@FindBy(xpath = ".//span[@id='spanDoneQty']")
	private WebElement DoneQty;

	@FindBy(xpath = ".//span[@id='spanToDoQty']")
	private WebElement ToDoQty;	


	@FindBy(xpath = ".//td[@class='Control fc_WC_Equipment']/span")
	private WebElement DisplayEquipmentDetails; 

	@FindBy(xpath = ".//td[@class='Control fc_OperationStatusDesc']/span")
	private WebElement OperationStatusDesc; 


	@FindBy(xpath = "//button[@value='HOLD']/span")
	private WebElement HoldBtn; 

	//@FindBy(xpath = "//button[@data-key='START' and not(@disabled)]/span")
	@FindBy(xpath = "//button[@data-key='START']/span")
	private WebElement startBtn; 


	@FindBy(xpath = "//button/span[contains(@class,'translation')]")
	private WebElement holdButtonOnPopup;

	@FindBy(xpath = "(//div[contains(@class,'ELX_Table_CellNoBorder')])[2]")
	private WebElement orderDetailsOnPopup;

	@FindBy(xpath = ".//div[@class='apr-message-error']")
	private WebElement errMessage;

	@FindBy(xpath = ".//div[contains(@class,'apr-message-item')]")
	private WebElement errMessageDiv;


	@FindBy(xpath = "(//div[@class='circularGauge-gauge-value-label']/span)[1]")
	private WebElement circularGauge;

	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";
	String startbtn="//button[@data-key='START']/span";
	String reportbtn=".//button[@value='REPORT_SCRAP']";

	@FindBy(xpath = ".//input[@data-field='reasonclass']")
	private  WebElement reasonclass;
	@FindBy(xpath = "//*[@title='Home']")
	private  WebElement homeIcon	;

	@FindBy(xpath = ".//td[contains(@class,'Label fl_')]")
	private List <WebElement> mcsScreenLabel;

	@FindBy(xpath = ".//h2[@class='Label FormHead Collapsed']")
	private  WebElement LabelFormHeadCollapsed	;


	@FindBy(xpath = ".//*[contains(@class,'Control fc_ExpectedStartDate')]/span")
	private WebElement ExpectedStartDate;

	@FindBy(xpath = ".//*[contains(@class,'Control fc_ExpectedCompletionDate')]/span")
	private WebElement ExpectedCompletionDate;


	@FindBy(xpath = ".//td[contains(@class,'Control fc_ActualStartDate')]/span")
	private WebElement ActualStartDate;


	@FindBy(xpath = ".//*[@class='apr-popup-head']")
	private  WebElement ReportPopUpTitle	;

	@FindBy(xpath = ".//*[@id='txtProductionOrderGoodQtyInput']")
	private  WebElement txtProductionOrderGoodQtyInput	;

	@FindBy(xpath = ".//*[@id='txtProductionOrderScrapQtyInput']")
	private  WebElement txtProductionOrderScrapQtyInput	;

	@FindBy(xpath = ".//*[@id='txtProductionOrderReverseQtyInput']")
	private  WebElement txtProductionOrderReverseQtyInput	;

	@FindBy(xpath = ".//button[@id='Classify']")
	private  WebElement ReportBtnPopUp	;

	@FindBy(xpath = ".//*[@class='close fa fa-close']")
	private  WebElement ReportBtnPopUpClose	;

	@FindBy(xpath = ".//*[contains(@class,'UIServiceBody')]")
	private  WebElement UIServiceBody	;

	@FindBy(xpath = ".//button[contains(@class,'ELX_NCMReasonCode')]")
	private List <WebElement> reasonCodeLevel;

	@FindBy(xpath = ".//button[contains(@class,'ELX_NCMReasonCode')]")
	private WebElement reasonCode;

	@FindBy(xpath = "//span[@class='ExpandIcon close']")
	private List <WebElement> ExpandIconList;

	@FindBy(xpath = "//span[@class='ExpandIcon close']")
	private  WebElement ExpandIcon;

	@FindBy(xpath = ".//td[contains(@class,'Label fl_UnitMachineLabel')]")
	private  WebElement machineLabel;

	@FindBy(xpath = ".//div[contains(@class,'ELX_ReportingInfoChart')]/p[4]")
	private WebElement ReportedQtyGoodScrap;

	@FindBy(xpath = ".//div/span[@data-flx-literal='ELX_MCS_MenuItems_Pallet']")
	private WebElement palletLink;

	String palletlink=".//div/span[@data-flx-literal='ELX_MCS_MenuItems_Pallet']";


	@SuppressWarnings("static-access")
	public void validateMCSPageTitle(String title, String ScreenshotRequire) throws InterruptedException{
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(8000);
			Assert.assertEquals(mcsPageTitle.getText(), title,  "MCS page not displayed");
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	public void clickOnLeftTree(String ScreenshotRequire)
	{	System.out.println("Clicked on left tree on MCS screen");
	try
	{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, leftTreeLink, IConstants.SYS_WAIT_TIME);
		Thread.sleep(5000);
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Left Tree Panel1 is displaying on MCS screen"+ common.captureScreenshot(ScreenshotRequire));
		common.clickOnObject(leftTreeLink, "leftTreeLink");
		driver.switchTo().defaultContent();
	}

	catch(java.lang.AssertionError exp1){
		System.out.println("Got Assertion Error.."+exp1);
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp1.getMessage() + common.captureScreenshot("true"));
	}
	catch(Exception exp2){		
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp2.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp2.getMessage());
	}
	}

	public void clickOnMCSPage(String ScreenshotRequire)
	{
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, mcsPageTitle, IConstants.SYS_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - MCS Screen clicked"+ common.captureScreenshot(ScreenshotRequire));
			common.clickOnObject(mcsPageTitle, "mcsPageTitle");
			driver.switchTo().defaultContent();
		}

		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	public void clickOnKILInk(String ScreenshotRequire)
	{System.out.println("Clicked on left tree KI link on MCS screen");
	try
	{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, KILink, IConstants.SYS_WAIT_TIME);
		Thread.sleep(10000);
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - KI link displaying on MCS screen"+ common.captureScreenshot(ScreenshotRequire));
		//common.clickOnObject(KILink, "KILink");
		JavascriptExecutor js = (JavascriptExecutor)driver; 
		js.executeScript("arguments[0].click();", KILink);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		driver.switchTo().defaultContent();
	}

	catch(java.lang.AssertionError exp1){
		System.out.println("Got Assertion Error.."+exp1);
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp1.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp1.getMessage());
	}
	catch(Exception exp2){		
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp2.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp2.getMessage());
	}
	}

	public void expandAllCloseIcon(String ScreenshotRequire)
	{
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(10000);
			for(int i=0;i<=ExpandIconList.size();i++) {
				Common.isElementDisplayed(driver, ExpandIconList.get(i), IConstants.SYS_WAIT_TIME);
				common.clickOnObject(ExpandIconList.get(i), ExpandIconList.get(i).getText());
			}

			WebTestCase.getTest().log(LogStatus.INFO, "Expand all Expand Icon on Left Tree"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}

		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	public void clickOnTechnologyAreaLink(String techArea, String ScreenshotRequire)
	{System.out.println("Clicked on techArea on MCS screen "+ techArea);
	try
	{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Thread.sleep(20000);
		WebElement techAreaOption=driver.findElement(By.xpath("//*[contains(text(),'"+techArea+"')]"));
		Common.isElementDisplayed(driver, techAreaOption, IConstants.SYS_WAIT_TIME);
		JavascriptExecutor js = (JavascriptExecutor)driver; 
		js.executeScript("arguments[0].click();", techAreaOption);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		WebTestCase.getTest().log(LogStatus.INFO, "Verified the " +techArea +" item is present and clicked"+ common.captureScreenshot(ScreenshotRequire));
		driver.switchTo().defaultContent();
	}

	catch(java.lang.AssertionError exp1){
		System.out.println("Got Assertion Error.."+exp1);
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp1.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp1.getMessage());
	}
	catch(Exception exp2){		
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp2.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp2.getMessage());
	}
	}

	public void validateTechnologyAreaLink(String techArea, String ScreenshotRequire)
	{
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(10000);
			WebElement techAreaOption=driver.findElement(By.xpath("//*[contains(text(),'"+techArea+"')]"));
			Common.isElementDisplayed(driver, techAreaOption, IConstants.SYS_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.INFO, "Verified the " +techArea +" item is present"+ common.captureScreenshot(ScreenshotRequire));
			WebElement closeIconLink=driver.findElement(By.xpath("//span[contains(text(),'"+techArea+"')]/..//span[@class='ExpandIcon close']"));
			if(closeIconLink.isDisplayed())
			{
				common.clickOnObject(closeIconLink, "closeIconLink");
			}
			driver.switchTo().defaultContent();
		}

		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	public void collapseTechnologyAreaLink(String techArea, String ScreenshotRequire)
	{
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(10000);
			WebElement techAreaOption=driver.findElement(By.xpath("//*[contains(text(),'"+techArea+"')]"));
			Common.isElementDisplayed(driver, techAreaOption, IConstants.SYS_WAIT_TIME);
			WebElement openIconLink=driver.findElement(By.xpath("//span[contains(text(),'"+techArea+"')]/..//span[@class='ExpandIcon open']"));
			if(openIconLink.isDisplayed())
			{
				common.clickOnObject(openIconLink, "openIconLink");
			}
			driver.switchTo().defaultContent();
		}

		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	public void clickOnMachineNameLink(String machineName, String ScreenshotRequire)
	{	System.out.println("Clicked on machineName on MCS screen: "+ machineName);
	try
	{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Thread.sleep(6000);
		WebElement machineNameOption=driver.findElement(By.xpath("//*[contains(text(),'"+machineName+"')]"));
		Common.isElementDisplayed(driver, machineNameOption, IConstants.SYS_WAIT_TIME);			
		WebTestCase.getTest().log(LogStatus.INFO, "Verified the " +machineName +" item is present"+ common.captureScreenshot(ScreenshotRequire));
		JavascriptExecutor js = (JavascriptExecutor)driver; 
		js.executeScript("arguments[0].click();", machineNameOption);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
		driver.switchTo().defaultContent();
	}

	catch(java.lang.AssertionError exp1){
		System.out.println("Got Assertion Error.."+exp1);
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp1.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp1.getMessage());
	}
	catch(Exception exp2){		
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp2.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp2.getMessage());
	}
	}

	public void validateMachineNameLink(String machineName, String ScreenshotRequire)
	{
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(6000);
			WebElement machineNameOption=driver.findElement(By.xpath("//*[contains(text(),'"+machineName+"')]"));
			Common.isElementDisplayed(driver, machineNameOption, IConstants.SYS_WAIT_TIME);			
			WebTestCase.getTest().log(LogStatus.INFO, "Verified the " +machineName +" is present in MCS Screen"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}

		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To verifyOrderStatus and validate to start another order
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public int verifyOrderStatus(String techArea, String machineName, String ScreenshotRequire) throws InterruptedException{
		int listSize=0;
		try{
			System.out.println("inside verifyOrderStatus function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(25000);
			Common.isElementDisplayed(driver, ContainerList, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",wipOrder);
			common.isElementDisplayed(driver, wipOrder, IConstants.MEDIUM_WAIT_TIME);
			listSize=displaywipordernoList.size();		
			int counter=0;
			js.executeScript("arguments[0].scrollIntoView();",OprStatus);
			common.isElementDisplayed(driver, wipOrder, IConstants.MEDIUM_WAIT_TIME);
			String orderID=null;			
			for(int i=0;i<listSize;i++) {
				if((operationstatusdescList.get(i).getAttribute("innerHTML").contains("Started"))){
					WebTestCase.getTest().log(LogStatus.INFO, DisplayWipOrderNo.getText() +" ----"+displaywipordernoList.get(i).getText()+ common.captureScreenshot(ScreenshotRequire));
					Assert.assertEquals(DisplayWipOrderNo.getText(), displaywipordernoList.get(i).getText(),"WIP Order number is not coming correctly on Header section.");
					Assert.assertEquals(OperationStatusDesc.getText(), operationstatusdescList.get(i).getText(),"WIP status is not coming correctly on Header section.");
					WebTestCase.getTest().log(LogStatus.INFO, DisplayWipOrderNo.getText() +" Order number is displaying as started"+ common.captureScreenshot(ScreenshotRequire));
					counter++;
					orderID=DisplayWipOrderNo.getText();
				}
			}			
			if(counter==1) {
				WebTestCase.getTest().log(LogStatus.PASS, "WIP Order number <b>"+orderID+"</b> is showing in MCS screen as started status"+ common.captureScreenshot(ScreenshotRequire));
				// checking if we can make another order to start

				/*for(int i=0;i<operationstatusdescList.size();i++) {

					if((operationstatusdescList.get(i).getText().contains("New"))||(operationstatusdescList.get(i).getText().contains("Off-Hold"))){	
						common.clickOnObject(operationstatusdescList.get(i), "order selected");
						String OrderStatusbeforeStartClick=operationstatusdescList.get(i).getText();
						if(startBtn.isDisplayed()) {
							System.out.println("click on start");
							common.clickOnObject(startBtn, "startBtn");
							System.out.println("clicked on start button***********");
						}else {
							System.out.println("click on refresh btn");
							operationstatusdescList.get(i).click();
							common.clickOnObject(startBtn, "startBtn");
							System.out.println("enabled and clicked on start******");
						}
						String OrderStatusAfterStartClick=operationstatusdescList.get(i).getText();
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME);
						Thread.sleep(10000);
						WebTestCase.getTest().log(LogStatus.INFO, "Verified - Clicked on start button to start any another order.");
						//WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing while starting another order :<b>"+errMessage.getText()+"</b> for:"+techArea+">>"+machineName+ common.captureScreenshot(ScreenshotRequire));
						//Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing while starting another order");
						Assert.assertEquals(OrderStatusAfterStartClick,OrderStatusbeforeStartClick ,"Order status is wrong");
						break;
					}
				}*/
			}else if(counter<1){
				WebTestCase.getTest().log(LogStatus.PASS, "Display Wip OrderNo: "+DisplayWipOrderNo.getText()+  common.captureScreenshot(ScreenshotRequire));
				Assert.assertTrue(DisplayWipOrderNo.getText().isEmpty(), "WIP order details are showing incorrectly.");
				WebTestCase.getTest().log(LogStatus.PASS, "No any WIP order status is started for:"+techArea+">>"+machineName+  common.captureScreenshot(ScreenshotRequire));
				if(listSize>0){
					common.clickOnObject(operationstatusdescList.get(0), operationstatusdescList.get(0).getText());
					Common.isElementDisplayed(driver, startBtn, 10);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicking on start button"+  common.captureScreenshot(ScreenshotRequire));
					common.clickOnObject(startBtn, "startBtn");
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on start button"+  common.captureScreenshot(ScreenshotRequire));
					WebTestCase.getTest().log(LogStatus.PASS, "WIP order "+DisplayWipOrderNo.getText()+" is started for: "+techArea+">>"+machineName+  common.captureScreenshot(ScreenshotRequire));
				}
			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return listSize;
	}



	/**
	 * Method To verifyStartToHoldOrderStatus
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void verifyStartToHoldOrderStatus(String ScreenshotRequire) throws InterruptedException{
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.isElementDisplayed(driver, wipOrder, IConstants.MEDIUM_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",wipOrder);
			Thread.sleep(4000);	
			Common.isElementDisplayed(driver, ContainerList, IConstants.HIGH_WAIT_TIME);
			int listSize=displaywipordernoList.size();		
			int i;
			js.executeScript("arguments[0].scrollIntoView();",OprStatus);
			Thread.sleep(4000);
			for(i=0;i<listSize;i++) {
				if((operationstatusdescList.get(i).getAttribute("innerHTML").contains("Started"))){
					String OrderNo=displaywipordernoList.get(i).getText();
					common.clickOnObject(RefreshDataLink, "RefreshDataLink");
					driver.findElement(By.xpath(".//tr/td[@data-field='displaywiporderno']//span[text()='"+OrderNo+"']")).click();
					Common.isElementDisplayed(driver, HoldBtn, 10);
					common.clickOnObject(HoldBtn, "HoldBtn");
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					Thread.sleep(4000);
					System.out.println("Verified - hold button clicked");

					common.isElementDisplayed(driver, holdButtonOnPopup, IConstants.HIGH_WAIT_TIME);
					Thread.sleep(4000);
					String OrderNoOnPopup=orderDetailsOnPopup.getText();	

					System.out.println("order number before trim: "+ OrderNoOnPopup);
					js.executeScript("arguments[0].click();", holdButtonOnPopup);
					WebTestCase.getTest().log(LogStatus.INFO, "Verified - Clicked on Hold PopUp Button"+ common.captureScreenshot(ScreenshotRequire));
					Thread.sleep(4000);

					String [] splits=common.splitValues(OrderNoOnPopup,"\\(");

					String oId=splits[0].trim();		
					System.out.println("order number after trim: "+ oId);
					Assert.assertEquals(driver.findElement(By.xpath(".//tr/td[@data-field='displaywiporderno']//span[text()='"+oId+"']/../../..//td[@data-field='operationstatusdesc']")).getText(),"On Hold","WIP status is not coming correctly in order list section.");
					WebTestCase.getTest().log(LogStatus.INFO, "Verified - Order status changed to On Hold:"+driver.findElement(By.xpath(".//tr/td[@data-field='displaywiporderno']//span[text()='"+oId+"']/../../..//td[@data-field='operationstatusdesc']")).getText()+ common.captureScreenshot(ScreenshotRequire));
					/*counter++;
					startedPos=i;
					Assert.assertTrue(DisplayWipOrderNo.getText().isEmpty(), "WIP order details are showing incorrectly.");
					WebTestCase.getTest().log(LogStatus.PASS, "No any WIP order status is started"+ common.captureScreenshot(ScreenshotRequire));*/
				}
			}

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

	}
	/**
	 * Method To verifyHoldToStartOrderStatus
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void verifyHoldToStartOrderStatus(String ScreenshotRequire) throws InterruptedException{
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.isElementDisplayed(driver, wipOrder, IConstants.MEDIUM_WAIT_TIME);
			Common.isElementDisplayed(driver, ContainerList, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",wipOrder);
			Thread.sleep(4000);	
			int listSize=displaywipordernoList.size();		
			int i;
			js.executeScript("arguments[0].scrollIntoView();",OprStatus);
			Thread.sleep(4000);
			for(i=0;i<listSize;i++) {
				if((operationstatusdescList.get(i).getAttribute("innerHTML").contains("On Hold"))){
					String OrderNo=displaywipordernoList.get(i).getText();
					common.clickOnObject(RefreshDataLink, "RefreshDataLink");
					driver.findElement(By.xpath(".//tr/td[@data-field='displaywiporderno']//span[text()='"+OrderNo+"']")).click();
					Common.isElementDisplayed(driver, startBtn, 10);
					common.clickOnObject(startBtn, "startBtn");
					Thread.sleep(7000);
					Assert.assertEquals(operationstatusdescList.get(i).getText(), "Started", "WIP order details are showing incorrectly.");
					Assert.assertEquals(DisplayWipOrderNo.getText(), displaywipordernoList.get(i).getText(), "WIP order details are showing incorrectly.");
					WebTestCase.getTest().log(LogStatus.PASS, "Order has been started :"+displaywipordernoList.get(i).getText()+ common.captureScreenshot(ScreenshotRequire));
					break;
				}
			}

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

	}

	/**
	 * Method To checkOrderStatus
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void checkOrderStatus(String ScreenshotRequire) throws InterruptedException{
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.isElementDisplayed(driver, wipOrder, IConstants.MEDIUM_WAIT_TIME);
			Common.isElementDisplayed(driver, ContainerList, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",wipOrder);
			Thread.sleep(4000);	
			int listSize=displaywipordernoList.size();		
			int counter=0;
			int i;
			int startedPos=0;;
			for(i=0;i<listSize;i++) {
				js.executeScript("arguments[0].scrollIntoView();",operationstatusdescList.get(i));
				Thread.sleep(4000);	

				if((operationstatusdescList.get(i).getAttribute("innerHTML").contains("Started"))){
					Assert.assertEquals(DisplayWipOrderNo.getText(), displaywipordernoList.get(i).getText(),"WIP Order number is not coming correctly on Header section.");
					Assert.assertEquals(OperationStatusDesc.getText(), operationstatusdescList.get(i).getText(),"WIP status is not coming correctly on Header section.");
					WebTestCase.getTest().log(LogStatus.INFO, DisplayWipOrderNo.getText() +" Order number is displaying as started"+ common.captureScreenshot(ScreenshotRequire));
					counter++;
					startedPos=i;
				}

			}

			if(counter==1) {

				//change to hold
				WebTestCase.getTest().log(LogStatus.PASS, "WIP Order number is showing in MCS screen as started status"+ common.captureScreenshot(ScreenshotRequire));
				// checking if we can make another order to start
				if(operationstatusdescList.size()>1) {
					String otherOrderStatus=operationstatusdescList.get(startedPos).getText();	
					//operationstatusdescList.get(startedPos).click();
					common.clickOnObject(operationstatusdescList.get(startedPos), otherOrderStatus);
					//	Common.isElementDisplayed(driver, startBtn, 10);
					if(otherOrderStatus.contains("Started")) {
						common.clickOnObject(startBtn, "startBtn");
						Thread.sleep(7000);
						WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing while starting another order :"+errMessage.getText()+ common.captureScreenshot(ScreenshotRequire));
						Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing while starting another order");
						Assert.assertEquals(operationstatusdescList.get(startedPos).getText(), otherOrderStatus,"Order status is wrong");
					}
				}
				String OrderNo=DisplayWipOrderNo.getText();
				driver.findElement(By.xpath(".//tr/td[@data-field='displaywiporderno']//span[text()='"+OrderNo+"']")).click();
				Common.isElementDisplayed(driver, HoldBtn, 10);
				common.clickOnObject(HoldBtn, "HoldBtn");

				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(8000);
				System.out.println("Verified - hold button clicked");

				common.isElementDisplayed(driver, holdButtonOnPopup, IConstants.HIGH_WAIT_TIME);
				Thread.sleep(4000);
				js.executeScript("arguments[0].click();", holdButtonOnPopup);
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Clicked on Hold PopUp Button"+ common.captureScreenshot(ScreenshotRequire));
				Thread.sleep(8000);
				Assert.assertEquals(driver.findElement(By.xpath(".//tr/td[@data-field='displaywiporderno']//span[text()='"+OrderNo+"']/../../..//td[@data-field='operationstatusdesc']")).getText(),"On Hold","WIP status is not coming correctly in order list section.");
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Order status changed to On Hold:"+driver.findElement(By.xpath(".//tr/td[@data-field='displaywiporderno']//span[text()='"+OrderNo+"']/../../..//td[@data-field='operationstatusdesc']")).getText()+ common.captureScreenshot(ScreenshotRequire));
			}else if(counter<1){
				WebTestCase.getTest().log(LogStatus.PASS, "No any WIP order status is started"+ common.captureScreenshot(ScreenshotRequire));
				Assert.assertTrue(DisplayWipOrderNo.getText().isEmpty(), "WIP order details are showing incorrectly.");
				WebTestCase.getTest().log(LogStatus.PASS, "Clicking on start button"+ common.captureScreenshot(ScreenshotRequire));
				operationstatusdescList.get(startedPos).click();
				Common.isElementDisplayed(driver, startBtn, 10);
				common.clickOnObject(startBtn, "startBtn");
				Thread.sleep(7000);
				Assert.assertEquals(operationstatusdescList.get(startedPos).getText(), "Started", "WIP order details are showing incorrectly.");
				Assert.assertEquals(DisplayWipOrderNo.getText(), displaywipordernoList.get(startedPos).getText(), "WIP order details are showing incorrectly.");
				WebTestCase.getTest().log(LogStatus.PASS, "Order has been started :"+displaywipordernoList.get(startedPos).getText()+ common.captureScreenshot(ScreenshotRequire));
			}

			int counter1=0;
			for(int j=0;j<displaywipordernoList.size();j++) {

				js.executeScript("arguments[0].scrollIntoView();",operationstatusdescList.get(j));
				Thread.sleep(4000);	

				if((operationstatusdescList.get(j).getAttribute("innerHTML").contains("Started"))){
					Assert.assertEquals(DisplayWipOrderNo.getText(), displaywipordernoList.get(j).getText(),"WIP Order number is not coming correctly on Header section.");
					Assert.assertEquals(OperationStatusDesc.getText(), operationstatusdescList.get(j).getText(),"WIP status is not coming correctly on Header section.");
					counter1++;
				}

			}

			if(counter1==0) {

				//changing to start
				WebTestCase.getTest().log(LogStatus.PASS, "All WIP Order status is other than started after clicked on Hold Button"+ common.captureScreenshot(ScreenshotRequire));
				Assert.assertTrue(DisplayWipOrderNo.getText().isEmpty(), "WIP order details are showing incorrectly.");
				operationstatusdescList.get(counter1).click();
				Common.isElementDisplayed(driver, startBtn, 10);
				common.clickOnObject(startBtn, "startBtn");
				Assert.assertEquals(operationstatusdescList.get(counter1).getText(), "Started", "WIP order status are showing incorrectly.");
				Assert.assertEquals(DisplayWipOrderNo.getText(), displaywipordernoList.get(counter1).getText(), "WIP order details are showing incorrectly.");
				WebTestCase.getTest().log(LogStatus.PASS, "Order has been started :"+displaywipordernoList.get(counter).getText()+ common.captureScreenshot(ScreenshotRequire));



			}else {
				//WebTestCase.getTest().log(LogStatus.PASS, "WIP Order status is started"+ common.captureScreenshot(ScreenshotRequire));
			}

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

	}
	/**
	 * Method To verifyOrderStatus
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public HashMap<String, String>  verifyMCSScreenOrderCount(String[][] hm2,int rowCount, String ScreenshotRequire) throws InterruptedException{
		int Startcounter=0;
		int Newcounter=0;
		int Holdcounter=0;
		int OffHoldcounter=0;
		HashMap<String,String> hm1=new HashMap<String,String>();
		String startOrderId=null;
		try{
			System.out.println("inside verifyMCSScreenOrderCount function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);
			common.isElementDisplayed(driver, DisplayEquipmentDetails, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			/*js.executeScript("arguments[0].scrollIntoView();",wipOrder);
			Thread.sleep(4000);	*/

			js.executeScript("arguments[0].scrollIntoView();",OprStatus);
			common.isElementDisplayed(driver, wipOrder, IConstants.MEDIUM_WAIT_TIME);

			Thread.sleep(25000);
			common.isElementDisplayed(driver, ContainerList, IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			System.out.println("displaywipordernoList size: "+ displaywipordernoList.size());
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order list is appearing in MCS page with count: "+displaywipordernoList.size()+ common.captureScreenshot(ScreenshotRequire));
			Thread.sleep(5000);
			for(int i=0;i<displaywipordernoList.size();i++) {
				if((operationstatusdescList.get(i).getAttribute("innerText").contains("Started"))){
					Startcounter++;
					startOrderId=displaywipordernoList.get(i).getText();

				}
				if((operationstatusdescList.get(i).getAttribute("innerText").contains("New"))){
					Newcounter++;
				}
				if((operationstatusdescList.get(i).getAttribute("innerText").contains("On Hold"))){
					Holdcounter++;
				}
				if((operationstatusdescList.get(i).getAttribute("innerText").contains("Off-Hold"))){
					OffHoldcounter++;
				}
			}
			int total=Startcounter+Newcounter+Holdcounter+OffHoldcounter;
			hm1.put("Started", Integer.toString(Startcounter));
			hm1.put("New", Integer.toString(Newcounter));
			hm1.put("Held", Integer.toString(Holdcounter));
			hm1.put("Off-Hold", Integer.toString(OffHoldcounter));
			hm1.put("TotalCount", Integer.toString(total));
			hm1.put("startOrderIdDetails", startOrderId);
			//WebTestCase.getTest().log(LogStatus.PASS, "Total Order Count in MCS screen :"+total+ common.captureScreenshot(ScreenshotRequire));
			WebTestCase.getTest().log(LogStatus.PASS, "Total Start Order Count in MCS screen :"+Startcounter);
			WebTestCase.getTest().log(LogStatus.PASS, "Total New Order Count in MCS screen :"+Newcounter);
			WebTestCase.getTest().log(LogStatus.PASS, "Total Hold Order Count in MCS screen :"+Holdcounter);
			WebTestCase.getTest().log(LogStatus.PASS, "Total Off-Hold Order Count in MCS screen :"+OffHoldcounter);

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return hm1;

	}
	
	/**
	 * Method To verifyMCSScreenStartOrderCount
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public HashMap<String, String>  verifyMCSScreenStartOrderCount(String[][] hm2,int rowCount, String ScreenshotRequire) throws InterruptedException{
		int Startcounter=0;
		HashMap<String,String> hm1=new HashMap<String,String>();
		try{
			System.out.println("inside verifyMCSScreenOrderCount function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);
			common.isElementDisplayed(driver, DisplayEquipmentDetails, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			common.isElementDisplayed(driver, wipOrder, IConstants.MEDIUM_WAIT_TIME);
			Thread.sleep(20000);
			common.isElementDisplayed(driver, ContainerList, IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			System.out.println("displaywipordernoList size: "+ displaywipordernoList.size());
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order list is appearing in MCS page with count: "+displaywipordernoList.size());
			/*js.executeScript("arguments[0].scrollIntoView();",OprStatus);
			Thread.sleep(5000);
			 int j =1;
			for(int i=0;i<displaywipordernoList.size();i++) {
				if((operationstatusdescList.get(i).getText().contains("Started"))){
					Startcounter++;
					hm1.put("startOrderIdDetails"+(j), displaywipordernoList.get(i).getText());
					j++;
				}
				
			}*/
			
			if(DisplayWipOrderNo.getText() != null) {
				hm1.put("StartedDisplayOrder", DisplayWipOrderNo.getText());
				String [] qty=common.splitValues(QuantityCompletedTarget.getText(),"\\/");
				hm1.put("QCompleted", qty[0].trim());
				hm1.put("QTarget", qty[1].trim());
			}else {
				// write code to start order in build pallet..
			}
			WebTestCase.getTest().log(LogStatus.INFO, "Total Start Order Count in MCS screen :"+Startcounter);
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return hm1;

	}

	/**
	 * Method To validateMCSPageOrderDetails
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateMCSPageOrderDetails(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside validateMCSPageOrderDetails function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.isElementDisplayed(driver, DisplayWipOrderNo, IConstants.MEDIUM_WAIT_TIME);

			softAssert.assertEquals(DisplayWipOrderNo.getText(),hmAction.get(1) ,"Order id not displayed correctly in MCS screen");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order id displaying same in MCS and POE Screen:"+ DisplayWipOrderNo.getText()+">>"+hmAction.get(1) );
			softAssert.assertEquals(OprSequenceNo.getText(),hmAction.get(2) ,"Opr seq# not displayed correctly in MCS screen");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Opr seq# displaying same in MCS and POE Screen:"+ OprSequenceNo.getText()+">>"+hmAction.get(2) );
			softAssert.assertEquals(OperationStatusDesc.getText(), hmAction.get(3),"Order status is not displaying correctly in MCS screen");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order status displaying same in MCS and POE Screen:"+ OperationStatusDesc.getText()+">>"+hmAction.get(3) );

			softAssert.assertEquals(fc_ProductNo.getText(), hmAction.get(4),"Product id/Part is not displaying correctly in MCS screen");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Product id/Part displaying same in MCS and POE Screen:"+ fc_ProductNo.getText()+">>"+hmAction.get(4) );

			softAssert.assertTrue(DisplayEquipmentDetails.getText().contains(hmAction.get(7)),"Order equipment details is not displaying correctly in MCS screen");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order equipment displaying same in MCS and POE Screen:"+ DisplayEquipmentDetails.getText()+">>"+hmAction.get(7) );

			String [] qty=common.splitValues(QuantityCompletedTarget.getText(),"\\/");
			String compleqty=qty[0].trim();
			String trgtqty=qty[1].trim();

			softAssert.assertEquals(trgtqty,hmAction.get(8),"Order target quantity is not displaying correctly in MCS screen");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order target quantity displaying in MCS and POE Screen:"+ trgtqty+">>"+hmAction.get(8) );

			softAssert.assertEquals(compleqty,hmAction.get(9),"Order completed quantity is not displaying correctly in MCS screen");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order completed quantity is displaying in MCS and POE Screen:"+ compleqty+">>"+hmAction.get(9) );


			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

	}

	/**
	 * Method To verifyReportProductionPage
	 * @author Arpana
	 * @return 
	 * @throws InterruptedException 
	 */
	public boolean verifyReportProductionPage(Hashtable<String, String> data, String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside verifyReportProductionPage function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(30000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			int counter=0;
			Common.isElementDisplayed(driver, ContainerList, IConstants.HIGH_WAIT_TIME);
			for(int i=0;i<displaywipordernoList.size();i++) {
				if((operationstatusdescList.get(i).getAttribute("innerHTML").contains("Started"))){
					Assert.assertEquals(DisplayWipOrderNo.getText(), displaywipordernoList.get(i).getText(),"WIP Order number is not coming correctly on Header section.");
					Assert.assertEquals(OperationStatusDesc.getText(), operationstatusdescList.get(i).getText(),"WIP status is not coming correctly on Header section.");
					WebTestCase.getTest().log(LogStatus.INFO, DisplayWipOrderNo.getText() +" Order number is displaying as started"+ common.captureScreenshot(ScreenshotRequire));
					counter++;
					break;
				}
			}
			if(counter==1) {
				//WebTestCase.getTest().log(LogStatus.PASS, "WIP Order number is showing in MCS screen as started status"+ common.captureScreenshot(ScreenshotRequire));
			}else if(counter<1){
				Assert.assertTrue(DisplayWipOrderNo.getText().isEmpty(), "WIP order details are showing incorrectly.");
				WebTestCase.getTest().log(LogStatus.PASS, "No any WIP order status is started"+ common.captureScreenshot(ScreenshotRequire));
				operationstatusdescList.get(1).click();
				Common.isElementDisplayed(driver, startBtn, 10);
				common.clickOnObject(startBtn, "startBtn");
				WebTestCase.getTest().log(LogStatus.PASS, "Clicked on start button"+ common.captureScreenshot(ScreenshotRequire));
				Thread.sleep(7000);
			}
			if(DisplayWipOrderNo.getText() != null) {
				Common.isElementDisplayed(driver, REPORT_Btn_homepage, IConstants.HIGH_WAIT_TIME);
				common.highLighterMethod(driver,REPORT_Btn_homepage);
				js.executeScript("arguments[0].click();", REPORT_Btn_homepage);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				//validating textboxes in Report production page.
				Common.isElementDisplayed(driver, ReportPopUpTitle, IConstants.LOW_WAIT_TIME);
				Common.isElementDisplayed(driver, txtProductionOrderGoodQtyInput, IConstants.LOW_WAIT_TIME);
				Common.isElementDisplayed(driver, txtProductionOrderScrapQtyInput, IConstants.LOW_WAIT_TIME);
				Common.isElementDisplayed(driver, txtProductionOrderReverseQtyInput, IConstants.LOW_WAIT_TIME);

				txtProductionOrderGoodQtyInput.sendKeys(data.get("MCSScreenReportValue"));
				txtProductionOrderScrapQtyInput.sendKeys(data.get("MCSScreenReportValue"));
				txtProductionOrderReverseQtyInput.sendKeys(data.get("MCSScreenReportValue"));
				js.executeScript("arguments[0].click();", ReportBtnPopUp);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				WebTestCase.getTest().log(LogStatus.PASS,"Report Popup Button clicked");
				Common.isElementDisplayed(driver, errMessage, IConstants.LOW_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.PASS, "Input value on Good, Scrap and Reverse values together, Error Message :<b>"+errMessage.getText()+"</b>"+ common.captureScreenshot(ScreenshotRequire));

				txtProductionOrderGoodQtyInput.clear();
				txtProductionOrderScrapQtyInput.clear();
				txtProductionOrderGoodQtyInput.sendKeys(data.get("MCSScreenReportValue"));
				txtProductionOrderScrapQtyInput.sendKeys(data.get("MCSScreenReportValue"));
				js.executeScript("arguments[0].click();", ReportBtnPopUp);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				WebTestCase.getTest().log(LogStatus.PASS,"Report Popup Button clicked");
				Common.isElementDisplayed(driver, errMessage, IConstants.LOW_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.PASS, "Input value on Good and Scrap values together, Error Message :<b>"+errMessage.getText()+"</b>"+ common.captureScreenshot(ScreenshotRequire));

				txtProductionOrderReverseQtyInput.clear();
				txtProductionOrderScrapQtyInput.clear();
				txtProductionOrderScrapQtyInput.sendKeys(data.get("MCSScreenReportValue"));
				txtProductionOrderReverseQtyInput.sendKeys(data.get("MCSScreenReportValue"));
				js.executeScript("arguments[0].click();", ReportBtnPopUp);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				WebTestCase.getTest().log(LogStatus.PASS,"Report Popup Button clicked");
				Common.isElementDisplayed(driver, errMessage, IConstants.LOW_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.PASS, "Input value on Scrap and Reverse values together, Error Message :<b>"+errMessage.getText()+"</b>"+ common.captureScreenshot(ScreenshotRequire));

				txtProductionOrderReverseQtyInput.clear();
				txtProductionOrderGoodQtyInput.clear();
				txtProductionOrderGoodQtyInput.sendKeys(data.get("MCSScreenReportValue"));
				txtProductionOrderReverseQtyInput.sendKeys(data.get("MCSScreenReportValue"));
				js.executeScript("arguments[0].click();", ReportBtnPopUp);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				WebTestCase.getTest().log(LogStatus.PASS,"Report Popup Button clicked");

				Common.isElementDisplayed(driver, errMessage, IConstants.LOW_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.PASS, "Input value on Good and Reverse values together, Error Message :<b>"+errMessage.getText()+"</b>"+ common.captureScreenshot(ScreenshotRequire));
				js.executeScript("arguments[0].click();", ReportBtnPopUpClose);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				WebTestCase.getTest().log(LogStatus.PASS,"Report Popup close Button clicked");
			}

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return true;

	}
	@SuppressWarnings("static-access")
	public HashMap<String, String> verifyReportProductionOrderDetails(Hashtable<String, String> data,String techArea, String ScreenshotRequire) throws InterruptedException, ArrayIndexOutOfBoundsException{
		HashMap<String, String> map  = new HashMap<String, String>();
		try{
			System.out.println("inside verifyReportProductionOrderDetails function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(30000);
			Common.isElementDisplayed(driver, ContainerList, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			int counter=0;
			if(techArea.contains("Racks")) {
				System.out.println("techArea::" + techArea);
				for(int i=0;i<displaywipordernoList.size();i++) {
					if((operationstatusdescList.get(i).getAttribute("innerText").contains("Started"))){
						//WebTestCase.getTest().log(LogStatus.INFO, DisplayWipOrderNo.getText() +" Order number is displaying as started"+ common.captureScreenshot(ScreenshotRequire));
						counter++;
					}
				}
			}else {
				for(int i=0;i<displaywipordernoList.size();i++) {
					if((operationstatusdescList.get(i).getAttribute("innerText").contains("Started"))){
						//Assert.assertEquals(DisplayWipOrderNo.getText(), displaywipordernoList.get(i).getText(),"WIP Order number is not coming correctly on Header section.");
						Assert.assertEquals(OperationStatusDesc.getText(), operationstatusdescList.get(i).getText(),"WIP status is not coming correctly on Header section.");
						//WebTestCase.getTest().log(LogStatus.INFO, DisplayWipOrderNo.getText() +" Order number is displaying as started"+ common.captureScreenshot(ScreenshotRequire));
						counter++;
					}
				}
			}
			System.out.println("counter value:: "+counter);
			if(counter==1) {
				//WebTestCase.getTest().log(LogStatus.PASS, "WIP Order number is showing in MCS screen as started status"+ common.captureScreenshot(ScreenshotRequire));
			}else if(counter<1){
				WebTestCase.getTest().log(LogStatus.PASS, "WIP order details"+DisplayWipOrderNo.getText()+ common.captureScreenshot(ScreenshotRequire));
				Assert.assertTrue(DisplayWipOrderNo.getText().isEmpty(), "WIP order details are showing incorrectly.");
				WebTestCase.getTest().log(LogStatus.PASS, "No any WIP order status is started"+ common.captureScreenshot(ScreenshotRequire));
				if(operationstatusdescList.size()>0) {
					for(int i=1;i<operationstatusdescList.size();i++) {
						if(!(operationstatusdescList.get(i).getText().contains("On Hold"))) {
							operationstatusdescList.get(i).click();
							Common.isElementDisplayed(driver, startBtn, 10);
							common.clickOnObject(startBtn, "startBtn");
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
							WebTestCase.getTest().log(LogStatus.PASS, "Clicked on start button to start the order"+ common.captureScreenshot(ScreenshotRequire));
							Thread.sleep(7000);
							break;
						}
					}
				}else {
					WebTestCase.getTest().log(LogStatus.PASS, "No any WIP order available for this machine"+ common.captureScreenshot(ScreenshotRequire));
				}
			}
			if(!(QuantityCompletedTarget.getText().contains("0/0"))) {
				Common.isElementDisplayed(driver, LabelFormHeadCollapsed, 100);
				js.executeScript("document.body.style.zoom = '90%';");
				js.executeScript("arguments[0].click();", LabelFormHeadCollapsed);	
				Thread.sleep(IConstants.SYS_WAIT_TIME);
				map.put("ExpectedStartDate", ExpectedStartDate.getText());
				map.put("ExpectedCompletionDate", ExpectedCompletionDate.getText());
				map.put("ActualStartDate", ActualStartDate.getText());
				map.put("OrderNo", DisplayWipOrderNo.getText());
				System.out.println("map value:: "+ map);
				common.waitTillCondition(By.xpath(".//button[@value='REPORT_SCRAP']"), 5);
				js.executeScript("arguments[0].click();", REPORT_Btn_homepage);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );

				Common.isElementDisplayed(driver, ReportedQtyGoodScrap, IConstants.HIGH_WAIT_TIME);
				String [] scrap=ReportedQtyGoodScrap.getText().split("\\/");
				int previousScrapQty=Integer.parseInt(scrap[2]);
				System.out.println("previousScrapQty value:"+previousScrapQty);
				WebTestCase.getTest().log(LogStatus.PASS, "previous Scrap Qty value:"+previousScrapQty);
				js.executeScript("arguments[0].click();", ReportBtnPopUpClose);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				//validate good qty
				int MCSScreenReportValue =Integer.parseInt(data.get("MCSScreenReportValue"));
				System.out.println("MCS Screen Reported Value: "+ MCSScreenReportValue);
				String [] beforeReportqty=common.splitValues(QuantityCompletedTarget.getText(),"\\/");
				int beforeReportcompleqty=Integer.parseInt(beforeReportqty[0].trim());
				System.out.println("beforeReportcompleqty value"+beforeReportcompleqty);

				map.put("targetQty", beforeReportqty[1].trim());

				//int beforeReportremQty=Integer.parseInt(ToDoQty.getText());
				//int beforeReportdoneQty=Integer.parseInt(DoneQty.getText());
				if(!(DisplayEquipmentDetails.getText().contains("RKCG"))) {
					WebTestCase.getTest().log(LogStatus.PASS, "selecting order to report good quantity on MCS home page"+ common.captureScreenshot(ScreenshotRequire));
					Thread.sleep(10000);
					Common.isElementDisplayed(driver, REPORT_Btn_homepage, IConstants.HIGH_WAIT_TIME);
					common.highLighterMethod(driver,REPORT_Btn_homepage);
					js.executeScript("arguments[0].click();", REPORT_Btn_homepage);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					Common.isElementDisplayed(driver, txtProductionOrderGoodQtyInput, 30);
					common.setObjectValue(txtProductionOrderGoodQtyInput, "txtProductionOrderGoodQtyInput", data.get("MCSScreenReportValue"));
					WebTestCase.getTest().log(LogStatus.PASS, "Inserted value in good quantity textbox:"+data.get("MCSScreenReportValue")+ common.captureScreenshot(ScreenshotRequire));
					js.executeScript("arguments[0].click();", ReportBtnPopUp);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
					Thread.sleep(5000);
					Common.isElementDisplayed(driver, QuantityCompletedTarget, IConstants.HIGH_WAIT_TIME);

					//validating value after report to good quantity
					String [] afterReportGoodqty=common.splitValues(QuantityCompletedTarget.getText(),"\\/");
					System.out.println("afterReportGoodqty value::"+afterReportGoodqty[0]);
					softAssert.assertTrue((Integer.parseInt(afterReportGoodqty[0].trim())-beforeReportcompleqty)>=MCSScreenReportValue,"Quantity completed not increased correctly in MCS screen");
					WebTestCase.getTest().log(LogStatus.PASS, "Earlier completed quantity was:: <b>"+beforeReportcompleqty+"</b> after reporting good quantity:<b>"+data.get("MCSScreenReportValue")+ "</b> it get increased to :<b>"+afterReportGoodqty[0].trim()+"</b>"+common.captureScreenshot(ScreenshotRequire));
					map.put("goodqty", afterReportGoodqty[0].trim());
				}else {
					map.put("goodqty", beforeReportqty[0].trim());
					WebTestCase.getTest().log(LogStatus.PASS, "Good qty update disabled for Racks orders"+common.captureScreenshot(ScreenshotRequire));

				}
				//validating scrap qty
				WebTestCase.getTest().log(LogStatus.PASS, "selecting order to report scrap quantity on MCS home page"+ common.captureScreenshot(ScreenshotRequire));
				common.isElementDisplayed(driver, mcsPageTitle, IConstants.HIGH_WAIT_TIME);
				Thread.sleep(10000);
				System.out.println("MCS page displayed");
				common.elementToBeClickable(By.xpath(reportbtn), IConstants.HIGH_WAIT_TIME);	
				common.highLighterMethod(driver,REPORT_Btn_homepage);
				js.executeScript("arguments[0].click();", REPORT_Btn_homepage);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Common.isElementDisplayed(driver, txtProductionOrderScrapQtyInput, IConstants.HIGH_WAIT_TIME);
				common.setObjectValue(txtProductionOrderScrapQtyInput, "txtProductionOrderScrapQtyInput", data.get("MCSScreenReportValue"));
				WebTestCase.getTest().log(LogStatus.PASS, "Inserted value in scrap quantity textbox:"+data.get("MCSScreenReportValue")+ common.captureScreenshot(ScreenshotRequire));
				js.executeScript("arguments[0].click();", ReportBtnPopUp);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );

				//Common.isElementDisplayed(driver, errMessage, IConstants.MEDIUM_WAIT_TIME);
				//WebTestCase.getTest().log(LogStatus.PASS, "Entered value on Scrap textbox without selecting reason codes , Error Message :"+errMessage.getText()+ common.captureScreenshot(ScreenshotRequire));

				System.out.println("Entered scrap qty "+data.get("MCSScreenReportValue"));
				Common.isElementDisplayed(driver, reasonCode, IConstants.MEDIUM_WAIT_TIME);
				if(reasonCodeLevel.size()>0) {
					int reasonCodeL1=common.generateRandomIntIntRange(0,(reasonCodeLevel.size()-2));
					System.out.println("RandomIntegerNumberlevel1 = "+reasonCodeL1);
					Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL1), IConstants.MEDIUM_WAIT_TIME);
					String r1=reasonCodeLevel.get(reasonCodeL1).getText();
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+r1+ common.captureScreenshot(ScreenshotRequire));
				}
				if(reasonCodeLevel.size()>0) {
					if(reasonCodeLevel.size()>1) {
						Common.isElementDisplayed(driver, reasonCodeLevel.get(0), IConstants.MEDIUM_WAIT_TIME);
						int reasonCodeL2=common.generateRandomIntIntRange(0,(reasonCodeLevel.size()-2));
						System.out.println("RandomIntegerNumberlevel2 = "+reasonCodeL2);
						Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL2), IConstants.MEDIUM_WAIT_TIME);
						String r2=reasonCodeLevel.get(reasonCodeL2).getText();
						js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
						Thread.sleep(5000);
						WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level2:"+ r2+common.captureScreenshot(ScreenshotRequire));
					}else {
						Common.isElementDisplayed(driver, reasonCodeLevel.get(0), IConstants.MEDIUM_WAIT_TIME);
						String r2=reasonCodeLevel.get(0).getText();
						js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
						Thread.sleep(5000);
						WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level2:"+ r2+common.captureScreenshot(ScreenshotRequire));
					}
				}
				if(reasonCodeLevel.size()>0) {
					if(reasonCodeLevel.size()>1) {
						Common.isElementDisplayed(driver, reasonCodeLevel.get(0), IConstants.MEDIUM_WAIT_TIME);
						int reasonCodeL3=Common.generateRandomIntIntRange(0,(reasonCodeLevel.size()-2));
						System.out.println("RandomIntegerNumberlevel3 = "+reasonCodeL3);
						Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL3), IConstants.MEDIUM_WAIT_TIME);
						String r3=reasonCodeLevel.get(reasonCodeL3).getText();
						js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
						Thread.sleep(5000);
						WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code level3:"+ r3+common.captureScreenshot(ScreenshotRequire));
					}else {
						Common.isElementDisplayed(driver, reasonCodeLevel.get(0), IConstants.MEDIUM_WAIT_TIME);
						String r3=reasonCodeLevel.get(0).getText();
						js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
						Thread.sleep(5000);
						WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code level3:"+ r3+common.captureScreenshot(ScreenshotRequire));
					}
				}
				Thread.sleep(8000);
				Common.isElementDisplayed(driver, ReportBtnPopUp, IConstants.MEDIUM_WAIT_TIME);
				js.executeScript("arguments[0].click();", ReportBtnPopUp);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				WebTestCase.getTest().log(LogStatus.PASS, "Entered value on Scrap textbox and selecting reason codes"+ common.captureScreenshot(ScreenshotRequire));
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				common.isElementDisplayed(driver, mcsPageTitle, IConstants.HIGH_WAIT_TIME);
				Thread.sleep(10000);
				common.elementToBeClickable(By.xpath(reportbtn), IConstants.SYS_WAIT_TIME);
				common.highLighterMethod(driver,REPORT_Btn_homepage);
				js.executeScript("arguments[0].click();", REPORT_Btn_homepage);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Common.isElementDisplayed(driver, ReportedQtyGoodScrap, IConstants.HIGH_WAIT_TIME);
				String [] afterReportscrap=ReportedQtyGoodScrap.getText().split("\\/");
				int afterReportscrapqty=Integer.parseInt(afterReportscrap[2]);

				js.executeScript("arguments[0].click();", ReportBtnPopUpClose);
				//validating value after report to scrap quantity
				softAssert.assertTrue((afterReportscrapqty-previousScrapQty)>=MCSScreenReportValue,"Quantity Scrap not increased correctly");
				WebTestCase.getTest().log(LogStatus.PASS, "Earlier scrap quantity was:"+previousScrapQty+" after reporting scrap quantity:"+data.get("MCSScreenReportValue")+ "it get increased to :"+afterReportscrapqty+common.captureScreenshot(ScreenshotRequire));
				map.put("afterReportscrapqty", afterReportscrap[2]);
				System.out.println("Earlier scrap quantity was:"+previousScrapQty+"after reporting scrap quantity:"+data.get("MCSScreenReportValue")+ "it get increased to :"+afterReportscrapqty+"");

			}
			if(UIServiceBody.getAttribute("innerHTML").contains("Report Production")) {
				js.executeScript("arguments[0].click();", ReportBtnPopUpClose);
				Common.isElementDisplayed(driver, machineLabel, IConstants.HIGH_WAIT_TIME);
				System.out.println("closed report screen forcefully");
			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return map;

	}

	@SuppressWarnings("static-access")
	public void validateMCSScreenHeader(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateMCSScreenHeader function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, mcsScreenLabel.get(0), 100);
			Common.isElementDisplayed(driver, LabelFormHeadCollapsed, 100);

			JavascriptExecutor js = (JavascriptExecutor)driver; 
			js.executeScript("arguments[0].click();", LabelFormHeadCollapsed);	

			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("document.body.style.zoom = '90%';");

			Thread.sleep(IConstants.SYS_WAIT_TIME);

			System.out.println(mcsScreenLabel.size());
			for(int i=0;i<mcsScreenLabel.size();i++) {
				if((mcsScreenLabel.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("MCS screen Headers Label:"+mcsScreenLabel.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "MCS Screen Header Label"+"--"+mcsScreenLabel.get(i).getAttribute("innerHTML").toLowerCase()+ " -- " + " Data in Global Sheet:- " +hmAction.get(i+1).toLowerCase());
				}else{
					WebTestCase.getTest().log(LogStatus.INFO, "MCS Screen Header Label Expected "+" -- "+mcsScreenLabel.get(i).getAttribute("innerHTML")+ " -- " + "  But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
				}
			}
			WebTestCase.getTest().log(LogStatus.INFO, "MCS Screen Header Label validated successfully"+common.captureScreenshot(ScreenshotRequire));
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}


	@SuppressWarnings("static-access")
	public void validateMCSScreenProductionHeader(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateMCSScreenProductionHeader function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, ActualProduction_NumbersList.get(0), 100);
			System.out.println(ActualProduction_NumbersList.size());
			for(int i=0;i<ActualProduction_NumbersList.size();i++) {
				if((ActualProduction_NumbersList.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("MCS screen Headers Label:"+ActualProduction_NumbersList.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "MCS Screen Production Header Label"+"--"+ActualProduction_NumbersList.get(i).getAttribute("innerHTML").toLowerCase()+ " -- " + " Data in Global Sheet:- " +hmAction.get(i+1).toLowerCase());
				}else{
					WebTestCase.getTest().log(LogStatus.INFO, "MCS Screen Production Header Label Expected "+" -- "+ActualProduction_NumbersList.get(i).getAttribute("innerHTML")+ " -- " + "  But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
				}
			}
			WebTestCase.getTest().log(LogStatus.INFO, "MCS Screen Header Label validated successfully"+common.captureScreenshot(ScreenshotRequire));
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To verify Racks OrderStatus on MCS Screen
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public int verifyRacksOrderStatus(String ScreenshotRequire) throws InterruptedException{
		int counter=0;
		WebDriverWait wait = new WebDriverWait(driver, IConstants.MEDIUM_WAIT_TIME);
		try{
			System.out.println("inside verifyRacksOrderStatus function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.isElementDisplayed(driver, DisplayEquipmentDetails, IConstants.HIGH_WAIT_TIME);
			Thread.sleep(20000);			
			int pos=1;
			HashMap<String,String> map=new HashMap<String,String>();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			System.out.println("displaywipordernoList size:  "+ displaywipordernoList.size());
			for(int i=0;i<displaywipordernoList.size();i++) {
				if((operationstatusdescList.get(i).getAttribute("innerHTML").contains("Started"))){
					counter++;
					System.out.println("started pno:"+operationProductList.get(i).getText());
					map.put("StartedProductId"+pos, operationProductList.get(i).getText());
					pos++;

				}
			}
			System.out.println("started order count:" +counter );
			if(counter>=1) {
				WebTestCase.getTest().log(LogStatus.PASS, "WIP Order number is showing in MCS screen as started status"+ common.captureScreenshot(ScreenshotRequire));
				// checking if we can make another order to start for racks technology area
				if(NewProductNoList.size()>0) {
					for(int j=0;j<NewProductNoList.size();j++) {
						String newProductNo=NewProductNoList.get(j).getText();
						//common.clickOnObject(RefreshDataLink, "RefreshDataLink");
						//Thread.sleep(1000);
						if((operationstatusdescList.get(j).getText().contains("New"))||(operationstatusdescList.get(j).getText().contains("Off-Hold"))) {
							if(map.containsValue(newProductNo)) {
								System.out.println(" operationstatusdescList::" + operationstatusdescList.get(j).getText());
								common.waitForElementLoaded(NewProductNoList.get(j), IConstants.SYS_WAIT_TIME);
								WebTestCase.getTest().log(LogStatus.PASS, "Order to start::"+NewProductNoList.get(j).getText()+ common.captureScreenshot(ScreenshotRequire));
								NewProductNoList.get(j).click();
								if(startBtn.isEnabled()) {
									System.out.println("start button enabled");
									Thread.sleep(1000);
									common.clickOnObject(startBtn, "startBtn");
									System.out.println("clicked on start button");
								}else {
									System.out.println("start button not enabled");
									NewProductNoList.get(j).click();
									Thread.sleep(1000);
									common.clickOnObject(startBtn, "startBtn");
									System.out.println("enable and clicked on start");
								}
								Thread.sleep(4000);
								common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
								if(errMessageDiv.getAttribute("innerHTML").contains("apr-message-error")) {
									WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing while starting another order with same product id :"+errMessage.getText()+ common.captureScreenshot(ScreenshotRequire));
									Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing while starting another order");
									break;
								}else {
									System.out.println("no error msg");
								}
							}else {
								NewProductNoList.get(j).click();
								common.isElementDisplayed(driver, startBtn, 180);
								common.clickOnObject(startBtn, "startBtn");
								common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
								String newProductStatus=driver.findElement(By.xpath(".//tr/td[@data-field='productno']//span[text()='"+newProductNo+"']/../../..//td[@data-field='operationstatusdesc']")).getText();
								System.out.println("new status :"+ newProductStatus);
								WebTestCase.getTest().log(LogStatus.PASS, "Product order:  "+NewProductNoList.get(j).getText()+" , status is"+newProductStatus+ common.captureScreenshot(ScreenshotRequire));
								break;
							}
						}
					}
				}
				/*else if(NewProductNoList.size()>0) {
					for(int j=0;j<NewProductNoList.size();) {
						String NewProductNo=NewProductNoList.get(j).getText();
						common.clickOnObject(RefreshDataLink, "RefreshDataLink");
						Thread.sleep(1000);
						if(map.containsValue(NewProductNo)) {
							NewProductNoList.get(j).click();
							common.isElementDisplayed(driver, startBtn, 180);
							common.clickOnObject(startBtn, "startBtn");
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
							common.isElementDisplayed(driver, errMessage, IConstants.HIGH_WAIT_TIME);
							WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing while starting another order with same product id :"+errMessage.getText()+ common.captureScreenshot(ScreenshotRequire));
							Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing while starting another order");
							break;

						}else {
							NewProductNoList.get(j).click();
							common.isElementDisplayed(driver, startBtn, 180);
							common.clickOnObject(startBtn, "startBtn");
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
							String newProductStatus=driver.findElement(By.xpath(".//tr/td[@data-field='productno']//span[text()='"+NewProductNo+"']/../../..//td[@data-field='operationstatusdesc']")).getText();
							System.out.println("new status :"+ newProductStatus);
							WebTestCase.getTest().log(LogStatus.PASS, "Product order:  "+NewProductNoList.get(j).getText()+" , status is"+newProductStatus+ common.captureScreenshot(ScreenshotRequire));
							break;

						}
					}
				}*/

			}else if(counter<1){
				Assert.assertTrue(DisplayWipOrderNo.getText().isEmpty(), "WIP order details are showing incorrectly.");
				WebTestCase.getTest().log(LogStatus.PASS, "No any WIP order status is started"+ common.captureScreenshot(ScreenshotRequire));

			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return counter;
	}

	/**
	 * Method To verify Reverse Production Order Status in MCS Screen
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings("static-access")
	public int verifyReverseProductionOrderStatus(Hashtable<String, String> data, String ScreenshotRequire) throws InterruptedException, ArrayIndexOutOfBoundsException{
		int startorderCount=0;
		System.out.println("inside verifyReverseProductionOrderStatus function");
		try{

			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.highLighterMethod(driver,QuantityCompletedTarget);
			Thread.sleep(20000);
			int MCSScreenReportQty =Integer.parseInt(data.get("MCSScreenReportValue"));
			JavascriptExecutor js = (JavascriptExecutor)driver;
			if(DisplayWipOrderNo.getText()!=null) {
				String [] beforeReportqty=common.splitValues(QuantityCompletedTarget.getText(),"\\/");
				int beforeReportcompleqty=Integer.parseInt(beforeReportqty[0].trim());
				System.out.println("beforeReportcompleqty value: "+beforeReportcompleqty);
				WebTestCase.getTest().log(LogStatus.PASS, "selecting order <b>"+DisplayWipOrderNo.getText()+"</b> to report reverse quantity on MCS home page"+ common.captureScreenshot(ScreenshotRequire));
				Common.isElementDisplayed(driver, REPORT_Btn_homepage, IConstants.HIGH_WAIT_TIME);
				//validating value after report to reverse quantity
				//common.highLighterMethod(driver,REPORT_Btn_homepage);
				Common.isElementDisplayed(driver, REPORT_Btn_homepage, IConstants.HIGH_WAIT_TIME);
				js.executeScript("arguments[0].click();", REPORT_Btn_homepage);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				System.out.println("clicked on REPORT_Btn_homepage");
				Common.isElementDisplayed(driver, txtProductionOrderReverseQtyInput, IConstants.HIGH_WAIT_TIME);
				Thread.sleep(10000);
				if(beforeReportcompleqty>=MCSScreenReportQty){
					common.setObjectValue(txtProductionOrderReverseQtyInput, "txtProductionOrderGoodQtyInput", data.get("MCSScreenReportValue"));
					WebTestCase.getTest().log(LogStatus.PASS, "Inserted value in reverse quantity textbox:"+data.get("MCSScreenReportValue")+ common.captureScreenshot(ScreenshotRequire));
					Common.isElementDisplayed(driver, reasonCode, IConstants.MEDIUM_WAIT_TIME);
					String reasoncodeText=reasonCode.getText();
					js.executeScript("arguments[0].click();", reasonCode);
					Thread.sleep(10000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+reasoncodeText+ common.captureScreenshot(ScreenshotRequire));
					Common.isElementDisplayed(driver, ReportBtnPopUp, IConstants.MEDIUM_WAIT_TIME);
					js.executeScript("arguments[0].click();", ReportBtnPopUp);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
					Thread.sleep(5000);
					Common.isElementDisplayed(driver, QuantityCompletedTarget, IConstants.HIGH_WAIT_TIME);
					String [] afterReportGoodqty=common.splitValues(QuantityCompletedTarget.getText(),"\\/");
					System.out.println("afterReportGoodqty value"+afterReportGoodqty[0]);
					softAssert.assertTrue(beforeReportcompleqty-(Integer.parseInt(afterReportGoodqty[0].trim()))>=MCSScreenReportQty,"Quantity completed not decreased correctly in MCS screen");
					WebTestCase.getTest().log(LogStatus.PASS, "Earlier completed quantity was: <b>"+beforeReportcompleqty+"</b> after reporting reverse quantity:<b>"+data.get("MCSScreenReportValue")+ "</b> it get decreased to :<b>"+afterReportGoodqty[0].trim()+"</b>"+common.captureScreenshot(ScreenshotRequire));
					startorderCount=1;
				}else {
					common.setObjectValue(txtProductionOrderReverseQtyInput, "txtProductionOrderGoodQtyInput", data.get("MCSScreenReportValue"));
					js.executeScript("arguments[0].click();", ReportBtnPopUp);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Completed quantity value:"+beforeReportcompleqty+" Reverse reported quantity value: "+MCSScreenReportQty);
					//WebTestCase.getTest().log(LogStatus.PASS, "Reverse quantity value should not greater then completed quantity value, error message <b>"+errMessage.getText()+"</b>"+common.captureScreenshot(ScreenshotRequire));
					js.executeScript("arguments[0].click();", ReportBtnPopUpClose);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
					Common.isElementDisplayed(driver, QuantityCompletedTarget, IConstants.HIGH_WAIT_TIME);
					Thread.sleep(10000);
					String [] afterReportGoodqty=common.splitValues(QuantityCompletedTarget.getText(),"\\/");
					System.out.println("afterReportGoodqty value::"+afterReportGoodqty[0].trim());
					softAssert.assertEquals(beforeReportcompleqty,afterReportGoodqty[0].trim(),"Quantity completed changed incorrectly in MCS screen");

				}
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "No any start order available.");
				startorderCount=0;
			}

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return startorderCount;
	}

	/**
	 * Method To verify And Start the hold Order On MCS Screen
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void verifyAndStartOrderOnMCSScreen(String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside verifyAndStartOrderOnMCSScreen function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.isElementDisplayed(driver, DisplayEquipmentDetails, IConstants.HIGH_WAIT_TIME);
			Thread.sleep(8000);
			if(DisplayWipOrderNo.getText()!=null) {
				System.out.println("started order :" +DisplayWipOrderNo.getText() );
				WebTestCase.getTest().log(LogStatus.PASS, "WIP Order number "+DisplayWipOrderNo.getText()+" is showing in MCS screen as started status"+ common.captureScreenshot(ScreenshotRequire));
			}else {
				for(int j=0;j<onHoldProductNoList.size();) {
					String onHoldProductNo=onHoldProductNoList.get(j).getText();
					onHoldProductNoList.get(j).click();
					common.isElementDisplayed(driver, startBtn, 180);
					common.clickOnObject(startBtn, "startBtn");
					Thread.sleep(5000);
					String newProductStatus=driver.findElement(By.xpath(".//tr/td[@data-field='productno']//span[text()='"+onHoldProductNo+"']/../../..//td[@data-field='operationstatusdesc']")).getText();
					System.out.println("new status >>"+ onHoldProductNoList.get(j)+">>"+newProductStatus);
					WebTestCase.getTest().log(LogStatus.PASS, "Product order "+onHoldProductNoList.get(j)+" status is"+newProductStatus+ common.captureScreenshot(ScreenshotRequire));
					break;

				}
			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

	}


	/**
	 * Method To click on build pallet button in MCS Page
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public void clickBuildPalletButton(String ScreenshotRequire)
	{
		try
		{	
			System.out.println("click on clickBuildPalletButton function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, palletLink, IConstants.HIGH_WAIT_TIME);
			Thread.sleep(20000);
			System.out.println("wait over");

			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Build pallet button is present in MCS Screen"+ common.captureScreenshot(ScreenshotRequire));
			/*JavascriptExecutor js = (JavascriptExecutor)driver; 
		js.executeScript("arguments[0].click();", palletLink);	*/	
			//palletLink.click();
			WebDriverWait myWaitVar = new WebDriverWait(driver,20);
			WebElement el = myWaitVar.until(ExpectedConditions.elementToBeClickable(By.xpath(palletlink)));
			el.click();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			System.out.println("clicked on BuildPalletButton");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Build pallet button clicked on MCS screen"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}

		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To validateMCSPageOrderQtyDetailsAfterBuildPallet
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public HashMap<String, String> validateMCSPageOrderQtyDetailsAfterBuildPallet(String buildPalletQtyAndOrderId, String ScreenshotRequire) throws InterruptedException{
		HashMap<String,String> hm=new HashMap<String,String>();
		try{
			System.out.println("inside validateMCSPageOrderQtyDetailsAfterBuildPallet function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.isElementDisplayed(driver, DisplayWipOrderNo, IConstants.MEDIUM_WAIT_TIME);

			String [] buildPalletQtyOId=common.splitValues(buildPalletQtyAndOrderId,"\\_");
			String palletQty=buildPalletQtyOId[0].trim();
			String oID=buildPalletQtyOId[1].trim();

			softAssert.assertEquals(DisplayWipOrderNo.getText(),oID ,"Order id not displayed correctly in MCS screen");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order id displaying same in MCS and Pallet Screen:"+ DisplayWipOrderNo.getText()+">>"+oID );

			String [] qty=common.splitValues(QuantityCompletedTarget.getText(),"\\/");
			String compleqty=qty[0].trim();
			String trgtqty=qty[1].trim();
			driver.switchTo().defaultContent();
			hm.put("orderId", oID);
			hm.put("completedqty", compleqty);
			hm.put("targetqty", trgtqty);
			hm.put("palletqty", palletQty);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return hm;

	}



}
