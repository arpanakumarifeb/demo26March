package com.web.elx.pages;

import java.io.File;
import java.util.*;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class NCInfoPage {

	@FindBy(xpath ="//button[@class='ToolButton CREATE_NC_OUTOFCONTEXT T1 ']")
	private WebElement createNCButton;

	@FindBy(xpath ="//li[@title='NCM-020']")
	private WebElement createNCTitle;

	@FindBy(xpath ="//h2[text()='Non-Conformity Information']")
	private WebElement NCInfoPageTitle;

	@FindBy(xpath ="//button[@value='RESOLVE']")
	private WebElement resolveButton;

	@FindBy(xpath="//button[@value='YES']")
	private WebElement yes;

	@FindBy(xpath = "(//select[contains(@class,'FC4')])[3]")
	private WebElement workCenterDropDown;

	@FindBy(xpath = ".//select[contains(@class,'NCCriticality')]")
	private WebElement NCCriticality;

	@FindBy(xpath = ".//td[@class='Control fc_NCCreatedBy']/span")
	private WebElement NCCreatedBy;

	@FindBy(xpath = ".//td[@class='Control fc_WipOrderNo']/span")
	private WebElement WipOrderNo;





	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	String DashboardAlert="//*[@id='DashboardAlert']/div/div/div[1]/a";

	@FindBy(xpath =".//li[contains(@data-reasoncodecrumb,'L3')]")
	private WebElement reasonCode3;

	@FindBy(xpath ="//tr[@class='HeadT']/td/div[1]")
	private List <WebElement> ncmTableHeaderList;

	@FindBy(xpath = "(//a[@class='k-icon k-i-hbars'])[3]")
	private WebElement clickLine;

	@FindBy(xpath = "(//tbody[@class='Items'])[1]//div")        
	private List <WebElement> webListLine;  

	@FindBy(xpath = "(//button[@id='default'])")
	private WebElement oK;

	@FindBy(xpath = "(//a[@class='k-icon k-i-hbars'])[4]")
	private WebElement clickStatus;

	@FindBy(xpath = "(//div[@class='DropDownWrapper'])[3]/select")
	private WebElement workCenters;

	@FindBy(xpath = "(//div[@class='DropDownWrapper'])[2]/select")
	private WebElement criticality;

	@FindBy(xpath = "(//div[@class='DropDownWrapper'])[1]/select")
	private WebElement operatorSequence;

	@FindBy(xpath = "(//tbody[@class='Items'])[1]//div")        
	private List <WebElement> webListStatus; 

	@FindBy(xpath = ".//td[contains(@class, 'value')][1]//span")
	private List <WebElement> webListOrder;

	@FindBy(xpath = "//div[@class='FormContainer']/div//td[1]|//div[@class='FormContainer']/div//td[3]")
	private List <WebElement> nonConfirmityDetails;

	@FindBy(xpath = "//button[@value='RESOLVE']")
	private  WebElement btnResolve	;

	@FindBy(xpath = "//button[@value='SAVE']")
	private  WebElement btnSave	;

	@FindBy(xpath = "//div[@class='fix sort asc']")
	private  WebElement statusDropdown	;

	@FindBy(xpath ="//tbody[@class='Items']//div")
	private List <WebElement> availableLines;

	@FindBy(xpath ="//div[contains(text(),'Available Items')]")
	private WebElement availbleItemTxt;

	@FindBy(xpath ="//div[contains(text(),'Selected items')]")
	private WebElement selectedItemTxt;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[2]")
	private WebElement ncType;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[9]")
	private WebElement orderNO;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[15]")
	private WebElement createdBy;
	
	@FindBy(xpath = "//button/span[text()='Complete']")
	private WebElement completeBtn;
	
	@FindBy(xpath = ".//span[contains(@class,'fa fa-close ELX_RPC_window-close')]")
	private WebElement ELX_RPCwindowclose;
	
	
	
	@FindBy(xpath = "//div[@class='ELX_ReasonCode-crumbs']//li")
	private WebElement reason;
	
	@FindBy(xpath = "(//div[@class='ELX_ReasonCode-crumbs']//li)[1]")
	private WebElement level1ReasonCode;
	
	@FindBy(xpath = "(//div[@class='ELX_ReasonCode-crumbs']//li)")
	private List <WebElement> level1ReasonCodeSelected;
	
			
	@FindBy(xpath = ".//button[contains(@class,'ELX_NCM_RPC_ReasonCode')]")
	private List <WebElement> reasonCodeLevel;
	
	@FindBy(xpath = ".//div[@class='apr-message-error']")
	private WebElement errMessage;
	
	@FindBy(xpath = "//button[@class='ToolButton Export action action_export']")
	private WebElement exportIcon;
	
	@FindBy(xpath = "//button[@id='default']")
	private WebElement exportBtn;

	private WebDriver driver;
	private Common common;

	public NCInfoPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}


	/**
	 * Method To validate NC Info Page Title
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateNCInfoPageTitle(String title, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateNCInfoPageTitle function");
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, NCInfoPageTitle, IConstants.LOW_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Non-Conformity Information page loaded"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}catch(Exception exp2){
			System.out.println("Got Exception Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To click On Resolve Button
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	public String clickOnResolveButton(String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside clickOnResolveButton function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, resolveButton, IConstants.LOW_WAIT_TIME);
			common.captureScreenshot(ScreenshotRequire);
			common.clickOnObject(resolveButton, "resolveButton");
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			System.out.println(" Resolve Button clicked");
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - clicked on resolve button"+ common.captureScreenshot(ScreenshotRequire));
			Thread.sleep(4000);
			/*JavascriptExecutor js = (JavascriptExecutor)driver; 
		js.executeScript("arguments[0].click();", yes);*/
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, yes, IConstants.LOW_WAIT_TIME);
			common.clickOnObject(yes,"yes");
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			Thread.sleep(6000);
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - Clicked on Yes option from alert box" + common.captureScreenshot(ScreenshotRequire));
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Resolve NC button is clicked successfuly" + common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}catch(Exception exp2){
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);
	}
	/**
	 * Method To validate NC Details Page Details
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateNCDetailsPageDetails(String wc,String option3,String operator,String orderNum,String model, String plannedqty,String status, String ScreenshotRequire) throws InterruptedException{
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);

			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, NCInfoPageTitle, IConstants.LOW_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Non-Conformity Information page loaded"+ common.captureScreenshot(ScreenshotRequire));

			//Assert.assertEquals(NCCreatedBy.getText(),operator,"valid operator is not displaying correctly.");
			//Assert.assertEquals(WipOrderNo.getText(),orderNum,"valid order number is not displaying correctly");
			//Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+model+"']")).getText(),model,"valid model number is not displaying correctly");
			//Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+plannedqty+"']")).getText(),plannedqty,"valid planned qty is not displaying correctly");

			Select CriticalityDropDown = new Select(NCCriticality);
			WebElement option1 = CriticalityDropDown.getFirstSelectedOption();
			System.out.println("selected Criticality: "+option1.getText());
			Assert.assertEquals(option1.getText(),status,"selected Criticality is not displaying correctly.");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - selected Criticality is displaying correctly:"+option1.getText()+ common.captureScreenshot(ScreenshotRequire));


			Select WorkCenterDropDown = new Select(workCenterDropDown);
			WebElement option2 = WorkCenterDropDown.getFirstSelectedOption();
			System.out.println("selected wc: "+option2.getText());
			if(option2.getText()!="--") {
			Assert.assertEquals(option2.getText(),wc,"Selected work center is not displaying correctly. ");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - selected work center is displaying correctly:"+option2.getText()+ common.captureScreenshot(ScreenshotRequire));
			}

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

	}

	@SuppressWarnings("static-access")
	public void validateNCMPageTableHeader(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateNCMPageTableHeader function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.SYS_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.INFO, "NCM page loaded "+common.captureScreenshot(ScreenshotRequire));


			for(int i=0;i<ncmTableHeaderList.size();i++) {		
				if((ncmTableHeaderList.get(i).getAttribute("innerText").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					WebTestCase.getTest().log(LogStatus.INFO, "Available Icons  in NCM page table Header Section"+"--"+ncmTableHeaderList.get(i).getAttribute("innerText")+"----global sheet---"+hmAction.get(i+1).toLowerCase());
				}else{
					WebTestCase.getTest().log(LogStatus.FAIL, "Available Icons in NCM page table Header Section Expected "+" -- "+hmAction.get(i+1).toLowerCase()+ " -- " + "  But Data in online screen " +ncmTableHeaderList.get(i).getAttribute("innerHTML"));	
				}
			}
			WebTestCase.getTest().log(LogStatus.INFO, "Successfully validated  Available Icons  in NCM page table Header Section "+common.captureScreenshot(ScreenshotRequire));
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	public String clickonLine(String ScreenshotRequire) throws InterruptedException{
		Thread.sleep(15000);
		System.out.println("inside clickonLine function");
		Thread.sleep(10000);
		common.switchToFrame(By.xpath(iframepage), 120);
		common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
		String img=common.captureScreenshot(ScreenshotRequire);
		common.clickOnObject(clickLine, "clickLine");
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Thread.sleep(10000);
		driver.switchTo().defaultContent();
		return img;

	}

	@SuppressWarnings("static-access")
	public String selectLine(String lineName, String ScreenshotRequire) throws InterruptedException{

		String val=null;

		try{
			System.out.println("inside searchOrderOnOrderCockpitPage function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(10000);

			if(webListLine==null){
			}

			for(int i=0;i<=webListLine.size();i++){
				System.out.println(webListLine.get(i).getAttribute("innerHTML"));
				if(webListLine.get(0).getAttribute("innerHTML").contains(lineName))
				{
					val=webListLine.get(0).getAttribute("innerHTML");
					System.out.println(val);
					System.out.println(webListLine.get(0).getAttribute("innerHTML"));
					Actions action =new Actions(driver);
					action.doubleClick(driver.findElement(By.xpath(".//div[text()='"+webListLine.get(0).getAttribute("innerHTML")+"']"))).perform();
					Thread.sleep(10000);
					break;	
				}
				if(webListLine.get(1).getAttribute("innerHTML").contains(lineName))
				{
					val=webListLine.get(1).getAttribute("innerHTML");
					System.out.println(val);
					System.out.println(webListLine.get(1).getAttribute("innerHTML"));
					Actions action =new Actions(driver);
					action.doubleClick(driver.findElement(By.xpath(".//div[text()='"+webListLine.get(1).getAttribute("innerHTML")+"']"))).perform();
					Thread.sleep(10000);
					break;	
				}
				if(webListLine.get(2).getAttribute("innerHTML").contains(lineName))
				{
					val=webListLine.get(2).getAttribute("innerHTML");
					System.out.println(val);
					System.out.println(webListLine.get(2).getAttribute("innerHTML"));
					Actions action =new Actions(driver);
					action.doubleClick(driver.findElement(By.xpath(".//div[text()='"+webListLine.get(2).getAttribute("innerHTML")+"']"))).perform();
					Thread.sleep(10000);
					break;	
				}
			}
			oK.click();
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Line number is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));
			System.out.println("Selected "+ val);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	public String clickonStatus(String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside clickonStatus function");
		Thread.sleep(10000);
		common.switchToFrame(By.xpath(iframepage), 120);
		common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
		JavascriptExecutor js = (JavascriptExecutor)driver; 	
		js.executeScript("arguments[0].scrollIntoView();",statusDropdown);
		Thread.sleep(10000);

		String img=common.captureScreenshot(ScreenshotRequire);
		clickStatus.click();
		Thread.sleep(10000);
		driver.switchTo().defaultContent();
		return img;

	}

	/**
	 * Method To Status Fields 
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateStatusFields(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateStatusFields function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			List <WebElement> list	=	common.getallvaluesfromSelectbox(workCenters, "SelectBox");
			System.out.println(list.size());
			for(int i=0;i<list.size();i++) {
				if((list.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("NCM Screen StatusField Contains :"+list.get(i).getAttribute("innerHTML"));
					//WebTestCase.getTest().log(LogStatus.PASS, "Level 1 Operation verification on online and Global file :" +list.get(j).getAttribute("innerHTML")+"***"+hm2[j][i]);
					WebTestCase.getTest().log(LogStatus.PASS, "NcDetails  Workcenter Contains :"+ list.get(i).getAttribute("innerHTML")+ "***"+ hmAction.get(i+1).toLowerCase());
				}

				/*else{
							WebTestCase.getTest().log(LogStatus.INFO, "ORD Screen StatusField Contains Expected "+" -- "+list.get(i).getAttribute("innerHTML")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
						}*/
			}

			WebTestCase.getTest().log(LogStatus.INFO, "Workcenter fields validated successfully "+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To Status Fields 
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void criticalityFields(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside criticalityFields function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			List <WebElement> list	=	common.getallvaluesfromSelectbox(criticality, "SelectBox");
			System.out.println(list.size());
			for(int i=0;i<list.size();i++) {
				if((list.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("Criticality field Contains :"+list.get(i).getAttribute("innerHTML"));
					//WebTestCase.getTest().log(LogStatus.PASS, "Level 1 Operation verification on online and Global file :" +list.get(j).getAttribute("innerHTML")+"***"+hm2[j][i]);
					WebTestCase.getTest().log(LogStatus.PASS, "Criticality field Contains :"+ list.get(i).getAttribute("innerHTML")+ "***"+ hmAction.get(i+1).toLowerCase());
				}

				/*else{
							WebTestCase.getTest().log(LogStatus.INFO, "ORD Screen StatusField Contains Expected "+" -- "+list.get(i).getAttribute("innerHTML")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
						}*/
			}

			WebTestCase.getTest().log(LogStatus.INFO, "Criticality field Contains validated successfully "+common.captureScreenshot("ScreenshotRequire"));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To Status Fields 
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void cprSequenceNoFields(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside cprSequenceNoFields function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			List <WebElement> list	=	common.getallvaluesfromSelectbox(operatorSequence, "SelectBox");
			System.out.println(list.size());
			for(int i=0;i<list.size();i++) {
				if((list.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("OperatorSequence Field Contains :"+list.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.PASS, "OperatorSequence Field Contains :"+ list.get(i).getAttribute("innerHTML")+ "***"+ hmAction.get(i+1).toLowerCase());
				}

				/*else{
							WebTestCase.getTest().log(LogStatus.INFO, "ORD Screen StatusField Contains Expected "+" -- "+list.get(i).getAttribute("innerHTML")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
						}*/
			}

			WebTestCase.getTest().log(LogStatus.INFO, "OperatorSequence Field Contains validated successfully "+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	@SuppressWarnings("static-access")
	public String selectstatus(String statusName, String ScreenshotRequire) throws InterruptedException{

		String val=null;

		try{
			System.out.println("inside selectstatus function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(10000);

			if(webListStatus==null){
			}

			for(int i=0;i<=webListStatus.size();i++){
				System.out.println(webListStatus.get(i).getAttribute("innerHTML"));
				if(webListStatus.get(0).getAttribute("innerHTML").contains(statusName))
				{
					val=webListStatus.get(0).getAttribute("innerHTML");
					System.out.println(val);
					System.out.println(webListStatus.get(0).getAttribute("innerHTML"));
					Actions action =new Actions(driver);
					action.doubleClick(driver.findElement(By.xpath(".//div[text()='"+webListStatus.get(0).getAttribute("innerHTML")+"']"))).perform();
					Thread.sleep(10000);
					break;	
				}
			}
			oK.click();


			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Status name is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));

			System.out.println("Selected "+ val);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	/**
	 * Method To search Order On Order Cockpit Page
	 * @author Chinmay
	 * @throws InterruptedException 
	 */

	@SuppressWarnings("static-access")
	public String searchNcOnNcListPage(String ScreenshotRequire) throws InterruptedException{

		String val=null;
		int flag=0;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPage function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(10000);

			if(webListOrder==null){
			}
			for(WebElement ele :webListOrder){
				if(ele.isDisplayed()==true){
					if(ele.getAttribute("innerHTML").contains(" "))
					{
						System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
					}
					else {
						flag=1;
						val=ele.getAttribute("innerHTML"); 
						val=val+"_"+ncType.getText()+"_"+orderNO.getText()+"_"+createdBy.getText();
						driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']")).click();
						Thread.sleep(10000);
						Actions action =new Actions(driver);
						action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();
						Thread.sleep(10000);
						break;
					}


				}
				else{
					driver.findElement(By.xpath("//button[@class='ToolButton NextPage action action_page_next']")).click();
					driver.switchTo().defaultContent();
					common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
					Thread.sleep(15000);
					for(WebElement ele1 :webListOrder){
						if(ele1.isDisplayed()==true){
							if(ele1.getAttribute("innerHTML").contains(" "))
							{
								System.out.println("----ignore order---"+ele1.getAttribute("innerHTML"));
							}
							else {
								flag=1;
								val=ele1.getAttribute("innerHTML"); 
								val=val+"_"+ncType.getText()+"_"+orderNO.getText()+"_"+createdBy.getText();
								driver.findElement(By.xpath(".//span[text()='"+ele1.getAttribute("innerHTML")+"']")).click();
								Thread.sleep(10000);
								Actions action =new Actions(driver);
								action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele1.getAttribute("innerHTML")+"']"))).perform();
								Thread.sleep(10000);
								//break;
							}

							break;	
						}
					}
				}
				break;
			}
			Thread.sleep(10000);
			//Assert.assertEquals(flag, 1,  "Valid order list of status: "+line+" : is not displaying");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));

			System.out.println("clicked on order"+ val);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}
	@SuppressWarnings("static-access")
	public void validateNCderDetails(String ncId,String ncType,String orderNo,String createdBy, String ScreenshotRequire) throws InterruptedException{
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			System.out.println("inside validateOrderDetails function");
			Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+ncId+"']")).getText(),ncId,"Expected order number is not appearing on order operation page");
			Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+ncType+"']")).getText(),ncType,"Expected order number is not appearing on order operation page");
			Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+orderNo+"']")).getText(),orderNo,"Expected order number is not appearing on order operation page");
			Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+createdBy+"']")).getText(),createdBy,"Expected order number is not appearing on order operation page");
			WebTestCase.getTest().log(LogStatus.PASS, "Compared - NC id "+ncId+ "Verified - NC Type "+ncType+"Verified - Created By "+orderNo+"Verified - Order No  "+createdBy+" is displayed same as in Non Confirmity List Page With Respected fileds with NC Details Page"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	public void validateFooterButtons(String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		System.out.println("inside validateFooterButtons function");
		if(btnResolve.isEnabled()){
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the hold button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
		}
		else{
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the hold button is disablled as expected"+ common.captureScreenshot(ScreenshotRequire));	
		}

		if(btnSave.isEnabled()){
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Save button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
		}
		else{
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Save button is disablled as expected"+ common.captureScreenshot(ScreenshotRequire));	
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To Validate GeneralTab Contains
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public boolean validateNCDetails(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateGeneralTabContains function");
		boolean result=false;
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			//Common.isElementDisplayed(driver, ELX17iconRow, 100);

			System.out.println(nonConfirmityDetails.size());
			for(int i=0;i<nonConfirmityDetails.size();i++) {
				System.out.println(nonConfirmityDetails.get(i).getText());
				if((nonConfirmityDetails.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("Non-Conformity InformationField Values:"+nonConfirmityDetails.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "Non-Conformity InformationField Values"+"--"+nonConfirmityDetails.get(i).getAttribute("innerHTML")+"  --Data in Global Sheet:- " +hmAction.get(i+1).toLowerCase());
					result =true;
				}
				else{
					WebTestCase.getTest().log(LogStatus.INFO, "Non-Conformity InformationField Values Expected "+" -- "+nonConfirmityDetails.get(i).getAttribute("innerHTML")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
					result =false;
				}
				//+(i+1)
			}

			WebTestCase.getTest().log(LogStatus.INFO, "Non-Conformity InformationField Values validated successfully "+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return result;
	}

	public void verifyLineWindow(HashMap<Integer,String> hmAction, String ScreenshotRequire){
		System.out.println("inside verifyLineWindow");
		common.switchToFrame(By.xpath(iframepage), 120);
		common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
		Common.isElementDisplayed(driver, availbleItemTxt, IConstants.LOW_WAIT_TIME);
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Available Items Text Displayed"+ common.captureScreenshot(ScreenshotRequire));
		Common.isElementDisplayed(driver, selectedItemTxt, IConstants.LOW_WAIT_TIME);
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Selected items Text Displayed"+ common.captureScreenshot(ScreenshotRequire));

		for(int i=0;i<availableLines.size();i++) {		
			System.out.println(availableLines.get(i).getText());
			if((availableLines.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
				System.out.println(availableLines.get(i).getText());
				System.out.println("Available Lines in Line Window:"+availableLines.get(i).getAttribute("innerHTML"));
				WebTestCase.getTest().log(LogStatus.INFO, "Available Lines in Line Window"+"--"+availableLines.get(i).getAttribute("innerHTML"));
			}

			else{
				WebTestCase.getTest().log(LogStatus.FAIL, "Available Lines in Line Window "+" -- "+availableLines.get(i).getAttribute("innerHTML")+ " -- " + "  But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
			}
			//(i+1)+
		}

		WebTestCase.getTest().log(LogStatus.INFO, "Successfully validated  Available Lines in Line Window "+common.captureScreenshot(ScreenshotRequire));
		driver.switchTo().defaultContent();
	}
	
	/**
	 * Method To click On complete Button
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	public String clickOnCompleteButton(String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside clickOnCompleteButton function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			Common.isElementDisplayed(driver, completeBtn, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(completeBtn, "completeBtn");
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			System.out.println(" complete Button clicked");
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - clicked on complete button successfully"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);
	}
	/**
	 * Method To verify reason codes selection in repair NC page.
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String verifyReasonCodeAndclickOnCompleteButton(String code, String ScreenshotRequire) throws InterruptedException{

		try{
			System.out.println("verifyReasonCodeAndclickOnCompleteButton function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, reason, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 
			int size=level1ReasonCodeSelected.size();
			Common.isElementDisplayed(driver, level1ReasonCodeSelected.get(size-1), IConstants.SYS_WAIT_TIME);
			common.clickOnObject(level1ReasonCodeSelected.get(size-2), "level1ReasonCodeSelected");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			/*common.clickOnObject(ELX_RPCwindowclose, "ELX_RPCwindowclose");	
			Thread.sleep(3000);
			Common.isElementDisplayed(driver, completeBtn, IConstants.SYS_WAIT_TIME);
			common.clickOnObject(completeBtn, "completeBtn");
			Thread.sleep(3000);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );*/
			
			if(reasonCodeLevel.size()>0) {
				if(reasonCodeLevel.size()>1) {
					System.out.println("reason code size3:"+ reasonCodeLevel.size());
					int reasonCodeL=Common.generateRandomIntIntRange(0,(reasonCodeLevel.size()-1));
					System.out.println("RandomIntegerNumberlevel3 = "+reasonCodeL);
					Common.isElementDisplayed(driver, reasonCodeLevel.get(reasonCodeL), 30);
					String reasoncode=reasonCodeLevel.get(reasonCodeL).getText();
					Common.isElementDisplayed(driver, ELX_RPCwindowclose, IConstants.SYS_WAIT_TIME);
					common.clickOnObject(ELX_RPCwindowclose, "ELX_RPCwindowclose");	
					Thread.sleep(3000);
					Common.isElementDisplayed(driver, completeBtn, IConstants.SYS_WAIT_TIME);
					common.clickOnObject(completeBtn, "completeBtn");	
					Thread.sleep(5000);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
					WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code Level3."+ common.captureScreenshot(ScreenshotRequire));
					common.clickOnObject(level1ReasonCodeSelected.get(size-2), "level1ReasonCodeSelected");
					Thread.sleep(3000);
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(reasonCodeL));
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level3:"+ reasoncode+common.captureScreenshot(ScreenshotRequire));
					Common.isElementDisplayed(driver, completeBtn, IConstants.SYS_WAIT_TIME);
					common.clickOnObject(completeBtn, "completeBtn");	
					Thread.sleep(5000);
				}else {
					String reasoncode=reasonCodeLevel.get(0).getText();
					System.out.println("reasoncode3");
					Common.isElementDisplayed(driver, completeBtn, IConstants.SYS_WAIT_TIME);
					common.clickOnObject(completeBtn, "completeBtn");
					Thread.sleep(5000);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
					WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing if clicked on save button without selecting reason code level3."+ common.captureScreenshot(ScreenshotRequire));
					js.executeScript("arguments[0].click();", reasonCodeLevel.get(0));
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code Level3:"+ reasoncode+common.captureScreenshot(ScreenshotRequire));
					Common.isElementDisplayed(driver, completeBtn, IConstants.HIGH_WAIT_TIME);
					common.clickOnObject(completeBtn, "completeBtn");
					System.out.println("complete button clicked");
					WebTestCase.getTest().log(LogStatus.INFO, "Verified - Complete button clicked"+ common.captureScreenshot(ScreenshotRequire));
					Thread.sleep(5000);
				}
			}


			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);	

	}
	
	/**
	 * Method To search order status from dropdown
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")

	public void clickonExport(String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), 120);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, exportIcon, 100);
		Assert.assertTrue(exportIcon.isDisplayed()," Export Icon not displayed");
		
		if(exportIcon.isDisplayed())
		{
			common.clickOnObject(exportIcon, "exportIcon");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Export icon  is clicked "+ common.captureScreenshot(ScreenshotRequire));
			Assert.assertTrue(exportBtn.isDisplayed()," Export button  not Displayed");
			common.clickOnObject(exportBtn, "exportBtn");
			Thread.sleep(8000);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			WebTestCase.getTest().log(LogStatus.PASS, "Verified -  Export Button is clicked"+ common.captureScreenshot("true"));
			
		}
		else 
		{
			WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Export button is Not clicked"+ common.captureScreenshot(ScreenshotRequire));
		}
		driver.switchTo().defaultContent();
		
	}

	/**
	 * Method To get Last downloaded file name
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	public File getLatestFilefromDir(String dirPath){
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files == null || files.length == 0) {
	        return null;
	    }
	
	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           lastModifiedFile = files[i];
	       }
	    }
	    return lastModifiedFile;
	}
}
