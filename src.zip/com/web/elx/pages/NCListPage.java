package com.web.elx.pages;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.*;
import org.testng.Assert;

import com.elx.common.Common;
import com.elx.helper.*;
import com.relevantcodes.extentreports.LogStatus;
import java.text.*;

public class NCListPage {


	public WebDriver driver;
	private Common common;
	ReadConfig testData = new ReadConfig();

	public NCListPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}


	//NC Title
	@FindBy(xpath = "//li[@title='NCM-010']")
	private WebElement ncTitle;

	//NC Textbox
	@FindBy(xpath = ".//div[@class='Container vpBody']//tr[2]/td")
	private WebElement NcList; 

	@FindBy(xpath = ".//div[@class='Container vpBody']")
	private WebElement ContainerDiv; 

	//Cancel
	@FindBy(xpath ="//button[@class='ToolButton NCCANCEL']/span")
	private WebElement cancelButton;

	@FindBy(xpath = ".//div[@class='Container vpBody']//tr[2]/td")
	private List <WebElement> ncFirstRowdetails;


	@FindBy(xpath = ".//div[@class='Container vpBody']//tr[contains(@data-key,'MT')]")
	private List <WebElement> ncListDetails;


	@FindBy(xpath = ".//input[@data-field='serialno']")
	private  WebElement serialNumber;

	//NC Textbox
	@FindBy(xpath = "//input[@data-field='ncno']")
	private WebElement ncTextbox; 


	@FindBy(xpath = "(//input[@data-role='datetimepicker'])[1]")
	private WebElement datetimepicker; 	

	//Select NC number from grid
	@FindBy(xpath = "//*[contains(@id, 'content_BC_')]/tr[2]/td[1]")
	private WebElement ncIdNum;

	@FindBy(xpath ="//button[@class='ToolButton DETAILS T1 ']")
	private WebElement NCDetailsButton;

	//@FindBy(xpath ="//*[contains(@id, 'content_BC_')]/tr[2]/td[13]")
	@FindBy(xpath ="//td[@data-field='statuslist']")
	private WebElement NCStatus;

	@FindBy(xpath = ".//input[@data-field='createdbylist']")
	private  WebElement createdByList;

	@FindBy(xpath = ".//input[@data-field='workcenterlist']")
	private  WebElement workCenter;

	@FindBy(xpath = ".//*[contains(@data-field,'statuslist') and contains(@class,'value')]//span")
	private WebElement statusList;

	@FindBy(xpath = "//input[@data-field='createdbylist']")
	private WebElement createdByInput;

	@FindBy(xpath="//div[@class='ui-dialog-buttonset']/button[1]")
	private WebElement yes;

	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	@FindBy(xpath = ".//input[@data-field='reasonclass']")
	private  WebElement reasonclass;

	@FindBy(xpath = ".//td[@data-field='productionlinenolist']//a")
	private  WebElement productionlinenolist;

	@FindBy(xpath = ".//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//button[contains(@title,'deselect all') and not (contains(@style,'cursor: auto'))]")
	private WebElement deselectAllSelectedBtn;

	@FindBy(xpath = ".//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//button[contains(@title,'Remove selected') and not (contains(@style,'cursor: auto'))]")
	private WebElement removeSelectedBtn;


	@FindBy(xpath = "(//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//div[contains(@class,'vpBody')])[2]")
	private WebElement leftSideDivPanel;

	@FindBy(xpath = ".//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//span[contains(text(),'OK')]")
	private WebElement okBtn;

	@FindBy(xpath = ".//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//input")
	private WebElement popUpFilterTextBox;


	@FindBy(xpath = "(//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//div[contains(@class,'vpBody')])[1]//tr")
	private List <WebElement> lineSelectPopUp;

	@FindBy(xpath = ".//tr[contains(@data-key,'MTY')]/td[@data-field='ncno']")
	private  List <WebElement> listTotal	;


	@FindBy(xpath = "//*[@title='Home']")
	private  WebElement homeIcon	;

	@FindBy(xpath = ".//span[@class='pgTotal']")
	private  WebElement pgTotal	;

	@FindBy(xpath = "//*[contains(@data-field,'createdonlist') and contains(@placeholder,'From')]")
	private  WebElement createdonlistFrom	;

	@FindBy(xpath = ".//input[@data-field='productionordernolist']")
	private WebElement productionordernolist;



	/**
	 * Method To validate Nc Details On Nc List Page
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String validateNcDetailsOnNcListPage(String serialNO,String orderId,String userId,String wc, Hashtable<String, String> data, String ScreenshotRequire){	
		System.out.println("inside validate new NC details");
		String ncSerialNo = null;
		String ncNumber=null;
		try
		{

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, NcList, IConstants.SYS_WAIT_TIME);
			System.out.println("check for : "+serialNO+">>"+orderId+">>"+userId);
			WebTestCase.getTest().log(LogStatus.PASS, "NC list displayed"+ common.captureScreenshot(ScreenshotRequire));

			Common.isElementDisplayed(driver, reasonclass, IConstants.SYS_WAIT_TIME);
			common.clickOnObject(reasonclass, "reasonclass");
			reasonclass.clear();
			common.setObjectValue(reasonclass, "reasonclass", "NRFT");
			reasonclass.sendKeys(Keys.ENTER);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(5000);
			System.out.println("reason class entered");
			Common.isElementDisplayed(driver, reasonclass, IConstants.HIGH_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "reason class NRFT inserted:"+ common.captureScreenshot(ScreenshotRequire));


			Common.isElementDisplayed(driver, workCenter, IConstants.SYS_WAIT_TIME);
			common.clickOnObject(workCenter,"workCenter");
			workCenter.clear();
			common.setObjectValue(workCenter,"wc",wc);
			//Thread.sleep(20000);
			workCenter.sendKeys(Keys.TAB);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);
			System.out.println("work center entered:"+ wc);
			Common.isElementDisplayed(driver, workCenter, IConstants.HIGH_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "Work Center inserted:"+wc+ common.captureScreenshot(ScreenshotRequire));


			/*common.scrollIntoViewPage(serialNumber);
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",serialNumber);
			System.out.println("scrolled to serial number");
			Common.isElementDisplayed(driver, serialNumber, IConstants.SYS_WAIT_TIME);
			serialNumber.click();
			serialNumber.sendKeys(serialNO);
			Thread.sleep(5000);
			serialNumber.sendKeys(Keys.RETURN);
			Common.isElementDisplayed(driver, serialNumber, IConstants.SYS_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "serial number inserted "+serialNumber+ common.captureScreenshot());



			common.scrollIntoViewPage(createdByList);
			js.executeScript("arguments[0].scrollIntoView();",createdByList);
			Common.isElementDisplayed(driver, createdByList, IConstants.SYS_WAIT_TIME);
			System.out.println("scrolled to createdby");
			createdByList.click();
			createdByList.sendKeys(userId);
			createdByList.sendKeys(Keys.RETURN);
			Common.isElementDisplayed(driver, createdByList, IConstants.SYS_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "created By user inserted "+createdByList+ common.captureScreenshot());
			 */
			if(ContainerDiv.isDisplayed()) {
				ncNumber=ncFirstRowdetails.get(0).getText();

				String ncReasonCode=ncFirstRowdetails.get(5).getText();
				System.out.println(data.get("elx.reason.code") + "--"+ncReasonCode);
				//if(testData.getConfig().getProperty("elx.reason.code").contentEquals(ncReasonCode))
				if(ncReasonCode.contains("NRFT"))
				{	
					WebTestCase.getTest().log(LogStatus.PASS, "Reason code displayed in NC list:"+ncReasonCode+ common.captureScreenshot(ScreenshotRequire));
				}else {
					WebTestCase.getTest().log(LogStatus.PASS, "Correct reason code not displayed in NC list:"+ncReasonCode + common.captureScreenshot(ScreenshotRequire));
				}

				//Assert.(ncReasonCode,testData.getConfig().getProperty("elx.reason.code"),"Reason Code is displaying as expected");
				Thread.sleep(5000);
				String ncWorkCenter=ncFirstRowdetails.get(7).getText();
				WebTestCase.getTest().log(LogStatus.PASS, "Work center is displaying as expected:"+ncWorkCenter+ common.captureScreenshot(ScreenshotRequire));


				//String ncOrderId=ncFirstRowdetails.get(8).getText();
				/*Assert.assertEquals(ncOrderId, orderId,"Order Id is not displaying as expected");
			WebTestCase.getTest().log(LogStatus.PASS, "Order Id is displaying as expected:"+ncOrderId+ common.captureScreenshot());
				 */

				ncSerialNo=ncFirstRowdetails.get(10).getText();
				//Assert.assertEquals(ncSerialNo,serialNO, "Serial number is not displaying as expected ");
				WebTestCase.getTest().log(LogStatus.PASS, "Serial number is displaying as expected "+ncSerialNo+ common.captureScreenshot(ScreenshotRequire));


				String ncStatus=ncFirstRowdetails.get(12).getText();
				Assert.assertEquals(ncStatus,data.get("status.new"), "Status is not displaying correctly for new NC");
				WebTestCase.getTest().log(LogStatus.PASS, "Status is displaying for new NC: "+ncStatus+ common.captureScreenshot(ScreenshotRequire));

				//NcList.click();
				//WebTestCase.getTest().log(LogStatus.PASS, "Clicked on selected NC "+ common.captureScreenshot());
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "List not displayed"+ common.captureScreenshot(ScreenshotRequire));
			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return ncNumber;
	}


	/**
	 * Method To validate More than One NC can be created with same serial Number
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String validateNewNCDetailsWithSameSerialNumber(String serialNO, String ScreenshotRequire){	
		System.out.println("inside validateNewNCDetailsWithSameSerialNumber function");
		String ncNumber=null;
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, NcList, IConstants.SYS_WAIT_TIME);
			System.out.println("serialNO:: "+serialNO);

			common.scrollIntoViewPage(serialNumber);
			System.out.println("scrolled to serial number");
			Common.isElementDisplayed(driver, serialNumber, IConstants.SYS_WAIT_TIME);
			common.clickOnObject(serialNumber, "serialNumber");
			serialNumber.clear();
			common.setObjectValue(serialNumber, "serialNumber", serialNO);			
			serialNumber.sendKeys(Keys.RETURN);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, serialNumber, IConstants.SYS_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "serial number inserted "+serialNumber+ common.captureScreenshot(ScreenshotRequire));

			if(ncListDetails.size()>1) {
				WebTestCase.getTest().log(LogStatus.PASS, "More than one NC has been created with same serial Number: "+serialNO+ common.captureScreenshot("true"));
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "More than one NC cannt be created with same serial Number: "+serialNO+ common.captureScreenshot("true"));
			}
			Thread.sleep(4000);
			ncNumber=ncFirstRowdetails.get(0).getText();
			System.out.println("new NC: "+  ncNumber);
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return ncNumber;
	}

	public void clickNCDetails(String ncNum, String ScreenshotRequire)
	{
		try
		{
			//Enter NC#
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, ncTextbox, IConstants.SYS_WAIT_TIME);
			Assert.assertTrue(ncTextbox.isDisplayed(), "NC# Textbox not displayed");
			WebTestCase.getTest().log(LogStatus.INFO, "Enter the NC Number:" + ncNum);
			Thread.sleep(10000);
			common.setObjectValue(ncTextbox, "ncTextbox", ncNum);
			Common.isElementDisplayed(driver, ncTextbox, IConstants.SYS_WAIT_TIME);
			ncTextbox.sendKeys(Keys.ENTER);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertEquals(ncIdNum.getText(), ncNum,  "NC Number is not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Number is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
			common.clickOnObject(ncIdNum, "ncIdNum");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			driver.switchTo().defaultContent();


		}

		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}
	/**
	 * Method To search And click NC Details Button
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public void searchAndclickNCDetailsButton(String ncID, String ScreenshotRequire) throws InterruptedException{

		try {
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, ncTextbox, IConstants.SYS_WAIT_TIME);

			
			/*common.scrollIntoViewPage(datetimepicker);
			System.out.println("scroll to verify datetimepicker");	
			
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Date date1 = new Date();
			String time = sdf.format(date1);
		    System.out.println(time);
			
		    String previousDateStringval=common.DateString(time);
		    
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("document.getElementsByClassName('datetime filter active k-input').value = '"+previousDateStringval+"';");
			*/
			
		    
			/*JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("document.getElementsByClassName('datetime filter active k-input').value = '"+previousDateStringval+"';");
			
*/
			
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.scrollIntoViewPage(ncTextbox);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertTrue(ncTextbox.isDisplayed(), "NC# Textbox not displayed");
			WebTestCase.getTest().log(LogStatus.INFO, "Enter the NC Number:" + ncID);
			Thread.sleep(10000);
			common.setObjectValue(ncTextbox, "ncTextbox", ncID);
			Common.isElementDisplayed(driver, ncTextbox, IConstants.SYS_WAIT_TIME);
			ncTextbox.sendKeys(Keys.ENTER);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+ncID+"']")).getText(), ncID,  "NC Number is not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Number is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
			common.clickOnObject(ncIdNum, "ncIdNum");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.clickOnObject(NCDetailsButton,"NCDetailsButton");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(4000);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Details Button is clicked successfuly"+ common.captureScreenshot(ScreenshotRequire));

		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();

	}
	/**
	 * Method To validate NC Number And Status After NC Close
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public void validateNCNumberAndStatusAfterNCClose(String ncNum, String ScreenshotRequire)
	{	String img=null;
	try
	{	System.out.println("inside validateNCNumberAndStatusAfterNCClose function checking for Cancel NC status: "+ncNum);
	common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
	common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
	Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//span[text()='"+ncNum+"']")), IConstants.SYS_WAIT_TIME);
	img=common.captureScreenshot(ScreenshotRequire);
	WebTestCase.getTest().log(LogStatus.PASS, "Verified -NC List Page is appearing"+img);

	System.out.println(driver.findElement(By.xpath(".//span[text()='"+ncNum+"']")).getText()+" is apearing on the NC list");
	Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//span[text()='"+ncNum+"']")), IConstants.SYS_WAIT_TIME);
	Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+ncNum+"']")).getText(), ncNum,  "NC Number is not displayed");
	WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Number is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
	//i will check later
	common.scrollIntoViewPage(createdByInput);
	System.out.println("scroll to verify NC status");
	Common.isElementDisplayed(driver, NCStatus, IConstants.SYS_WAIT_TIME);
	String nStatusafterResolve=statusList.getText();
	if(statusList.getText().contains("Closed")||(statusList.getText().contains("Cancelled")))
	{
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Status " + nStatusafterResolve + " is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
	}
	System.out.println("NC status is appearing as:"+nStatusafterResolve);
	WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC status is appearing as:"+nStatusafterResolve+ common.captureScreenshot(ScreenshotRequire));

	}

	catch(java.lang.AssertionError exp1){
		System.out.println("Got Assertion Error..");
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp1.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp1.getMessage());
	}
	catch(Exception exp2){		
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp2.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp2.getMessage());
	}
	driver.switchTo().defaultContent();
	}
	/**
	 * Method To validate NC List Page Title
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateNCListPageTitle(String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, ncTitle, IConstants.LOW_WAIT_TIME);
		System.out.println("inside validateNCListPageTitle");
		driver.switchTo().defaultContent();
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Non-Conformity List page loaded"+ common.captureScreenshot(ScreenshotRequire));
	}
	/**
	 * Method To validate NC Number And Status After NC Resolve
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	public void validateNCNumberAndStatusAfterNCResolve(String ncNum, String ScreenshotRequire)
	{	String img=null;
	try
	{	System.out.println("inside validateNCNumberAndStatusAfterNCResolve function checking for resolved NC status: "+ncNum);
	common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
	common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
	Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//span[text()='"+ncNum+"']")), IConstants.SYS_WAIT_TIME);
	img=common.captureScreenshot(ScreenshotRequire);
	WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC List Page is appearing"+img);

	System.out.println(driver.findElement(By.xpath(".//span[text()='"+ncNum+"']")).getText()+" is apearing on the NC list");
	Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//span[text()='"+ncNum+"']")), IConstants.SYS_WAIT_TIME);
	Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+ncNum+"']")).getText(), ncNum,  "NC Number is not displayed");
	WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Number is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
	//i will check later
	common.scrollIntoViewPage(createdByInput);
	System.out.println("scroll to verify NC status");
	Common.isElementDisplayed(driver, NCStatus, IConstants.SYS_WAIT_TIME);
	String nStatusafterResolve=statusList.getText();
	if(statusList.getText().contains("Closed")||(statusList.getText().contains("Cancelled")))
	{
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Status " + nStatusafterResolve + " is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
	}
	System.out.println("NC status is appearing as:"+nStatusafterResolve);
	WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC status is appearing as:"+statusList.getText()+ common.captureScreenshot(ScreenshotRequire));

	}

	catch(java.lang.AssertionError exp1){
		System.out.println("Got Assertion Error..");
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp1.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp1.getMessage());
	}
	catch(Exception exp2){		
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp2.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp2.getMessage());
	}
	driver.switchTo().defaultContent();
	}
	/**
	 * Method To validate Cancel NC
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public void validateCancelNC(String ncID,String cancelStatus, String ScreenshotRequire)
	{
		try
		{
			System.out.println("inside validateCancelNC function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			
			/*common.scrollIntoViewPage(datetimepicker);
			System.out.println("scroll to verify datetimepicker");	
			
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Date date1 = new Date();
			String time = sdf.format(date1);
		    System.out.println(time);
			
		    String previousDateStringval=common.DateString(time);
		    
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("document.getElementsByClassName('datetime filter active k-input').value = '"+previousDateStringval+"';");
			*/
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.scrollIntoViewPage(ncTextbox);
			Common.isElementDisplayed(driver, ncTextbox, IConstants.SYS_WAIT_TIME);
			Assert.assertTrue(ncTextbox.isDisplayed(), "NC# Textbox not displayed");

			Thread.sleep(5000);
			ncTextbox.sendKeys(Keys.CLEAR);
			common.setObjectValue(ncTextbox, "ncTextbox", ncID);
			ncTextbox.sendKeys(Keys.TAB);
			Thread.sleep(8000);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertEquals(ncIdNum.getText(), ncID,  "NC Number is not displayed");
			WebTestCase.getTest().log(LogStatus.INFO, "Enter the NC Number:" + ncID);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Number is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));

			Thread.sleep(8000);
			common.clickOnObject(ncIdNum, "ncIdNum");
			WebTestCase.getTest().log(LogStatus.INFO, "Verify the Cancel NC button is enabled");
			Assert.assertTrue(cancelButton.isEnabled(),  "Cancel NC button not enabled");
			WebTestCase.getTest().log(LogStatus.PASS, "Verifyed - the Cancel NC button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
			common.clickOnObject(cancelButton,"cancelButton");
			WebTestCase.getTest().log(LogStatus.INFO, "Verifyed - the popup is appeard with Yes and No button"+ common.captureScreenshot(ScreenshotRequire));
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor)driver; 
			js.executeScript("arguments[0].click();", yes);
			WebTestCase.getTest().log(LogStatus.INFO, "Verifyed - Clicked on Yes option"+ common.captureScreenshot(ScreenshotRequire));

			Thread.sleep(8000);
			System.out.println("cancelled NC");
			driver.switchTo().defaultContent();
			//validateStatus(cancelStatus);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To click Home Icon
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void clickHomeIcon(String ScreenshotRequire) throws InterruptedException{
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, homeIcon, IConstants.MEDIUM_WAIT_TIME);
			Assert.assertTrue(homeIcon.isDisplayed(), "Home Icon not displayed");			
			//WebTestCase.getTest().log(LogStatus.PASS, "Verified - Home Icon present in Operation page"+ common.captureScreenshot());
			common.clickOnObject(homeIcon, "homeIcon");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			System.out.println("homeIcon clicked");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Home page is appearing"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

	}

	/**
	 * Method To validate created by system
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public void searchWithCreatedByAndTime(String createdBy, String ScreenshotRequire)
	{	
		try
		{	System.out.println("inside searchWithCreatedBy function");
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		common.scrollIntoViewPage(createdByInput);
		System.out.println("scroll to verify NC status");			
		Common.isElementDisplayed(driver, createdByInput, IConstants.SYS_WAIT_TIME);
		common.setObjectValue(createdByInput, createdBy, createdBy);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - created by system searched"+ common.captureScreenshot(ScreenshotRequire));
		Thread.sleep(20000);

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String time = sdf.format(date);
		System.out.println(time);


		//String dateString = "1/30/2019 12:00:00 AM";
		//System.out.println(previousDateString(time));
		String previousDateStringval=previousDateString(time)+" "+"12:00:00 AM";

		createdonlistFrom.click();
		Thread.sleep(5000);
		common.setObjectValue(createdonlistFrom, "createdonlistFrom", previousDateStringval);
		createdonlistFrom.sendKeys(Keys.TAB);
		Thread.sleep(15000);
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - From date entered"+ common.captureScreenshot(ScreenshotRequire));
		// ((JavascriptExecutor)driver).executeScript("document.getElementByXpath(createdonlistFrom).setAttribute('value',previousDateStringval)");
		/*WebElement calElement = driver.findElement(By.xpath("(//span[@class='k-icon k-i-calendar'])[1]"));
	calElement.click();

	 List <WebElement> selectDate = driver.findElements(By.xpath(".//td[@role='gridcell']/a"));
	 for(int i=0;i<selectDate.size();i++){ 
		 if(selectDate.get(i).getText().contains("29")) {
			 selectDate.get(i).click();
		 }
	 }
		 */

		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Thread.sleep(15000);

		common.scrollIntoViewPage(ncTextbox);
		System.out.println("scroll to verify pgTotal");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - createdBy List searched"+ common.captureScreenshot(ScreenshotRequire));


		}

		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To validate created by system
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public void searchWithLine(String line, String ScreenshotRequire)
	{	
		try
		{	System.out.println("inside searchWithLine function");
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );

		Common.isElementDisplayed(driver, productionlinenolist, IConstants.HIGH_WAIT_TIME);
		common.clickOnObject(productionlinenolist,"productionlinenolist");
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );

		Common.isElementDisplayed(driver, deselectAllSelectedBtn, IConstants.HIGH_WAIT_TIME);
		common.clickOnObject(deselectAllSelectedBtn,"deselectAllSelectedBtn");
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );

		if(removeSelectedBtn.isEnabled()) {
			common.clickOnObject(removeSelectedBtn,"removeSelectedBtn");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
		}

		/*if(popUpFilterTextBox.isDisplayed()) {
				common.setObjectValue(popUpFilterTextBox, line, line);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			}*/
		for(int i=0;i<lineSelectPopUp.size();i++) {
			if(lineSelectPopUp.get(i).getText().contains(line)) {
				common.clickOnObject(lineSelectPopUp.get(i),"Line");
				Actions action =new Actions(driver);
				action.doubleClick(lineSelectPopUp.get(i)).perform();
				System.out.println("clicked on Line"+ lineSelectPopUp.get(i).getText());
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - clicked on Line"+ common.captureScreenshot(ScreenshotRequire));
				break;
			}
		}
		if(leftSideDivPanel.getAttribute("innerText").length()>0) {
			System.out.println("value added from popup window");
			if(okBtn.isEnabled()) {
				common.clickOnObject(okBtn,"okBtn");
				System.out.println("ok button clicked");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
				Thread.sleep(20000);
			}
		}
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To validate NC List created by system
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public int validateNCList(String Line, String ScreenshotRequire)
	{	

		int totalList=0;
		try
		{	
			System.out.println("inside validateNCList function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			if(listTotal.size()>0) {
				totalList= Integer.parseInt(pgTotal.getText());
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Total NC List for: "+Line+"--"+ totalList+ common.captureScreenshot(ScreenshotRequire));
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Total NC List for: "+Line+"--"+ totalList+ common.captureScreenshot(ScreenshotRequire));
			}


		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){		
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return totalList;
	}

	public static String previousDateString(String dateString)
			throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

		Date myDate = dateFormat.parse(dateString);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(myDate);
		calendar.add(Calendar.DAY_OF_YEAR, -1);

		Date previousDate = calendar.getTime();
		String result = dateFormat.format(previousDate);

		return result;
	}
	/**
	 * Method To validate orderID and NC count
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public int searchOrderIdAndValidateNCCount(String orderID, String ScreenshotRequire)
	{	int NCSize=0;
	try
	{	
		System.out.println("inside searchWithOrderId function");
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, productionordernolist, IConstants.HIGH_WAIT_TIME);
		common.setObjectValue(productionordernolist, "orderID", orderID);
		productionordernolist.sendKeys(Keys.ENTER);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );

		if(ncListDetails.size()>1) {
			NCSize=ncListDetails.size();
			WebTestCase.getTest().log(LogStatus.PASS, "NC has been created for the order>>: "+orderID+ common.captureScreenshot(ScreenshotRequire));
		}else {
			WebTestCase.getTest().log(LogStatus.FAIL, "NC has not been created for the order>>:"+orderID+ common.captureScreenshot(ScreenshotRequire));
		}

	}catch(java.lang.AssertionError exp1){
		System.out.println("Got Assertion Error..");
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp1.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp1.getMessage());
	}
	catch(Exception exp2){		
		WebTestCase.getTest().log(LogStatus.FAIL,
				exp2.getMessage() + common.captureScreenshot("true"));
		Assert.fail(exp2.getMessage());
	}
	driver.switchTo().defaultContent();
	return NCSize;
	}
}
