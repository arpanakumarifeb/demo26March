package com.web.elx.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class ORD20Page {
	
	String orderID;
	String productID;
	String orderStatus;
	SoftAssert softAssert=new SoftAssert();
	
	public OrderCockpitPage ordCockpit;
	@FindBy(xpath = "//*[contains(@id, 'BC_')]//div[2]/div[1]/table/thead/tr[2]/td[1]/div[1]/input")
	private WebElement orderTextbox;
	
	@FindBy(xpath ="//*[contains(@class, 'ELX_GridColorCode')]/td[1]/div/span")
	private WebElement ordId;
	
	@FindBy(xpath = "//tr[@class='HeadF']/td[4]/div/input")
	private WebElement productTextbox;
	
	//Product Number - Select from first row
	@FindBy(xpath ="//*[contains(@class, 'ELX_GridColorCode')]/td[4]/div/span")
	private WebElement prodId;
	
	//Status - Select from first row
	@FindBy(xpath ="//*[contains(@class, 'ELX_GridColorCode')]/td[3]/div/span")
	private WebElement status;
	
	//ORD20 Operator title
	@FindBy(xpath ="//*[text()='Operations']")
	private WebElement labelOperator;
	
	//Details Tab
	@FindBy(xpath ="//*[contains(@class, 'ELX_GridColorCode')]/td[11]/div/button")
	private WebElement detailsTab;
	
	//ORD20 OrderId
	@FindBy(xpath ="//*[@class='Label fl_WipOrderTypeName']/../td[2]/span")
	private WebElement orderIdORD20;
	
	//ORD20 ProductId
	@FindBy(xpath ="//*[@class='Label fl_ProductDesc']/../td[2]/span")
	private WebElement productIdORD20;
	
	//ORD20 Status
	@FindBy(xpath ="//*[@class='Control fc_WipOrderStatus Bold']/span")
	private WebElement statusORD20;
	
	
	//ORD20LeftPane Order Number
	@FindBy(xpath ="//*[@class='apr-font-me apr-image apr-and-img-status-new']")
	private WebElement leftPaneOrdId;
	
	@FindBy(xpath ="//*[contains (@id, 'BC_')]/tbody/tr[3]/td/div/span[2]/apr-image/text()")
	private WebElement workCenterL2CH;
	
	//ord20 General Tab
	@FindBy(xpath ="//*[@class='apr-cttabscrolled-tabscrolledcontainer TabList']/button[1]")
	private WebElement generalTab;
	
	//ord20 Components Tab
	@FindBy(xpath ="//*[@class='apr-cttabscrolled-tabscrolledcontainer TabList']/button[2]")
	private WebElement componentsTab;
	
	//ord20 NonConformance Tab
	@FindBy(xpath ="//*[@class='apr-cttabscrolled-tabscrolledcontainer TabList']/button[3]")
	private WebElement nonConformanceTab;
	//ord20 SerialNo Tab
	@FindBy(xpath ="//*[@class='apr-cttabscrolled-tabscrolledcontainer TabList']/button[4]")
	private WebElement serialNoTab;
	//ord20 ToolsTab
	@FindBy(xpath ="//*[@class='apr-cttabscrolled-tabscrolledcontainer TabList']/button[4]")
	private WebElement toolsTab;
	
	private WebDriver driver;
	private Common common;
	
	public ORD20Page(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}
	
	

}
