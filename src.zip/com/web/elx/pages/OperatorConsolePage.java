package com.web.elx.pages;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class OperatorConsolePage {


	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	@FindBy(xpath = "//div[contains(@class,'ELX_Button')]//span[(contains(@style,'top'))]")
	private List <WebElement> ELXSelectActionList;

	@FindBy(xpath = "//span[text()='Create NC']")
	private WebElement createNC;
	
	@FindBy(xpath = ".//button[@runat='server']/span")
	private List <WebElement> ELXButtonList;

	@FindBy(xpath = "//*[contains(@id,'ELX_SelectAction')]")
	private WebElement mousehoverIcons;

	@FindBy(xpath = ".//li[@title='POE-020']")
	private WebElement pageTitle;
	
	@FindBy(xpath = ".//td[@class='Control fc_WipOrderNo']/span")
	private WebElement WipOrderNo;
	
	@FindBy(xpath = ".//td[@class='Control fc_Area Bold']/span")
	private WebElement WipArea;
	
	@FindBy(xpath = ".//td[@class='Control fc_OrderQuantity']/span")
	private WebElement WipOrderQuantity;
	
	@FindBy(xpath = ".//td[@class='Control fc_ProductNo']/span")
	private WebElement WipProductNo;
	
	
	@FindBy(xpath = ".//td[@class='Control fc_QuantityProduced Bold']/span")
	private WebElement WipQuantityProduced;

	@FindBy(xpath = ".//td[@class='Control fc_GoodQuantity Bold']/span")
	private WebElement WipGoodQuantity;
	
	@FindBy(xpath = ".//button[@value='START']/span")
	private WebElement startBtn;
	
	@FindBy(xpath = ".//button[@value='REPORT']/span")
	private WebElement reportBtn;
	
	@FindBy(xpath = ".//button[@value='GOTO_NC']/span")
	private WebElement GOTO_NCBtn;
	
	@FindBy(xpath = ".//button[@value='GEN_CON']/span")
	private WebElement GEN_CONBtn;
	
	@FindBy(xpath = "//*/div[@class='ELX_Button_NC']/div[@class='ELX_Button_Triangle']//..//span[@class='number']")
	private WebElement ncIco;
	
	@FindBy(xpath = "//*/div[@class='ELX_Button_NC']")
	private WebElement ncIconst;
	
	//@FindBy(xpath = "//*/div[@class='ELX_BigSize Hidde']")
	@FindBy(xpath = ".//div[contains(@class,'ELX_BigSize Hidde') and (contains(@style,'display: block'))]")
	private WebElement SelectOperationWindow;
	
	
	@FindBy(xpath = "//*/div[@id='ELX_SelectOperation']/div")
	private List <WebElement> ELX_SelectOperation;
	
	
	
	
	



	private WebDriver driver;
	private Common common;

	public OperatorConsolePage(WebDriver driver2){
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}



	/**
	 * Method To validateHeaderButtons
	 * @author Arpana
	 * @throws InterruptedException
	 */
	@SuppressWarnings("static-access")
	public void validateHeaderButtons(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateHeaderButtons function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.SYS_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, mousehoverIcons, IConstants.SYS_WAIT_TIME);
			
			for(int i=0;i<ELXSelectActionList.size();i++) {				
				if((ELXSelectActionList.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("Available Button in Header Section:"+ELXSelectActionList.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.PASS, "Available Button in Header Section"+(i+1)+"--"+ELXSelectActionList.get(i).getAttribute("innerHTML").toLowerCase()+ " -- " + "   Data in Global Sheet:- " +hmAction.get(i+1).toLowerCase());
				}else{
					WebTestCase.getTest().log(LogStatus.FAIL, "Available Button in Header Section Expected "+" -- "+ELXSelectActionList.get(i).getAttribute("innerHTML")+ " -- " + "  But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
				}
			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	
	public String clickCreateNC(String ScreenshotRequire){
		String img=null;
		try{
			common.switchToFrame(By.xpath(iframepage),  IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),  IConstants.HIGH_WAIT_TIME);
			Common.isElementDisplayed(driver, createNC,  IConstants.HIGH_WAIT_TIME);
			img=common.captureScreenshot(ScreenshotRequire);
			common.clickOnObject(createNC, "createNC");
			common.waitTillElementDisappears(By.xpath(toolbox),  IConstants.HIGH_WAIT_TIME);
			System.out.println("clicked on CreateNC btn");
		}catch(java.lang.AssertionError e){
				System.out.println("Got Assertion Error:" +e);
				WebTestCase.getTest().log(LogStatus.FAIL,
						e.getMessage() + common.captureScreenshot("true"));
				Assert.fail(e.getMessage());
			}
			catch(Exception e1){

				WebTestCase.getTest().log(LogStatus.FAIL,
						e1.getMessage() + common.captureScreenshot("true"));
				Assert.fail(e1.getMessage());
			}
			driver.switchTo().defaultContent();
			return img;
	}

	/**
	 * Method To validatefooterbuttons
	 * @author Chinmay
	 * @throws InterruptedException
	 */

	@SuppressWarnings("static-access")
	public void validatefooterbuttons(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validatefooterbuttons function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			//Common.isElementDisplayed(driver, ELXPrimaryButtonList, 100);


			for(int i=0;i<ELXButtonList.size();i++) {				
				if((ELXButtonList.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("Available Button in Footer Section:"+ELXButtonList.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "Available Button in Footer Section"+(i+1)+"--"+ELXButtonList.get(i).getAttribute("innerHTML").toLowerCase()+ " -- " + "   Data in Global Sheet:- " +hmAction.get(i+1).toLowerCase());
				}

				else{
					WebTestCase.getTest().log(LogStatus.INFO, "Available Button in Footer Section Expected "+" -- "+ELXButtonList.get(i).getAttribute("innerHTML")+ " -- " + "  But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
				}

			}

			WebTestCase.getTest().log(LogStatus.INFO, "Successfully validated  Buttons present in Footer sections of OpertorConsole screen "+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	/**
	 * Method To validateOperatorConsolePageTitle
	 * @author Arpana
	 * @throws InterruptedException
	 */

	public void validateOperatorConsolePageTitle(String title, String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside validateOperatorConsolePageTitle function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, pageTitle, IConstants.LOW_WAIT_TIME);
			Assert.assertEquals(pageTitle.getText(), title,"Operator Console page title is not appearing correctly");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Operator Console page loaded: Title is:"+pageTitle.getText()+ common.captureScreenshot(ScreenshotRequire));

		}catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){
			System.out.println("Got Exception :" +e1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("tre"));
			Assert.fail(e1.getMessage());
		}driver.switchTo().defaultContent();
	}
	
	/**
	 * Method To validateOrderDetailsOnOperatorConsolePage
	 * @author Arpana
	 * @throws InterruptedException
	 */

	public void validateOrderDetailsOnOperatorConsolePage(HashMap<String,String> hm, String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside validateOrderDetailsOnOperatorConsolePage function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, WipOrderNo, IConstants.LOW_WAIT_TIME);
			
			Assert.assertEquals(WipOrderNo.getText(), hm.get("orderNo"),"Order Number is not displaying correctly on Operator Console page");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order Number is  displaying correctly on Operator Console page: "+WipOrderNo.getText()+ common.captureScreenshot(ScreenshotRequire));
			
			Assert.assertEquals(WipArea.getText(), hm.get("WC"),"Area is not displaying correctly on Operator Console page");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Area is  displaying correctly on Operator Console page: "+WipArea.getText());

			Assert.assertEquals(WipOrderQuantity.getText(), hm.get("PlannedQuantity"),"Planned qty is not displaying correctly on Operator Console page");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Planned qty is  displaying correctly on Operator Console page: "+WipOrderQuantity.getText());

			Assert.assertEquals(WipProductNo.getText(), hm.get("ProductNo"),"Model Number is not displaying correctly on Operator Console page");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Model Number is  displaying correctly on Operator Console page: "+WipProductNo.getText());

			Assert.assertEquals(WipQuantityProduced.getText(), hm.get("GoodQuantity"),"Quantity Produced is not displaying correctly on Operator Console page");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Quantity Produced is  displaying correctly on Operator Console page: "+WipQuantityProduced.getText());
		
			
		}catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){
			System.out.println("Got Exception :" +e1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}driver.switchTo().defaultContent();
	}
	
	/**
	 * Method To startHoldOrderOnOperatorConsolePage
	 * @author Arpana
	 * @throws InterruptedException
	 */

	public void startHoldOrderOnOperatorConsolePage(String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside startHoldOrderOnOperatorConsolePage function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, startBtn, IConstants.LOW_WAIT_TIME);
			if(startBtn.isEnabled()) {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Start Button is appearing on operator console Page "+common.captureScreenshot(ScreenshotRequire));
				common.clickOnObject(startBtn, "startBtn");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				System.out.println("start button clicked");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Start Button is clicked on operator console Page ");
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Start Button is not appearing on operator console Page"+ common.captureScreenshot(ScreenshotRequire));
			}
		}catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){
			System.out.println("Got Exception :" +e1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}driver.switchTo().defaultContent();
	}
	
	/**
	 * Method To vaidateNonConformityIconCount
	 * @author Arpana
	 * @throws InterruptedException
	 */
	
	public String vaidateNonConformityIconCount(String ScreenshotRequire)
	{
		String NCCount=null;

		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			Common.isElementDisplayed(driver, mousehoverIcons, IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver,ncIconst, IConstants.HIGH_WAIT_TIME);
			Thread.sleep(10000);
			NCCount=ncIco.getText();	
			System.out.println("Count value shown:"+NCCount);
			if(NCCount.trim().equals("-")||Integer.parseInt(NCCount)==0) 
			{
				System.out.println("NC count is not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "count of NC is "+NCCount+ common.captureScreenshot(ScreenshotRequire));
				NCCount="0";

			}
			else {			
				WebTestCase.getTest().log(LogStatus.PASS, "current NC count:"+NCCount+ common.captureScreenshot(ScreenshotRequire));
			}
		}catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return NCCount;
	}
	
	public String selectOperation(String ScreenshotRequire){
		String OperationText=null;
		System.out.println("inside selectOperation function");
		try{
			common.switchToFrame(By.xpath(iframepage),  IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME);
			Thread.sleep(15000);
			if(SelectOperationWindow.isDisplayed()) {
			JavascriptExecutor js = (JavascriptExecutor)driver; 
			
			int operation=Common.generateRandomIntIntRange(0,(ELX_SelectOperation.size()-2));
			System.out.println("operation number = "+operation);
			Common.isElementDisplayed(driver, ELX_SelectOperation.get(operation), 30);
			OperationText=ELX_SelectOperation.get(operation).getText();
			js.executeScript("arguments[0].click();", ELX_SelectOperation.get(operation));
			common.waitTillElementDisappears(By.xpath(toolbox), 800);
			Thread.sleep(5000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on Operation:"+OperationText+ common.captureScreenshot(ScreenshotRequire));
			System.out.println("clicked on operation btn");
			}else {
				System.out.println("no operation for Workcenter");
			}
		}catch(java.lang.AssertionError e){
				System.out.println("Got Assertion Error:" +e);
				WebTestCase.getTest().log(LogStatus.FAIL,
						e.getMessage() + common.captureScreenshot("true"));
				Assert.fail(e.getMessage());
			}
			catch(Exception e1){

				WebTestCase.getTest().log(LogStatus.FAIL,
						e1.getMessage() + common.captureScreenshot("true"));
				Assert.fail(e1.getMessage());
			}
			driver.switchTo().defaultContent();
			return OperationText;
	}
}
