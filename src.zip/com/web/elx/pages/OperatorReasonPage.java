package com.web.elx.pages;

import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;
public class OperatorReasonPage {



	@FindBy(xpath = ".//div[contains(text(),'REASON')]")
	private WebElement reasontext;

	@FindBy(xpath = ".//div[@class='Content Level1']")
	private WebElement reasonlevel1;

	@FindBy(xpath = ".//input[contains(@class,'SerialNo')]")
	private WebElement SerialNoInput;

	@FindBy(xpath = ".//div[@class='apr-message-error']")
	private WebElement errMessage;

	@FindBy(xpath = "//*[@id='header']/div/div")
	private WebElement dshmain;

	@FindBy(xpath = "//*[@id='DashboardContent']")
	private WebElement colorheader;

	@FindBy(xpath = ".//span[@id='ELX_Header_Information']")
	private WebElement ELXHeader;

	@FindBy(xpath = ".//span[@id='spanOrderName']")
	private WebElement orderName;

	@FindBy(xpath = ".//span[@id='spanToDoQty']")
	private WebElement spanToDoQty;

	@FindBy(xpath = ".//span[@id='spanDoneQty']")
	private WebElement spanDoneQty;

	@FindBy(xpath = ".//span[@id='spanPlannedQty']")
	private WebElement spanPlannedQty;

	@FindBy(xpath = ".//span[text()='STOP']")
	private WebElement stopButton;

	@FindBy(xpath = ".//div[contains(text(),'REASON')]")
	private WebElement reasonText;



	@FindBy(xpath = ".//div[@class='Level1']")
	private List <WebElement> stopReasonLevel1;

	@FindBy(xpath = ".//div[@class='Level2']")
	private List <WebElement> stopReasonLevel2;

	@FindBy(xpath = ".//div[@class='Level3']")
	private List <WebElement> stopReasonLevel3;

	@FindBy(xpath = ".//div[@class='Content Level1']")
	private WebElement helpReason;

	@FindBy(xpath = ".//div[@class='Level1']")
	private List <WebElement> helpReasonLevel1;

	@FindBy(xpath = ".//div[@class='Level2']")
	private List <WebElement> helpReasonLevel2;

	@FindBy(xpath = ".//div[@class='Content Level1']")
	private WebElement nonConfReason;

	@FindBy(xpath = ".//div[@class='Level1']")
	private List <WebElement> nonConfReasonLevel1;

	@FindBy(xpath = ".//div[@class='Level2']")
	private List <WebElement> nonConfReasonLevel2;

	@FindBy(xpath = ".//div[@id='ELX_SelectOperation_Reason']/div[contains(@class,'Level3')]")
	private List <WebElement> nonConfReasonLevel3;
	
	@FindBy(xpath = ".//div[@id='ELX_SelectOperation_Reason']/div[contains(@class,'Level4')]")
	private List <WebElement> nonConfReasonLevel4;




	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";


	private WebDriver driver;
	private Common common;

	public OperatorReasonPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}



	public String validateOperationPageTitle(String Line,String wc, String ScreenshotRequire) throws InterruptedException{
		try
		{	System.out.println("inside validate operation page title function");
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME);
		Common.isElementDisplayed(driver, ELXHeader, IConstants.MEDIUM_WAIT_TIME);
		Assert.assertTrue(ELXHeader.getText().contains(Line),  "Main operation page not displayed");
		Assert.assertTrue(ELXHeader.getText().contains(wc),  "Main operation page not displayed");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Main operation page is displayed successfuly"+ common.captureScreenshot(ScreenshotRequire));
		System.out.println("Main operation title:"+ELXHeader.getText());
		driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);
	}


	public String selectOrderNumber(String ScreenshotRequire) throws InterruptedException{
		String orderAndQuan=null;
		try
		{	
			System.out.println("inside selectOrderNumber function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(4000);
			Common.isElementDisplayed(driver, ELXHeader, IConstants.MEDIUM_WAIT_TIME);
			Assert.assertTrue(orderName.isEnabled(),  "order number not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - order number is displayed successfuly:"+orderName.getText()+ common.captureScreenshot(ScreenshotRequire));
			System.out.println("order number:"+orderName.getText());
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		orderAndQuan=orderName.getText()+"_"+spanToDoQty.getText()+"_"+spanDoneQty.getText()+"_"+spanPlannedQty.getText();
		return orderAndQuan;
	}

	public String clickOnButton(String val, String ScreenshotRequire) throws InterruptedException{
		String img=common.captureScreenshot(ScreenshotRequire);
		try{
			System.out.println("clickOnButton method : selecting button "+val);
			WebElement clickOption=driver.findElement(By.xpath("//span[contains(text(),'"+val+"')]"));
			Common.isElementDisplayed(driver, clickOption, 30);
			Assert.assertTrue(clickOption.isDisplayed(),clickOption.getText()+" Button not available");
			WebTestCase.getTest().log(LogStatus.INFO, "Verified the " +val +" item is present"+ common.captureScreenshot(ScreenshotRequire));
			clickOption.click();
			System.out.println("clicked On Button");
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}

	public String validateReasonText(String val, String ScreenshotRequire) throws InterruptedException{
		String img=common.captureScreenshot(ScreenshotRequire);
		try{
			System.out.println("validateReasonText function "+val);
			WebElement reasonText=driver.findElement(By.xpath("//div[contains(text(),'"+val+"')]"));
			Common.isElementDisplayed(driver, reasonText, 30);
			Assert.assertTrue(reasonText.isDisplayed(),reasonText.getText()+" text not available");
			WebTestCase.getTest().log(LogStatus.INFO, "Verified the " +reasonText.getText() +" item is present"+ common.captureScreenshot(ScreenshotRequire));
			System.out.println("reason Text" +reasonText);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}

	/**
	 * Method To select Help Reason Codes
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String selectHelpReasonCodes(String code1,String code2, String ScreenshotRequire) throws InterruptedException{

		try{
			System.out.println("inside reason code function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, reasonlevel1, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//div[@class='Content Level1']//span[text()='"+code1+"']")), 30);
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//div[@class='Content Level1']//span[text()='"+code1+"']")));
			Thread.sleep(15000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+code1+ common.captureScreenshot(ScreenshotRequire));	

			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//div[@class='Content Level2']//span[text()='"+code2+"']")),  IConstants.HIGH_WAIT_TIME);
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//div[@class='Content Level2']//span[text()='"+code2+"']")));
			Thread.sleep(15000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+code2+ common.captureScreenshot(ScreenshotRequire));

			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.." +exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);	

	}


	public String selectReasonCodes(String ScreenshotRequire) throws InterruptedException{
		String reasonCodeVal=null;
		try{
			System.out.println("inside reason code function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, reasonlevel1, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 

			if(stopReasonLevel1.size()>0) {
				String reasoncode1=null;
				if(stopReasonLevel1.size()>1) {
					int reasonCodeL1=Common.generateRandomIntIntRange(0,(stopReasonLevel1.size()-1));
					System.out.println("RandomIntegerNumberlevel1 = "+reasonCodeL1);
					Common.isElementDisplayed(driver, stopReasonLevel1.get(reasonCodeL1), 30);
					reasoncode1=stopReasonLevel1.get(reasonCodeL1).getText();
					js.executeScript("arguments[0].click();", stopReasonLevel1.get(reasonCodeL1));
					Thread.sleep(15000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+ reasoncode1+common.captureScreenshot(ScreenshotRequire));
				}else {
					reasoncode1=stopReasonLevel1.get(0).getText();
					js.executeScript("arguments[0].click();", stopReasonLevel1.get(0));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+ stopReasonLevel1.get(0).getText()+common.captureScreenshot(ScreenshotRequire));
				}
				reasonCodeVal=reasoncode1;
			}

			if(stopReasonLevel2.size()>0) {
				String reasoncode2=null;
				if(stopReasonLevel2.size()>1) {
					int reasonCodeL2=Common.generateRandomIntIntRange(0,(stopReasonLevel2.size()-1));
					System.out.println("RandomIntegerNumberlevel2 = "+reasonCodeL2);
					Common.isElementDisplayed(driver, stopReasonLevel2.get(reasonCodeL2), 30);
					reasoncode2=stopReasonLevel2.get(reasonCodeL2).getText();
					js.executeScript("arguments[0].click();", stopReasonLevel2.get(reasonCodeL2));
					Thread.sleep(15000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+ reasoncode2+common.captureScreenshot(ScreenshotRequire));
				}else {
					reasoncode2=stopReasonLevel2.get(0).getText();
					js.executeScript("arguments[0].click();", stopReasonLevel2.get(0));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+ stopReasonLevel2.get(0).getText()+common.captureScreenshot(ScreenshotRequire));
				}
				reasonCodeVal=reasonCodeVal+"_"+reasoncode2;
			}

			if(stopReasonLevel3.size()>0) {
				String reasoncode3=null;
				if(stopReasonLevel3.size()>1) {
					int reasonCodeL3=Common.generateRandomIntIntRange(0,(stopReasonLevel3.size()-1));
					System.out.println("RandomIntegerNumberlevel3 = "+reasonCodeL3);
					Common.isElementDisplayed(driver, stopReasonLevel3.get(reasonCodeL3), 30);
					reasoncode3=stopReasonLevel3.get(reasonCodeL3).getText();
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+ reasoncode3+common.captureScreenshot(ScreenshotRequire));
					js.executeScript("arguments[0].click();", stopReasonLevel3.get(reasonCodeL3));
					Thread.sleep(15000);

				}else {
					reasoncode3=stopReasonLevel3.get(0).getText();
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+ stopReasonLevel3.get(0).getText()+common.captureScreenshot(ScreenshotRequire));
					js.executeScript("arguments[0].click();", stopReasonLevel3.get(0));
					Thread.sleep(5000);

				}
				reasonCodeVal=reasonCodeVal+"_"+reasoncode3;
			}
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.." +exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return reasonCodeVal;	

	}

	public String selectReasonCodes(String code1,String code2,String code3, String ScreenshotRequire) throws InterruptedException{

		try{
			System.out.println("inside reason code function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, reasonlevel1, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 
			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//div[@class='Content Level1']//span[text()='"+code1+"']")), 30);
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//div[@class='Content Level1']//span[text()='"+code1+"']")));
			Thread.sleep(15000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+code1+ common.captureScreenshot(ScreenshotRequire));	

			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//div[@class='Content Level2']//span[text()='"+code2+"']")),  IConstants.HIGH_WAIT_TIME);
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//div[@class='Content Level2']//span[text()='"+code2+"']")));
			Thread.sleep(15000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+code2+ common.captureScreenshot(ScreenshotRequire));


			Common.isElementDisplayed(driver, driver.findElement(By.xpath(".//div[@class='Content Level3']//span[text()='"+code3+"']")),  IConstants.HIGH_WAIT_TIME);
			js.executeScript("arguments[0].click();", driver.findElement(By.xpath(".//div[@class='Content Level3']//span[text()='"+code3+"']")));
			Thread.sleep(15000);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on reason code:"+code3+ common.captureScreenshot(ScreenshotRequire));

			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.." +exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);	

	}

	public String EnterSerialNo(String val, String sharedFlag, String ScreenshotRequire) throws InterruptedException{
		String img=common.captureScreenshot(ScreenshotRequire);
		try{
			System.out.println("EnterSerialNo method : Entering  "+val);

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, SerialNoInput, IConstants.HIGH_WAIT_TIME);
			Thread.sleep(4000);
			if(sharedFlag.contains(";")&&(val!=null)) {
				Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing for shared WC without Entering serial number"+ common.captureScreenshot(ScreenshotRequire));

				common.setObjectValue(SerialNoInput, "SerialNoInputValue", val);
				Thread.sleep(3000);
				WebTestCase.getTest().log(LogStatus.INFO, "Serial No entered"+ common.captureScreenshot(ScreenshotRequire));
				System.out.println("Entered On SerialNoInput");
			}else {
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Serial number is not required for non-shared WC"+ common.captureScreenshot(ScreenshotRequire));

			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}

	public String selectNonConfReasonCodes(String val, String sharedFlag, String ScreenshotRequire) throws InterruptedException{
		String reasonCodeVal=null;
		try{
			System.out.println("inside selectNonConfReasonCodes");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, nonConfReason, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 

			if(nonConfReasonLevel1.size()>0) {
				String reasoncode1=null;
				if(nonConfReasonLevel1.size()>1) {
					int reasonCodeL1=Common.generateRandomIntIntRange(0,(nonConfReasonLevel1.size()-2));
					Common.isElementDisplayed(driver, nonConfReasonLevel1.get(reasonCodeL1), 30);
					reasoncode1=nonConfReasonLevel1.get(reasonCodeL1).getText();
					System.out.println("RandomIntegerNumberlevel1 = "+reasoncode1);
					js.executeScript("arguments[0].click();", nonConfReasonLevel1.get(reasonCodeL1));
					Thread.sleep(15000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on NC reason code Level1:"+ reasoncode1+common.captureScreenshot(ScreenshotRequire));
				}else {
					reasoncode1=nonConfReasonLevel1.get(0).getText();
					System.out.println("RandomIntegerNumberlevel1 = "+reasoncode1);
					js.executeScript("arguments[0].click();", nonConfReasonLevel1.get(0));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on NC reason code Level1:"+ reasoncode1+common.captureScreenshot(ScreenshotRequire));
				}
				reasonCodeVal=reasoncode1;
			}

			if(nonConfReasonLevel2.size()>0) {
				String reasoncode2=null;
				if(nonConfReasonLevel2.size()>1) {
					int reasonCodeL2=Common.generateRandomIntIntRange(0,(nonConfReasonLevel2.size()-1));
					Common.isElementDisplayed(driver, nonConfReasonLevel2.get(reasonCodeL2), 30);
					reasoncode2=nonConfReasonLevel2.get(reasonCodeL2).getText();
					System.out.println("RandomIntegerNumberlevel2 = "+reasoncode2);
					js.executeScript("arguments[0].click();", nonConfReasonLevel2.get(reasonCodeL2));
					Thread.sleep(15000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on NC reason code Level2:"+ reasoncode2+common.captureScreenshot(ScreenshotRequire));
				}else {
					reasoncode2=nonConfReasonLevel2.get(0).getText();
					System.out.println("RandomIntegerNumberlevel2 = "+reasoncode2);
					js.executeScript("arguments[0].click();", nonConfReasonLevel2.get(0));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on NC reason code Level2:"+ reasoncode2+common.captureScreenshot(ScreenshotRequire));
				}
				reasonCodeVal=reasonCodeVal+"_"+reasoncode2;
			}

			if(nonConfReasonLevel3.size()>0) {
				String reasoncode3=null;
					reasoncode3=nonConfReasonLevel3.get(0).getText();
					System.out.println("RandomIntegerNumberlevel3 = "+reasoncode3);
					js.executeScript("arguments[0].click();", nonConfReasonLevel3.get(0));
					Thread.sleep(4000);
					if(sharedFlag.contains(";")&&(val!=null)) {
						Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
						WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing for shared WC without Entering serial number::"+ errMessage.getText()+ common.captureScreenshot(ScreenshotRequire));
						common.setObjectValue(SerialNoInput, "SerialNoInputValue", val);
						Thread.sleep(3000);
						WebTestCase.getTest().log(LogStatus.INFO, "Serial No entered"+ common.captureScreenshot(ScreenshotRequire));
						System.out.println("Entered On SerialNoInput");
						js.executeScript("arguments[0].click();", nonConfReasonLevel3.get(0));
						WebTestCase.getTest().log(LogStatus.PASS, "Clicked on NC reason code Level3:"+ reasoncode3+common.captureScreenshot(ScreenshotRequire));
					}else {
						WebTestCase.getTest().log(LogStatus.INFO, "Verified - Serial number is not required for non-shared WC"+ common.captureScreenshot(ScreenshotRequire));

					}
					
				//}
				reasonCodeVal=reasonCodeVal+"_"+reasoncode3;
			}
			
			if(nonConfReasonLevel4.size()>0) {
				String reasoncode4=null;
					reasoncode4=nonConfReasonLevel4.get(0).getText();
					System.out.println("RandomIntegerNumberlevel4 = "+reasoncode4);
					js.executeScript("arguments[0].click();", nonConfReasonLevel4.get(0));
					Thread.sleep(4000);
					if(sharedFlag.contains(";")&&(val!=null)) {
						Assert.assertTrue(errMessage.isDisplayed(),"error message is not appearing");
						WebTestCase.getTest().log(LogStatus.INFO, "Verified - error message is appearing for shared WC without Entering serial number::"+ errMessage.getText()+ common.captureScreenshot(ScreenshotRequire));
						common.setObjectValue(SerialNoInput, "SerialNoInputValue", val);
						Thread.sleep(3000);
						WebTestCase.getTest().log(LogStatus.INFO, "Serial No entered"+ common.captureScreenshot(ScreenshotRequire));
						System.out.println("Entered On SerialNoInput");
						js.executeScript("arguments[0].click();", nonConfReasonLevel4.get(0));
						WebTestCase.getTest().log(LogStatus.PASS, "Clicked on NC reason code Level4:"+ reasoncode4+common.captureScreenshot(ScreenshotRequire));
					}else {
						WebTestCase.getTest().log(LogStatus.INFO, "Verified - Serial number is not required for non-shared WC"+ common.captureScreenshot(ScreenshotRequire));

					}
					
				//}
				reasonCodeVal=reasonCodeVal+"_"+reasoncode4;
			}


			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.." +exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return reasonCodeVal;	

	}

	public String selectHelpReasonCodes(String ScreenshotRequire) throws InterruptedException{

		String reasonCodeVal=null;
		try{
			System.out.println("inside help reason code function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, helpReason, IConstants.HIGH_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 

			if(helpReasonLevel1.size()>0) {
				String reasoncode1=null;
				if(helpReasonLevel1.size()>1) {
					int reasonCodeL1=Common.generateRandomIntIntRange(0,(helpReasonLevel1.size()-1));
					System.out.println("RandomIntegerNumberlevel1 = "+reasonCodeL1);
					Common.isElementDisplayed(driver, helpReasonLevel1.get(reasonCodeL1), 30);
					reasoncode1=helpReasonLevel1.get(reasonCodeL1).getText();
					js.executeScript("arguments[0].click();", helpReasonLevel1.get(reasonCodeL1));
					Thread.sleep(15000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on help reason code:"+ reasoncode1+common.captureScreenshot(ScreenshotRequire));
				}else {
					reasoncode1=helpReasonLevel1.get(0).getText();
					js.executeScript("arguments[0].click();", helpReasonLevel1.get(0));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on help reason code:"+ helpReasonLevel1.get(0).getText()+common.captureScreenshot(ScreenshotRequire));
				}
				reasonCodeVal=reasoncode1;
			}

			if(helpReasonLevel2.size()>0) {
				String reasoncode2=null;
				if(helpReasonLevel2.size()>1) {
					int reasonCodeL2=Common.generateRandomIntIntRange(0,(helpReasonLevel2.size()-1));
					System.out.println("RandomIntegerNumberlevel2 = "+reasonCodeL2);
					Common.isElementDisplayed(driver, helpReasonLevel2.get(reasonCodeL2), 30);
					reasoncode2=helpReasonLevel2.get(reasonCodeL2).getText();
					js.executeScript("arguments[0].click();", helpReasonLevel2.get(reasonCodeL2));
					Thread.sleep(15000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on help reason code:"+ reasoncode2+common.captureScreenshot(ScreenshotRequire));
				}else {
					reasoncode2=helpReasonLevel2.get(0).getText();
					js.executeScript("arguments[0].click();", helpReasonLevel2.get(0));
					Thread.sleep(5000);
					WebTestCase.getTest().log(LogStatus.PASS, "Clicked on help reason code:"+ helpReasonLevel2.get(0).getText()+common.captureScreenshot(ScreenshotRequire));
				}
				reasonCodeVal=reasonCodeVal+"_"+reasoncode2;
			}


			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.." +exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return reasonCodeVal;	

	}



}