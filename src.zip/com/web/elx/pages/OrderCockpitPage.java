package com.web.elx.pages;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class OrderCockpitPage {



	SoftAssert softAssert = new SoftAssert();

	@FindBy(xpath = "//li[@title='ORD']")
	private WebElement ORDPageTitle;

	@FindBy(xpath = "//li[@title='ORH']")
	private WebElement ORDHistoryPageTitle;

	@FindBy(xpath ="//div[@class='apr-delmia-header-content']/span[2]")
	private WebElement loginUser;

	@FindBy(xpath =".//span[contains(text(),'History')]")
	private WebElement historyBtn;

	@FindBy(xpath ="(//button[contains(text(),'Details')])[1]")
	private WebElement historyDetailsBtn;


	//@FindBy(xpath = "//*[contains(@id, 'BC_')]//div[2]/div[1]/table/thead/tr[2]/td[1]/div[1]/input")
	@FindBy(xpath = "//input[contains(@data-field,'productionordernolist')]")
	private WebElement orderTextbox;

	@FindBy(xpath ="//td[contains(@data-field,'productionordernolist')]//span[@class='display']")
	private WebElement ordId;

	@FindBy(xpath ="//td[@data-field='schedulquantitylist']//span[@class='display']")
	private WebElement schedulquantitylist;

	@FindBy(xpath ="//td[@data-field='goodquantitylist']//span[@class='display']")
	private WebElement goodquantitylist;

	@FindBy(xpath = ".//td[@data-field='badquantitylist']//span[@class='display']")
	private  WebElement badquantitylist;


	@FindBy(xpath ="//td[@data-field='remainingquantitylist']//span[@class='display']")
	private WebElement remainingquantitylist;

	@FindBy(xpath ="//td[@data-field='tacttimelist']//span[@class='display']")
	private WebElement tacttimelist;


	@FindBy(xpath = "//input[@data-field='productnumberlist']")
	private WebElement productTextbox;

	@FindBy(xpath ="//td[@data-field='productnumberlist']//span[@class='display']")
	private WebElement prodId;

	@FindBy(xpath = ".//td[contains(@class, 'value')][1]//span")
	private  WebElement orderList	;

	@FindBy(xpath = ".//input[@data-field='machinestatuslist']")
	private  WebElement machineStatus	;

	@FindBy(xpath = ".//td[@data-field='machinestatuslist']//span[@class='display']")
	private  WebElement machinestatuslist	;

	@FindBy(xpath = ".//button[contains(text(),'Details')]")
	private  WebElement detailsButton	;

	@FindBy(xpath = ".//select[@data-field='productionlinelist']")
	private  WebElement selectProductLine	;
	
	@FindBy(xpath = ".//div[@class='fix sort asc']/span")
	private  WebElement expStartDateAsc	;
	
	@FindBy(xpath = "(//input[@data-field='actualcompletiondatelist'])[1]")
	private  WebElement actualcompletiondatelistHistoryScreen;

	@FindBy(xpath = "(//td[@data-field='productionordernolistvis'])[4]//span")
	private  WebElement orderIDHistoryScreen;

	@FindBy(xpath = ".//tr[@class='HeadF']/td[@data-field='productionordernolistvis']//input")
	private  WebElement productionordernolistvisTextBox;
	
	@FindBy(xpath = "(//td[@data-field='productionorderstatuslist']//span)[2]")
	private  WebElement productionorderstatuslist;	

	@FindBy(xpath = ".//input[@data-field='machinelist']")
	private  WebElement selectmachinelist	;

	@FindBy(xpath = "//input[contains(@data-field, 'productionordernolist')]")
	private WebElement orderSearchTextbox;

	@FindBy(xpath = ".//select[@data-field='productionorderstatuslist']")
	private WebElement statusDropDown;

	@FindBy(xpath = "//*[contains(@data-field,'expectedstartdatelist') and contains(@placeholder,'From')]")
	private  WebElement expStartDate	;

	@FindBy(xpath = ".//td[contains(@class, 'value')][1]//span")
	private List <WebElement> webListOrder;

	@FindBy(xpath = ".//td[contains(@class, 'value')][3]//span")
	private  WebElement statusList	;

	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	@FindBy(xpath = ".//td[@data-field='colorfilter']//a")
	private WebElement colorfilterIcon;

	@FindBy(xpath = ".//td[@data-field='colorfilter']//span[@class='display']")
	private WebElement colorcode;

	@FindBy(xpath = ".//div[@class='Total']")
	private WebElement totalOrderRecord;

	@FindBy(xpath = ".//button[@data-key='NextPage']")
	private WebElement NextPage;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[2]")
	private WebElement OrderTypeRecord;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[4]")
	private WebElement ProductIdRecord;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[6]")
	private WebElement scheduledQuanList;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[7]")
	private WebElement goodQuanList;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[9]")
	private WebElement badQuanList;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[12]")
	private WebElement scheStartDate;


	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[13]")
	private WebElement schEndDate;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[14]")
	private WebElement actualStartDate;

	@FindBy(xpath = "//tr[@class='HeadT']")
	private WebElement ELX17iconRow;

	@FindBy(xpath = "//tr[@class='HeadT']/td")
	private List <WebElement> ELX17FieldList;

	@FindBy(xpath = "(//div[@class='DropDownWrapper']/select)[2]")
	private WebElement statusField;

	@FindBy(xpath = "(//div[@class='DropDownWrapper']/select)[1]")
	private WebElement statusField1;

	@FindBy(xpath = "//div[@class='Toolbox Top']/div/button[not(contains(@data-key, 'Export'))]")
	private List <WebElement> ordHeaderFields;

	@FindBy(xpath = "//div[@class='apr-cttabscrolled-tabscrolledcontainer TabList']/button")
	private List <WebElement> operationHeaderFields;

	@FindBy(xpath = "//div[@class='FormContainer']/h2/following-sibling::div/table/descendant::tr/descendant::td[starts-with(@class,'Label fl_')]")
	private List <WebElement> generalTabFields;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[3]")
	private WebElement Status;

	@FindBy(xpath = ".//td[@data-field='statuslist']//a")
	private WebElement statuslistIcon;

	@FindBy(xpath = ".//td[@data-field='productionlinenolist']//a")
	private WebElement productionlinenolist;

	@FindBy(xpath = ".//div[@class='Container vpBody']//tr[2]/td")
	private List <WebElement> ncFirstRowdetails;

	@FindBy(xpath = ".//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//button[contains(@title,'deselect all') and not (contains(@style,'cursor: auto'))]")
	private WebElement deselectAllSelectedBtn;

	@FindBy(xpath = ".//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//button[contains(@title,'Remove selected') and not (contains(@style,'cursor: auto'))]")
	private WebElement removeSelectedBtn;

	@FindBy(xpath = "(//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//div[contains(@class,'vpBody')])[1]//tr")
	private List <WebElement> colorSelectPopUp;


	@FindBy(xpath = "(//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//div[contains(@class,'vpBody')])[2]")
	private WebElement leftSideDivPanel;

	@FindBy(xpath = ".//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//span[contains(text(),'OK')]")
	private WebElement okBtn;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[12]")
	private WebElement expStart;


	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[13]")
	private WebElement expEnd;

	@FindBy(xpath = ".//td[@data-field='expectedstartdatelist']//span[@class='display']")
	private WebElement expectedstartdatelist;

	@FindBy(xpath = ".//td[@data-field='expectedenddatelist']//span[@class='display']")
	private WebElement expectedenddatelist;

	@FindBy(xpath = ".//td[@data-field='actualstartdatelist']//span[@class='display']")
	private WebElement actualstartdatelist;

	//order cockpit history
	
	@FindBy(xpath = ".//td[@data-field='goodquantitylist']//input[@placeholder='From']")
	private WebElement goodquantitylistFrom;	
	
	@FindBy(xpath = ".//td[@data-field='goodquantitylist']//input[@placeholder='To']")
	private WebElement goodquantitylistTo;
	
	@FindBy(xpath = ".//td[@data-field='schedulquantitylist']//input[@placeholder='From']")
	private WebElement schedulquantitylistFrom;	
	
	@FindBy(xpath = ".//td[@data-field='schedulquantitylist']//input[@placeholder='To']")
	private WebElement schedulquantitylistTo;
	
	private WebDriver driver;
	private Common common;

	public OrderCockpitPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
		new SoftAssert();

	}
	/**
	 * Method To validate Order Cockpit Page Title
	 * @author Arpana
	 * @throws InterruptedException
	 * @param title
	 */

	@SuppressWarnings("static-access")
	public void validateOrderCockpitPageTitle(String title,String ScreenshotRequire) throws InterruptedException{
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(15000);
			Common.isElementDisplayed(driver, ORDPageTitle, IConstants.HIGH_WAIT_TIME);
			Assert.assertEquals(ORDPageTitle.getText(), title,  "Order Cockpit page not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD Screen is displayed successfuly"+common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To validate Order Cockpit Page Title
	 * @author Arpana
	 * @throws InterruptedException
	 * @param title
	 */

	@SuppressWarnings("static-access")
	public void validateOrderCockpitHistoryPageTitle(String title, String ScreenshotRequire) throws InterruptedException{
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(30000);
			Common.isElementDisplayed(driver, ORDHistoryPageTitle, IConstants.HIGH_WAIT_TIME);
			Assert.assertEquals(ORDHistoryPageTitle.getText(), title,  "Order Cockpit History page not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order Cockpit History page is displayed successfuly"+common.captureScreenshot(ScreenshotRequire) );
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To validate Order Cockpit Page Title
	 * @author Arpana
	 * @throws InterruptedException
	 * @param title
	 */

	@SuppressWarnings("static-access")
	public void clickOnHistoryIcon(String ScreenshotRequire) throws InterruptedException{
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Common.isElementDisplayed(driver, historyBtn, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(historyBtn, "historyBtn");
			Thread.sleep(15000);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Clicked on History tab successfuly"+common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	//Validate Login User
	public void validateUser(String user, String ScreenshotRequire) throws InterruptedException{
		try {
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			Common.isElementDisplayed(driver, loginUser, IConstants.SYS_WAIT_TIME);
			Assert.assertEquals(loginUser.getText(), user, "Not a valid user");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Login user displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	//Order# Verification
	@SuppressWarnings("static-access")
	public void orderSearch(String orderId, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, orderTextbox, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(orderTextbox.isDisplayed(), "Order# Textbox not displayed");
		common.setObjectValue(orderTextbox, "orderTextbox", orderId);
		orderTextbox.sendKeys(Keys.ENTER);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, ordId, IConstants.HIGH_WAIT_TIME);
		Assert.assertEquals(ordId.getText(), orderId, "Order# is not in the list");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
		//orderTextbox.clear();
		driver.switchTo().defaultContent();

	}

	//Product# Verification
	public void productSearch(String productId, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath("iframepage"), IConstants.MEDIUM_WAIT_TIME);
		orderTextbox.clear();
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, productTextbox, IConstants.SYS_WAIT_TIME);
		Assert.assertTrue(productTextbox.isDisplayed(), "Product# Textbox not displayed");
		common.setObjectValue(productTextbox,"productId",productId);
		productTextbox.sendKeys(Keys.ENTER);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Assert.assertEquals(prodId.getText(), productId, "Product# is not in the list");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Product number displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
		driver.switchTo().defaultContent();

	}

	@SuppressWarnings("static-access")
	public String orderListVerification(String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed as expected "+ common.captureScreenshot(ScreenshotRequire));
		System.out.println("value " +orderList.getText());
		String val=orderList.getText();
		char sorder=orderList.getText().charAt(0);
		if (sorder != 'S') {

			Assert.assertTrue(orderList.isDisplayed(), "s order not displayed");
		}

		//orderList.getAttribute("img");
		/*List<WebElement> lstElem = driver.findElements(By.xpath(".//td[contains(@class, 'value')][1]//span"));		 
		for (int i = 0; i < lstElem.size(); i++) {
			if(lstElem.get(i).getAttribute("img")=="null"){
				//System.out.println("Text of Span " + (i + 1) + " => "+ lstElem.get(i).getText()+"--"+lstElem.get(i).getTagName());
				Actions action =new Actions(driver);
				orderList.click();
				action.doubleClick(orderList).perform();
		}}*/

		Actions action =new Actions(driver);
		common.clickOnObject(orderList, "orderList");
		action.doubleClick(orderList).perform();
		System.out.println("double clicked order cockpit");
		return val;
	}


	//Order# Verification
	@SuppressWarnings("static-access")
	public String verifyOrderOnOrderCockpitPage(String oId, String ScreenshotRequire) throws InterruptedException{

		String val=null;
		int flag=0;
		System.out.println("inside searchOrderOnOrderCockpitPage function");
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
		Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
		Thread.sleep(10000);
		common.setObjectValue(orderTextbox,"oId",oId);
		orderTextbox.sendKeys(Keys.ENTER);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
		Thread.sleep(10000);
		System.out.println("sent value on orderTextbox "+oId);

		Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));
		String tot= totalOrderRecord.getText();
		String [] splitsvalues=common.splitValues(tot,"\\:");
		String TotalORDRecords=splitsvalues[1].trim();

		//List<WebElement> webList =driver.findElements(By.xpath(".//td[contains(@class, 'value')][1]//span"));
		if(webListOrder==null){
		}
		int Totalpage=0;
		if(Integer.parseInt(TotalORDRecords)>10) {
			Totalpage=Integer.parseInt(TotalORDRecords)/10;
		}else {
			Totalpage=1;
		}
		for(int i=0;i<Totalpage;i++) {
			for(WebElement ele :webListOrder){
				if(ele.isDisplayed()==true){
					System.out.println("selected order:"+ele.getText());
					if(ele.getAttribute("innerHTML").contains("img"))
					{
						System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
					}
					else {
						flag=1;
						val=ele.getAttribute("innerHTML");
						common.clickOnObject(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']")),"webListOrder");
						String orderStatus=statusList.getText();
						val=val+"-"+orderStatus;
						Actions action =new Actions(driver);
						action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();
						break;
					}
				}
			}
			if(flag==1) {
				break;
			}else if(NextPage.isEnabled()) {
				System.out.println("val of I:: "+ i);
				common.clickOnObject(NextPage, "NextPage");
				Thread.sleep(3000);
			}
		}

		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));
		System.out.println("clicked on order"+ val);
		driver.switchTo().defaultContent();
		return val;			
	}
	/**
	 * Method To search Order On Order Cockpit Page
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings("static-access")
	public String searchOrderOnOrderCockpitPagewithLine(String productionLine, String ScreenshotRequire) throws InterruptedException{
		int flag=0;
		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPagewithLine function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(2000);

			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",selectProductLine);
			Thread.sleep(5000);

			Select select1 = new Select(selectProductLine);
			select1.selectByVisibleText(productionLine);
			Thread.sleep(5000);
			System.out.println("selectProductLine:"+productionLine);

			Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);

			Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));
			if(webListOrder==null){
			}
			String tot= totalOrderRecord.getText();
			String [] splitsvalues=common.splitValues(tot,"\\:");
			String TotalORDRecords=splitsvalues[1].trim();
			int Totalpage=0;
			if(Integer.parseInt(TotalORDRecords)>10) {
				Totalpage=Integer.parseInt(TotalORDRecords)/10;
			}else {
				Totalpage=1;
			}
			for(int i=0;i<Totalpage;i++) {
				for(WebElement ele :webListOrder){
					if(ele.isDisplayed()==true){
						if(ele.getAttribute("innerHTML").contains("img"))
						{
							System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
						}
						else {
							flag=1;
							val=ele.getAttribute("innerHTML");
							val=val+"_"+OrderTypeRecord.getText()+"_"+ProductIdRecord.getText()+"_"+scheduledQuanList.getText()+"_"+goodQuanList.getText()+"_"+badQuanList.getText()+"_"+scheStartDate.getText()+"_"+schEndDate.getText()+"_"+actualStartDate.getText();
							driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']")).click();
							Actions action =new Actions(driver);
							action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();
							break;
						}

					}
				}
				if(flag==1) {
					break;
				}else if(NextPage.isEnabled()) {
					System.out.println("val of I:: "+ i);
					common.clickOnObject(NextPage, "NextPage");
					Thread.sleep(3000);
				}
			}
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));
			System.out.println("clicked on order"+ val);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	/**
	 * Method To search Order On Order Cockpit Page
	 * @author Arpana Kumari
	 * @throws InterruptedException 
	 */

	@SuppressWarnings("static-access")
	public String searchOrderOnOrderCockpitPage(String oStatus,String oId, String line,String ScreenshotRequire) throws InterruptedException{
		//oStatus="New";
		String val=null;
		int flag=0;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPage function::oStatus::"+oStatus+"  oId::"+oId +" line::"+line);

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			//Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(10000);
			if(oId.length()>0) {
				common.setObjectValue(orderSearchTextbox, "orderSearchTextbox", oId);
				orderSearchTextbox.sendKeys(Keys.RETURN);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Thread.sleep(5000);
				System.out.println("sent value on orderTextbox "+oId);
				if(oId.length()==1) {
					Select select = new Select(statusDropDown);
					select.selectByVisibleText(oStatus);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
					Thread.sleep(5000);

					System.out.println("sent value on statusDropDown "+oStatus);
					if(line.length()>0) {
						JavascriptExecutor js = (JavascriptExecutor)driver; 	
						js.executeScript("arguments[0].scrollIntoView();",selectProductLine);
						Thread.sleep(5000);
						Select select1 = new Select(selectProductLine);
						select1.selectByVisibleText(line);
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
						Thread.sleep(5000);
						System.out.println("selectProductLine:"+line);
					}
				}
			}else {
				Select select = new Select(statusDropDown);
				select.selectByVisibleText(oStatus);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Thread.sleep(5000);
				if(line.length()>0) {
					JavascriptExecutor js = (JavascriptExecutor)driver; 	
					js.executeScript("arguments[0].scrollIntoView();",selectProductLine);
					Thread.sleep(5000);
					Select select1 = new Select(selectProductLine);
					select1.selectByVisibleText(line);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
					Thread.sleep(5000);
					System.out.println("selectProductLine:"+line);
				}
			}
			String tot= totalOrderRecord.getText();
			String [] splitsvalues=common.splitValues(tot,"\\:");
			String TotalORDRecords=splitsvalues[1].trim();

			if(Integer.parseInt(TotalORDRecords)==0){
				val=null;
				System.out.println("order list not displaying, count: "+ TotalORDRecords);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List is not displayed for given search, total count is: "+ TotalORDRecords+ common.captureScreenshot(ScreenshotRequire));
			}else {
				/*Common.isElementDisplayed(driver, expStartDateAsc, IConstants.HIGH_WAIT_TIME);
				common.clickOnObject(expStartDateAsc, "expStartDateAsc");
				Thread.sleep(3000);*/
				Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
				Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));
				System.out.println("order list displaying, count: "+ TotalORDRecords);
				int Totalpage=0;
				if(Integer.parseInt(TotalORDRecords)>10) {
					Totalpage=Integer.parseInt(TotalORDRecords)/10;
				}else {
					Totalpage=1;
				}
				for(int i=0;i<Totalpage;i++) {
					for(WebElement ele :webListOrder){
						if(ele.isDisplayed()==true){
							if(ele.getAttribute("innerHTML").contains("img"))
							{
								System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
							}else {
								flag=1;
								val=ele.getAttribute("innerHTML").trim();
								val=val+"_"+OrderTypeRecord.getText().trim()+"_"+ProductIdRecord.getText().trim()+"_"+scheduledQuanList.getText().trim()+"_"+goodQuanList.getText().trim()+"_"+badQuanList.getText().trim()+"_"+scheStartDate.getText().trim()+"_"+schEndDate.getText().trim()+"_"+actualStartDate.getText().trim();
								driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']")).click();
								Actions action =new Actions(driver);
								action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();
								System.out.println("clicked on order"+ val);
								break;
							}

						}
					}
					if(flag==1) {
						break;
					}else if(NextPage.isEnabled()) {
						System.out.println("val of I:: "+ i);
						common.clickOnObject(NextPage, "NextPage");
						Thread.sleep(3000);
					}
				}
				if(flag==1) {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));

				}else {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - valid orders are not available for operation"+ common.captureScreenshot(ScreenshotRequire));
				}
				//Assert.assertEquals(flag, 1,  "Valid order list of status: "+oStatus+" : is not displaying");
				//val=orderList.getText();
				//detailsButton.click();

			}}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}


	/**
	 * Method To search Order On Order Cockpit history Page
	 * @author Arpana Kumari
	 * @throws InterruptedException 
	 */

	@SuppressWarnings("static-access")
	public String searchOrderOnOrderCockpitHistoryPage(String oStatus, String ScreenshotRequire) throws InterruptedException{
		String orderID=null;
		int flag=0;
		try{
			System.out.println("inside searchOrderOnOrderCockpitHistoryPage function::oStatus::"+oStatus);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			String tot= totalOrderRecord.getText();
			String [] splitsvalues=common.splitValues(tot,"\\:");
			String TotalORDRecords=splitsvalues[1].trim();

			if(Integer.parseInt(TotalORDRecords)>0){
				Select select = new Select(statusDropDown);
				select.selectByVisibleText(oStatus);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Thread.sleep(5000);
				System.out.println("selected value from statusDropDown "+oStatus);
				/*JavascriptExecutor js = (JavascriptExecutor)driver; 	
				js.executeScript("arguments[0].scrollIntoView();",actualcompletiondatelistHistoryScreen);
				Thread.sleep(5000);
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				Date date = new Date();
				String time = sdf.format(date);
				System.out.println(time);

				String previousDateStringval=common.previousDateString(time)+" "+"12:00:00 AM";

				actualcompletiondatelistHistoryScreen.click();
				common.setObjectValue(actualcompletiondatelistHistoryScreen, "actualcompletiondatelistHistoryScreen", previousDateStringval);
				actualcompletiondatelistHistoryScreen.sendKeys(Keys.ENTER);
				Thread.sleep(8000);*/
				Common.isElementDisplayed(driver, schedulquantitylistFrom, IConstants.MEDIUM_WAIT_TIME);
				common.clickOnObject(schedulquantitylistFrom, "schedulquantitylistFrom");
				common.setObjectValue(schedulquantitylistFrom, "schedulquantitylistFrom", "1");
				schedulquantitylistFrom.sendKeys(Keys.ENTER);
				
				common.clickOnObject(schedulquantitylistTo, "schedulquantitylistTo");
				common.setObjectValue(schedulquantitylistTo, "schedulquantitylistTo", "10");
				schedulquantitylistTo.sendKeys(Keys.ENTER);
				Thread.sleep(1000);
				
				Common.isElementDisplayed(driver, goodquantitylistFrom, IConstants.MEDIUM_WAIT_TIME);
				common.clickOnObject(goodquantitylistFrom, "goodquantitylistFrom");
				common.setObjectValue(goodquantitylistFrom, "goodquantitylistFrom", "1");
				goodquantitylistFrom.sendKeys(Keys.ENTER);
				
				common.clickOnObject(goodquantitylistTo, "goodquantitylistTo");
				common.setObjectValue(goodquantitylistTo, "goodquantitylistTo", "10");
				goodquantitylistTo.sendKeys(Keys.ENTER);
				Thread.sleep(1000);
				
				tot= totalOrderRecord.getText();
				splitsvalues=common.splitValues(tot,"\\:");
				TotalORDRecords=splitsvalues[1].trim();
				if(Integer.parseInt(TotalORDRecords)>0){
					flag=1;
					orderID=orderIDHistoryScreen.getText();
					common.clickOnObject(historyDetailsBtn, "historyDetailsBtn");
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
					Thread.sleep(5000);
				}else {
					flag=0;
					orderID=null;
				}

			}else {
				flag=0;
				orderID=null;
			}

		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return orderID;			
	}
	/**
	 * Method To search ORDscreensearchheadervalidation
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateallORDScreenSearchHeaderValidation(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateallORDscreensearchheadervalidation function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.SYS_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, ELX17iconRow, IConstants.SYS_WAIT_TIME);

			System.out.println(ELX17FieldList.size());
			for(int i=8;i<ELX17FieldList.size();i++) {
				if(!(hmAction.get(i+1).contains("--"))) {
					if((ELX17FieldList.get(i).getAttribute("innerText").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
						WebTestCase.getTest().log(LogStatus.PASS, "ORD Page Table Headers "+"--"+ELX17FieldList.get(i).getAttribute("innerText").toLowerCase()+"--  Data in Global Sheet :-" +hmAction.get(i+1).toLowerCase());
					}
					else{
						WebTestCase.getTest().log(LogStatus.FAIL, "ORD Page Table Headers Expected "+" -- "+ELX17FieldList.get(i).getAttribute("innerText")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
					}
				}
			}
			WebTestCase.getTest().log(LogStatus.INFO, "ORD Page Table Headers validated successfully on ORD screen"+common.captureScreenshot(ScreenshotRequire));
			//+(i+1)
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	/**
	 * Method To Status Fields 
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateStatusFields(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateStatusFields function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			List <WebElement> list	=	common.getallvaluesfromSelectbox(statusField1, "SelectBox");
			System.out.println(list.size());
			for(int i=0;i<list.size();i++) {
				if((list.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("ORD Screen StatusField Contains :"+list.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.PASS, "ORD Screen StatusField Contains "+"--"+list.get(i).getAttribute("innerHTML").toLowerCase() +" -- Data in Global Sheet :-" +hmAction.get(i+1).toLowerCase());
				}

				else{
					WebTestCase.getTest().log(LogStatus.FAIL, "<b style=color:red;>ORD Screen StatusField Contains Expected "+" -- "+list.get(i).getAttribute("innerHTML")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase()+"</b>");	
				}
			}

			WebTestCase.getTest().log(LogStatus.INFO, "ORD Screen StatusField Contains validated successfully "+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	/**
	 * Method To Validate Product Line Field
	 * @author Chinmay
	 * @throws InterruptedException 
	 */

	@SuppressWarnings("static-access")
	public void validateProductLineFieldContains(HashMap<Integer,String> hmAction,String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateProductLineFieldContains function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			List <WebElement> list	=	common.getallvaluesfromSelectbox(statusField, "SelectBox");
			System.out.println(list.size());
			for(int i=0;i<list.size();i++) {
				if(!(list.get(i).getAttribute("value").contains("null"))) {
					if((list.get(i).getAttribute("innerText").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
						System.out.println("ORD Screen Product Line Field Contains :"+list.get(i).getAttribute("innerText"));
						WebTestCase.getTest().log(LogStatus.PASS, "ORD Screen Product Line Field Contains "+"--"+list.get(i).getAttribute("innerText").toLowerCase()+" -- Data in Global Sheet :-" +hmAction.get(i+1).toLowerCase());
					}
					else{
						WebTestCase.getTest().log(LogStatus.FAIL, "ORD Screen Product Line Field Contains "+" -- "+list.get(i).getAttribute("innerText")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
					}
				}
				WebTestCase.getTest().log(LogStatus.INFO, "ORD Screen Product Line Field Contains "+common.captureScreenshot(ScreenshotRequire));
			}}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	/**
	 * Method To Validate Ord Screen Header Buttons
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateORDScreenHeaderButtons(HashMap<Integer,String> hmAction,String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateOrdSceenHeaderButtons function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			//Common.isElementDisplayed(driver, ELX17iconRow, 100);

			System.out.println(ordHeaderFields.size());
			for(int i=0;i<ordHeaderFields.size();i++) {
				System.out.println(ordHeaderFields.get(i).getText());
				if((ordHeaderFields.get(i).getAttribute("innerText").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("ORD screen  Headers:"+ordHeaderFields.get(i).getAttribute("innerText"));
					WebTestCase.getTest().log(LogStatus.PASS, "ORD screen  Headers"+"--"+ordHeaderFields.get(i).getAttribute("innerText").toLowerCase()+" -- Data in Global Sheet:- " +hmAction.get(i+1).toLowerCase());
				}
				else{
					WebTestCase.getTest().log(LogStatus.FAIL, "ORD screen  Headers Expected "+" -- "+ordHeaderFields.get(i).getAttribute("innerText")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
				}
			}
			WebTestCase.getTest().log(LogStatus.INFO, "ORD Sceen Header Buttons validated successfully "+common.captureScreenshot(ScreenshotRequire));
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	/**
	 * Method To Validate Operation Screen Header Buttons
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	/*@SuppressWarnings("static-access")
	public boolean validateOperationSceenHeaderButtons(HashMap<Integer,String> hmAction) throws InterruptedException{
		System.out.println("inside validateOperationSceenHeaderButtons function");
		boolean result=false;
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			//Common.isElementDisplayed(driver, ELX17iconRow, 100);

			System.out.println(operationHeaderFields.size());
				for(int i=0;i<operationHeaderFields.size();i++) {
				System.out.println(operationHeaderFields.get(i).getText());
						if((operationHeaderFields.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
							System.out.println("Operation screen  Headers:"+operationHeaderFields.get(i).getAttribute("innerHTML"));
							WebTestCase.getTest().log(LogStatus.INFO, "Operation screen  Headers"+"--"+operationHeaderFields.get(i).getAttribute("innerHTML")+" -- Data in Global Sheet :-" +hmAction.get(i+1).toLowerCase());
						result =true;
						}
						else{

							WebTestCase.getTest().log(LogStatus.FAIL, "Operation screen  Headers Expected "+" -- "+operationHeaderFields.get(i).getAttribute("innerHTML")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
							result = false;
						}
					//+(i+1)
				}

				WebTestCase.getTest().log(LogStatus.INFO, "Operation Sceen Header Buttons validated successfully "+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return result;
	}
	 */
	@SuppressWarnings("static-access")
	public HashMap<String, String>  validateOperationSceenHeaderButtons(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateOperationSceenHeaderButtons function");
		new SoftAssert();
		HashMap<String,String> hm1=new HashMap<String,String>();
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			System.out.println("List size: "+operationHeaderFields.size());
			for(int i=0;i<operationHeaderFields.size();i++) {
				System.out.println("value: "+operationHeaderFields.get(i).getText());
				if((operationHeaderFields.get(i).getAttribute("innerText").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					WebTestCase.getTest().log(LogStatus.PASS, "Operation screen  Headers"+"--"+operationHeaderFields.get(i).getAttribute("innerText")+" -- Data in Global Sheet :-" +hmAction.get(i+1).toLowerCase());
					String x="Operation screen  Headers"+"--"+operationHeaderFields.get(i).getAttribute("innerText")+" -- Data in Global Sheet :-" +hmAction.get(i+1).toLowerCase();
					hm1.put("result"+i,x);
				}
				else{
					WebTestCase.getTest().log(LogStatus.FAIL, "Operation screen  Headers Expected "+" -- "+operationHeaderFields.get(i).getAttribute("innerText")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());      
					String x="Operation screen  Headers Expected "+" -- "+operationHeaderFields.get(i).getAttribute("innerText")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase();
					hm1.put("result"+i,x);
				}
				//+(i+1)
			}

			WebTestCase.getTest().log(LogStatus.INFO, "Operation Sceen Header Buttons validated successfully "+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return hm1;
	}

	/**
	 * Method To Validate GeneralTab Contains
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	/*@SuppressWarnings("static-access")
	public boolean validateGeneralTabContains(HashMap<Integer,String> hmAction) throws InterruptedException{
		System.out.println("inside validateGeneralTabContains function");
		boolean result=false;
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			//Common.isElementDisplayed(driver, ELX17iconRow, 100);

			System.out.println(generalTabFields.size());
				for(int i=0;i<generalTabFields.size();i++) {
				System.out.println(generalTabFields.get(i).getText());
						if((generalTabFields.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
							System.out.println("GeneralTabField Values:"+generalTabFields.get(i).getAttribute("innerHTML"));
							WebTestCase.getTest().log(LogStatus.INFO, "GeneralTabField Values"+"--"+generalTabFields.get(i).getAttribute("innerHTML")+"  --Data in Global Sheet:- " +hmAction.get(i+1).toLowerCase());
							result =true;
						}
						else{
							WebTestCase.getTest().log(LogStatus.FAIL, "GeneralTabField Values Expected "+" -- "+generalTabFields.get(i).getAttribute("innerHTML")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
							result =false;
						}
					//+(i+1)
				}

				WebTestCase.getTest().log(LogStatus.INFO, "GeneralTabField Values validated successfully "+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return result;
	}*/

	@SuppressWarnings("static-access")
	public HashMap<String, String>  validateGeneralTabContains(HashMap<Integer,String> hmAction,String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateGeneralTabContains function");
		HashMap<String,String> hm1=new HashMap<String,String>();
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			//Common.isElementDisplayed(driver, ELX17iconRow, 100);

			System.out.println(generalTabFields.size());
			for(int i=0;i<generalTabFields.size();i++) {
				System.out.println(generalTabFields.get(i).getText());
				if((generalTabFields.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("GeneralTabField Values:"+generalTabFields.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "GeneralTabField Values"+"--"+generalTabFields.get(i).getAttribute("innerHTML")+"  --Data in Global Sheet:- " +hmAction.get(i+1).toLowerCase());
					String x="Operation screen  Headers"+"--"+generalTabFields.get(i).getAttribute("innerHTML")+" -- Data in Global Sheet :-" +hmAction.get(i+1).toLowerCase();
					hm1.put("result"+i,x);
				}
				else{

					WebTestCase.getTest().log(LogStatus.FAIL, "GeneralTabField Values Expected "+" -- "+generalTabFields.get(i).getAttribute("innerHTML")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	      
					String x="Operation screen  Headers Expected "+" -- "+generalTabFields.get(i).getAttribute("innerHTML")+" But Data in Global Sheet " +hmAction.get(i+1).toLowerCase();
					hm1.put("result"+i,x);
				}
				//+(i+1)
			}

			WebTestCase.getTest().log(LogStatus.INFO, "GeneralTabField Values validated successfully "+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return hm1;
	}



	//Order# Verification
	@SuppressWarnings("static-access")
	public String calculateChangeOverTime(String orderName,String spanProductNo,String spanToDoQty,String spanDoneQty,String spanRemainingTime,String area, String wc) throws InterruptedException, ParseException{
		String val=null;
		try {
			System.out.println("inside calculateChangeOverTime function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );

			JavascriptExecutor js = (JavascriptExecutor)driver; 	

			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			common.setObjectValue(orderSearchTextbox, "orderSearchTextbox", orderName);
			orderSearchTextbox.sendKeys(Keys.ENTER);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);

			Assert.assertEquals(ordId.getText(),orderName , "Order id is displaying correctly");
			WebTestCase.getTest().log(LogStatus.INFO, "<b>Order Id value in operator screen is : "+orderName +"---"+"Order Id value in ORD screen is:"+ ordId.getText()+"</b>");


			Assert.assertEquals(prodId.getText(), spanProductNo, "Product id is not displaying correctly");
			WebTestCase.getTest().log(LogStatus.INFO, "<b>Product Id value in operator screen is : "+spanProductNo +"---"+"Product Id value in ORD screen is:"+ prodId.getText()+"</b>");

			//Assert.assertEquals(schedulquantitylist.getText(),spanPlannedQty , "spanPlannedQty is displaying correctly");
			//WebTestCase.getTest().log(LogStatus.INFO, "<b>Planned Qty value in operator screen is : "+spanPlannedQty +"---"+"Planned Qty value in ORD screen is:"+ schedulquantitylist.getText()+"</b>");


			js.executeScript("arguments[0].scrollIntoView();",tacttimelist);
			Thread.sleep(5000);

			//calculate change over time
			int tacttime=Integer.parseInt(tacttimelist.getText());
			System.out.println("tacttime is: "+tacttime);
			System.out.println("planned q:"+ spanToDoQty);
			int spanPlannedQtyVal= Integer.parseInt(spanToDoQty);
			int ChangeOverTime =(tacttime*spanPlannedQtyVal);
			System.out.println("ChangeOverTime in sec: "+ChangeOverTime);	

			String str=Integer.toString(ChangeOverTime);

			SimpleDateFormat finalChangeOverTime = new SimpleDateFormat("ss");
			Date dt = finalChangeOverTime.parse(str);
			finalChangeOverTime = new SimpleDateFormat("HH:mm");
			System.out.println("ChangeOverTime final:"+finalChangeOverTime.format(dt));
			String strPattern = "^0"; 
			val=finalChangeOverTime.format(dt).replaceAll(strPattern, "");
			System.out.println( "cot: " + val);
			WebTestCase.getTest().log(LogStatus.INFO, "<b>Change Over Time is displaying on OPR screen for Area and workcenter"+area+"--"+wc+"--"+ spanRemainingTime+"--"+"Change Over Time is displaying after calculation:"+ val+"</b>");
			Assert.assertTrue(val.contains(spanRemainingTime) , "Change Over Time is not displaying correctly on OPR screen:"+val);


			js.executeScript("arguments[0].scrollIntoView();",orderTextbox);
			Thread.sleep(5000);
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

		driver.switchTo().defaultContent();
		return val;			
	}
	/**
	 * Method To search Order On Order Cockpit Page
	 * @author Chinmay
	 * @throws InterruptedException 
	 */

	@SuppressWarnings("static-access")
	public String searchOrderOnOrderCockpitPagewthStatus(String oStatus,String oId, String line, String ScreenshotRequire) throws InterruptedException{

		String val=null;
		int flag=0;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPage function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(10000);
			orderSearchTextbox.clear();
			common.setObjectValue(orderSearchTextbox, "orderSearchTextbox", oId);
			orderSearchTextbox.sendKeys(Keys.RETURN);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(10000);
			System.out.println("sent value on orderTextbox : "+oId);
			if((oId!=null)&&(oId!="")) {
				if(oId.length()==1) {
					Select select = new Select(statusDropDown);
					select.selectByVisibleText(oStatus);
					Thread.sleep(10000);
					System.out.println("sent value on statusDropDown "+oStatus);

					JavascriptExecutor js = (JavascriptExecutor)driver; 	
					js.executeScript("arguments[0].scrollIntoView();",selectProductLine);
					Thread.sleep(10000);

					Select select1 = new Select(selectProductLine);
					select1.selectByVisibleText(line);
					Thread.sleep(10000);
					System.out.println("selectProductLine:"+line);
				}
			}else {
				Select select = new Select(statusDropDown);
				select.selectByVisibleText(oStatus);
				Thread.sleep(10000);
				System.out.println("sent value on statusDropDown "+oStatus);
			}
			String tot= totalOrderRecord.getText();
			String [] splitsvalues=common.splitValues(tot,"\\:");
			String TotalORDRecords=splitsvalues[1].trim();

			if(Integer.parseInt(TotalORDRecords)==0){
				val=null;
				System.out.println("order list not displaying, count: "+ TotalORDRecords);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List is not displayed for given search, total count is: "+ TotalORDRecords+ common.captureScreenshot(ScreenshotRequire));
			}else {
				Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
				System.out.println("order list displaying, count: "+ TotalORDRecords);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));

				int Totalpage=0;
				if(Integer.parseInt(TotalORDRecords)>10) {
					Totalpage=Integer.parseInt(TotalORDRecords)/10;
				}else {
					Totalpage=1;
				}
				for(int i=0;i<Totalpage;i++) {
					for(WebElement ele :webListOrder){
						if(ele.isDisplayed()==true){
							if(ele.getAttribute("innerHTML").contains("img"))
							{
								System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
							}
							else {
								flag=1;
								val=ele.getAttribute("innerHTML");    
								val=val+"_"+OrderTypeRecord.getText()+"_"+ProductIdRecord.getText()+"_"+scheduledQuanList.getText()+"_"+goodQuanList.getText()+"_"+badQuanList.getText()+"_"+scheStartDate.getText()+"_"+schEndDate.getText()+"_"+actualStartDate.getText()+"_"+Status.getText();
								driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']")).click();
								Actions action =new Actions(driver);
								action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();
								break;
							}

						}
					}
					if(flag==1) {
						break;
					}else if(NextPage.isEnabled()) {
						System.out.println("val of I:: "+ i);
						common.clickOnObject(NextPage, "NextPage");
						Thread.sleep(3000);
					}
				}
				if(flag==1) {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));

				}else {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - valid orders are not available for operation"+ common.captureScreenshot(ScreenshotRequire));
				}

				//val=orderList.getText();
				//detailsButton.click();
				System.out.println("clicked on order"+ val);
			}
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	/**
	 * Method To search Order On Order Cockpit Page
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings({ "static-access" })
	public String searchOrderOnOrderCockpitPageWithLineAndMachineDetails(Hashtable<String, String> data,HashMap<String,String> orderDetails,String areaName,String machineName,String ScreenshotRequire) throws InterruptedException{

		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPageWithLineAndMachineDetails function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(4000);

			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",selectmachinelist);
			Thread.sleep(6000);

			/*Select select = new Select(selectProductLine);
				select.selectByVisibleText(areaName);
				Thread.sleep(6000);
				System.out.println("selectProductLine:"+areaName);*/


			common.setObjectValue(selectmachinelist, "selectmachinelist", machineName);
			selectmachinelist.sendKeys(Keys.ENTER);
			Thread.sleep(5000);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			System.out.println("selectmachinelist:"+machineName+" total records::"+ totalOrderRecord.getText());

			softAssert.assertEquals(totalOrderRecord.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed on ORD Screen"+ common.captureScreenshot(ScreenshotRequire));

			String tot= totalOrderRecord.getText();
			String [] splitsvalues=common.splitValues(tot,"\\:");
			String TotalORDRecords=splitsvalues[1].trim();
			System.out.println("total records in ORD for machine name::"+areaName+"---"+machineName+"--" + TotalORDRecords);
			System.out.println("total records in MCS::"+ orderDetails.get("TotalCount"));

			softAssert.assertEquals(TotalORDRecords,orderDetails.get("TotalCount"),"Order Records counts are not same in MCS and ORD screen");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order Records counts are same in MCS and ORD screen:: "+orderDetails.get("TotalCount")+"<<"+TotalORDRecords);
			//order status verification from MCS and ORD screen
			if(Integer.parseInt(TotalORDRecords)>0) {
				js.executeScript("arguments[0].scrollIntoView();",ordId);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );

				Select selectstatus = new Select(statusDropDown);
				selectstatus.selectByVisibleText("Started");
				Thread.sleep(5000);			
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed for started order status");
				tot= totalOrderRecord.getText();
				String [] splitsStartedvalues=common.splitValues(tot,"\\:");
				TotalORDRecords=splitsStartedvalues[1].trim();
				if((TotalORDRecords.equals(orderDetails.get("Started"))) && (Integer.parseInt(TotalORDRecords)>0)) {
					softAssert.assertEquals(ordId.getText(),orderDetails.get("startOrderIdDetails"),"Started Order ID are not same in MCS and ORD screen");

				}else{
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - no order started in ORD screen");
					WebTestCase.getTest().log(LogStatus.PASS, "Started Order Records counts are not same in MCS and ORD screen");
				}
				System.out.println("TotalORDRecords started::"+TotalORDRecords+"--mCS started:: "+orderDetails.get("Started"));

				selectstatus.selectByVisibleText("New");
				Thread.sleep(5000);		
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed for new order status");
				String totNew= totalOrderRecord.getText();
				System.out.println("total new record"+ totNew);
				String [] splitsNewvalues=common.splitValues(totNew,"\\:");
				TotalORDRecords=splitsNewvalues[1].trim();
				System.out.println("TotalORDRecords new::"+TotalORDRecords+"-- mCS new:: "+orderDetails.get("New"));

				softAssert.assertEquals(TotalORDRecords,orderDetails.get("New"),"New Order Records counts are not same in MCS and ORD screen");

				selectstatus.selectByVisibleText("Held");
				Thread.sleep(5000);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
				tot= totalOrderRecord.getText();
				String [] splitsHeldvalues=common.splitValues(tot,"\\:");
				TotalORDRecords=splitsHeldvalues[1].trim();
				softAssert.assertEquals(TotalORDRecords,orderDetails.get("Held"),"on Hold Order Records counts are not same in MCS and ORD screen");
				System.out.println("TotalORDRecords held::"+TotalORDRecords+"::mCS held::"+orderDetails.get("Held"));
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - On Hold Order Records counts are same in MCS and ORD screen:: "+orderDetails.get("Held")+">>>"+TotalORDRecords+ common.captureScreenshot(ScreenshotRequire));

				selectstatus.selectByVisibleText("Off-Hold");
				Thread.sleep(5000);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
				tot= totalOrderRecord.getText();
				String [] splitsOffHoldvalues=common.splitValues(tot,"\\:");
				TotalORDRecords=splitsOffHoldvalues[1].trim();
				softAssert.assertEquals(TotalORDRecords,orderDetails.get("Off-Hold"),"Off-Hold Order Records counts are not same in MCS and ORD screen");
				System.out.println("TotalORDRecords held::"+TotalORDRecords+"::mCS offhold::"+orderDetails.get("Off-Hold"));
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Off Hold Order Records counts are same in MCS and ORD screen: "+orderDetails.get("Off-Hold")+">>>"+TotalORDRecords+ common.captureScreenshot(ScreenshotRequire));


			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order count is 0 in MCS and ORD screen");
			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	@SuppressWarnings({ "static-access" })
	public String validateOrderAndQtyOnOrderCockpitPage(HashMap<String, String> mCScreenOrderDetails, String ScreenshotRequire) throws InterruptedException{

		String val=null;

		try{
			SoftAssert softAssert = new SoftAssert();
			System.out.println("inside validateOrderAndQtyOnOrderCockpitPage function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(10000);
			highLighterMethod(driver,orderTextbox);
			orderTextbox.sendKeys(String.valueOf(mCScreenOrderDetails.get("OrderNo")));
			orderTextbox.sendKeys(Keys.RETURN);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));
			softAssert.assertEquals(schedulquantitylist.getText().trim(),mCScreenOrderDetails.get("targetQty").trim(),"schedul quantity list is not same in MCS and Order Cockpit screen");
			softAssert.assertTrue(Integer.parseInt(goodquantitylist.getText())>=Integer.parseInt(mCScreenOrderDetails.get("goodqty")),"Good quantity list is not same in MCS and Order Cockpit screen");
			//softAssert.assertTrue(Integer.parseInt(badquantitylist.getText())>=Integer.parseInt(mCScreenOrderDetails.get("afterReportscrapqty")),"Bad or Scrap quantity list is not same in MCS and Order Cockpit screen");

			WebTestCase.getTest().log(LogStatus.PASS, "schedule quantity list in MCS and Order Cockpit screen:"+mCScreenOrderDetails.get("targetQty")+"--"+schedulquantitylist.getText());
			WebTestCase.getTest().log(LogStatus.PASS, "Good quantity list in MCS and Order Cockpit screen:"+mCScreenOrderDetails.get("goodqty")+"--"+goodquantitylist.getText());
			//WebTestCase.getTest().log(LogStatus.PASS, "Bad quantity list in MCS and Order Cockpit screen:"+mCScreenOrderDetails.get("afterReportscrapqty")+"--"+badquantitylist.getText());

			JavascriptExecutor js = (JavascriptExecutor)driver;	
			js.executeScript("arguments[0].scrollIntoView();",actualstartdatelist);
			Thread.sleep(10000);

			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm");
			Date expectedstartdateList = sdf.parse(expectedstartdatelist.getText().trim());
			Date ExpectedStartDate = sdf.parse(mCScreenOrderDetails.get("ExpectedStartDate").trim());

			System.out.println("date1 : " + sdf.format(expectedstartdateList));
			System.out.println("date2 : " + sdf.format(ExpectedStartDate));

			if(expectedstartdateList.equals(ExpectedStartDate)) {
				WebTestCase.getTest().log(LogStatus.PASS, "expected start date in MCS and ORD screen:"+mCScreenOrderDetails.get("ExpectedStartDate")+"--"+expectedstartdatelist.getText());
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "expected start date not matching in MCS and ORD screen:"+mCScreenOrderDetails.get("ExpectedStartDate")+"--"+expectedstartdatelist.getText());
			}

			Date expectedenddateList = sdf.parse(expectedenddatelist.getText().trim());
			Date ExpectedCompletionDate = sdf.parse(mCScreenOrderDetails.get("ExpectedCompletionDate").trim());

			if(expectedenddateList.equals(ExpectedCompletionDate))
			{
				WebTestCase.getTest().log(LogStatus.PASS, "expected end date in MCS and ORD screen:"+mCScreenOrderDetails.get("ExpectedCompletionDate")+"--"+expectedenddatelist.getText());

			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "expected end date not matching in MCS and ORD screen:"+mCScreenOrderDetails.get("ExpectedCompletionDate")+"--"+expectedenddatelist.getText());

			}
			Date actualstartdateList = sdf.parse(actualstartdatelist.getText().trim());
			Date ActualStartDate = sdf.parse(mCScreenOrderDetails.get("ActualStartDate").trim());

			if(actualstartdateList.equals(ActualStartDate)) {
				WebTestCase.getTest().log(LogStatus.PASS, "actual start date in MCS and ORD screen:"+mCScreenOrderDetails.get("ActualStartDate")+"--"+actualstartdatelist.getText());

			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "actual start date not matching in MCS and ORD screen:"+mCScreenOrderDetails.get("ActualStartDate")+"--"+actualstartdatelist.getText());

			}
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

		driver.switchTo().defaultContent();
		return val;			
	}	


	@SuppressWarnings({ "static-access" })
	public String validateOrderAndQtyOnOrderCockpitPageAfterBuildPallet(HashMap<String, String> mCScreenOrderDetails, String ScreenshotRequire) throws InterruptedException{

		String val=null;

		try{
			SoftAssert softAssert = new SoftAssert();
			System.out.println("inside validateOrderAndQtyOnOrderCockpitPageAfterBuildPallet function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(8000);
			highLighterMethod(driver,orderTextbox);
			orderTextbox.sendKeys(String.valueOf(mCScreenOrderDetails.get("orderId")));
			orderTextbox.sendKeys(Keys.RETURN);
			Thread.sleep(5000);
			Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));

			softAssert.assertEquals(schedulquantitylist.getText().trim(),mCScreenOrderDetails.get("targetqty").trim(),"schedul quantity is not same in MCS and Order Cockpit screen");
			softAssert.assertTrue(Integer.parseInt(goodquantitylist.getText())>=Integer.parseInt(mCScreenOrderDetails.get("completedqty")),"Completed quantity is not same in MCS and Order Cockpit screen");
			softAssert.assertTrue(Integer.parseInt(remainingquantitylist.getText())>=Integer.parseInt(mCScreenOrderDetails.get("palletqty")),"Remaining quantity is not same in MCS and Order Cockpit screen");
			highLighterMethod(driver,remainingquantitylist);
			WebTestCase.getTest().log(LogStatus.PASS, "schedule quantity in MCS and Order Cockpit screen:"+mCScreenOrderDetails.get("targetqty")+"--"+schedulquantitylist.getText());
			WebTestCase.getTest().log(LogStatus.PASS, "Completed/Good quantity in MCS and Order Cockpit screen:"+mCScreenOrderDetails.get("completedqty")+"--"+goodquantitylist.getText());
			WebTestCase.getTest().log(LogStatus.PASS, "Remaining quantity in MCS and Order Cockpit screen:"+mCScreenOrderDetails.get("palletqty")+"--"+remainingquantitylist.getText());


		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

		driver.switchTo().defaultContent();
		return val;			
	}
	/**
	 * Method To searchOrderOnOrderCockpitPageWithOId
	 * @author Arpana
	 * @return 
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public String searchOrderOnOrderCockpitPageWithOId(String oId, String ScreenshotRequire) throws InterruptedException{

		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPageWithOId function with oid: "+ oId);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			if(oId!=null) {
				Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
				Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
				Thread.sleep(10000);
				common.setObjectValue(orderSearchTextbox, "orderSearchTextbox", oId);
				orderSearchTextbox.sendKeys(Keys.RETURN);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Thread.sleep(5000);
				System.out.println("sent value on orderTextbox "+oId);
			}
			String tot= totalOrderRecord.getText();
			String [] splitsvalues=common.splitValues(tot,"\\:");
			String TotalORDRecords=splitsvalues[1].trim();

			if(Integer.parseInt(TotalORDRecords)==0){
				val=null;
				System.out.println("order list not displaying in ORD screen, count: "+ TotalORDRecords);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List is not displayed for given search, total count is: "+ TotalORDRecords+ common.captureScreenshot(ScreenshotRequire));
			}else {

				Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
				Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));
				System.out.println("order list displaying, count: "+ TotalORDRecords);
				val=TotalORDRecords;
			}}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	/**
	 * selectColorFilter
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String selectColorFilter(String color, String ScreenshotRequire){	
		System.out.println("inside selectColorFilter details");
		String ncNumber=null;
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",colorfilterIcon);
			Thread.sleep(10000);
			Common.isElementDisplayed(driver, colorfilterIcon, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(colorfilterIcon,"colorfilterIcon");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );

			Common.isElementDisplayed(driver, deselectAllSelectedBtn, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(deselectAllSelectedBtn,"deselectAllSelectedBtn");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );

			if(removeSelectedBtn.isEnabled()) {
				common.clickOnObject(removeSelectedBtn,"removeSelectedBtn");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			}
			for(int i=0;i<colorSelectPopUp.size();i++) {
				if(colorSelectPopUp.get(i).getText().contains(color)) {
					common.clickOnObject(colorSelectPopUp.get(i),"color");
					Actions action =new Actions(driver);
					action.doubleClick(colorSelectPopUp.get(i)).perform();
					System.out.println("clicked on color"+ colorSelectPopUp.get(i).getText());
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - clicked on color"+ common.captureScreenshot(ScreenshotRequire));
					break;
				}
			}
			if(leftSideDivPanel.getAttribute("innerText").length()>0) {
				System.out.println("value added from popup window");
				if(okBtn.isEnabled()) {
					common.clickOnObject(okBtn,"okBtn");
					System.out.println("ok button clicked");
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
					Thread.sleep(20000);
				}
			}

			driver.switchTo().defaultContent();


		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return ncNumber;
	}

	/**
	 * validateOrderDetailsWithGreenAndRedColorFilter
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String validateOrderDetailsWithGreenAndRedColorFilter(String color, String ScreenshotRequire){	
		System.out.println("inside validateOrderDetailsWithGreenAndRedColorFilter details");
		String ncNumber=null;


		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );

			if(color.contains("Green")) {
				HashMap<Integer,String> hm1=new HashMap<Integer,String>();
				hm1.put(0, "Started");
				hm1.put(1, "New");
				hm1.put(2, "Held");
				/*hm1.put(3, "Completed");
				hm1.put(4, "Closed");*/
				String tot= totalOrderRecord.getText();
				String [] splitsvalues=common.splitValues(tot,"\\:");
				String TotalORDRecords=splitsvalues[1].trim();

				if(Integer.parseInt(TotalORDRecords)==0){
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD Screen is displayed with no record for color:: "+color+common.captureScreenshot(ScreenshotRequire) );

				}else {
					Assert.assertEquals(colorcode.getText(), color,"color filter result is not appearing correctly");
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD Screen is displayed with record count: "+TotalORDRecords+common.captureScreenshot(ScreenshotRequire) );
					Common.isElementDisplayed(driver, machineStatus, IConstants.HIGH_WAIT_TIME);
					machineStatus.clear();
					common.setObjectValue(machineStatus, "machineStatus", "Down");
					machineStatus.sendKeys(Keys.RETURN);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
					String totDown= totalOrderRecord.getText();
					String [] splitsDownvalues=common.splitValues(totDown,"\\:");
					String TotalORDDownRecords=splitsDownvalues[1].trim();
					if(Integer.parseInt(TotalORDDownRecords)>0) {
						WebTestCase.getTest().log(LogStatus.FAIL, "Verified - ORD screen record with color filter and machine status is down count:"+color+"--"+TotalORDDownRecords+common.captureScreenshot(ScreenshotRequire) );

					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with color filter and machine status is down count:"+color+"--"+TotalORDDownRecords+common.captureScreenshot(ScreenshotRequire) );

					}
					machineStatus.clear();
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
					Thread.sleep(5000);
					JavascriptExecutor js = (JavascriptExecutor)driver; 	
					js.executeScript("arguments[0].scrollIntoView();",statusDropDown);
					Thread.sleep(5000);
					//verify with  status filter.
					for(int i=0; i<hm1.size();i++) {

						Select select = new Select(statusDropDown);
						select.selectByVisibleText(hm1.get(i));
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
						Thread.sleep(5000);
						System.out.println("sent value on statusDropDown: "+ hm1.get(i));

						String totval= totalOrderRecord.getText();
						String [] splitsval=common.splitValues(totval,"\\:");
						String TotalRecords=splitsval[1].trim();
						if(Integer.parseInt(TotalRecords)>0) {
							if(hm1.get(i).contains("Started")) {
								//Assert.assertEquals(Integer.parseInt(TotalRecords), Integer.parseInt(TotalORDRecords),"Started record count is not coming correctly");
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with status filter is :"+color+"--"+hm1.get(i)+"--"+TotalRecords+"<b>, production order is started and execution is according to the plan</b>"+common.captureScreenshot(ScreenshotRequire) );

							}else {
								WebTestCase.getTest().log(LogStatus.FAIL, "Verified - ORD screen record with status filter is :"+color+"--"+hm1.get(i)+"--"+TotalRecords+common.captureScreenshot(ScreenshotRequire) );
							}
						}else {
							WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with status filter is: "+color+"--"+hm1.get(i)+"--"+TotalRecords+common.captureScreenshot(ScreenshotRequire) );
						}
					}
					Select select = new Select(statusDropDown);
					select.selectByVisibleText("[All]");
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
					Thread.sleep(5000);
				}
			}if(color.contains("Red")) {
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				String tot= totalOrderRecord.getText();
				String [] splitsvalues=common.splitValues(tot,"\\:");
				String TotalORDRecords=splitsvalues[1].trim();
				if(Integer.parseInt(TotalORDRecords)>0){

					Assert.assertEquals(colorcode.getText(), color,"color filter result is not appearing correctly");
					JavascriptExecutor js = (JavascriptExecutor)driver; 	
					Thread.sleep(5000);
					js.executeScript("arguments[0].scrollIntoView();",machineStatus);
					Thread.sleep(5000);

					common.setObjectValue(machineStatus, "machineStatus", "Up");
					machineStatus.sendKeys(Keys.RETURN);
					Thread.sleep(5000);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
					String totDown= totalOrderRecord.getText();
					String [] splitsDownvalues=common.splitValues(totDown,"\\:");
					String TotalORDDownRecords=splitsDownvalues[1].trim();
					if(Integer.parseInt(TotalORDDownRecords)>0) {
						WebTestCase.getTest().log(LogStatus.FAIL, "Verified - ORD screen record with color filter red and machine status up count:"+TotalORDDownRecords +" ;for red orders,  order shouldn't be on UP status"+common.captureScreenshot(ScreenshotRequire) );

					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with color filter red and machine status up count:"+TotalORDDownRecords+" ;for red color order , if Order status is UP then order count should be 0"+common.captureScreenshot(ScreenshotRequire) );

					}
					machineStatus.clear();
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
					Thread.sleep(5000);
					Select select = new Select(statusDropDown);
					select.selectByVisibleText("[All]");
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
					Thread.sleep(5000);
				}else {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with color filter red count:"+TotalORDRecords+common.captureScreenshot(ScreenshotRequire) );

				}

			}if(color.contains("Purple")) {
				String tot= totalOrderRecord.getText();
				String [] splitsvalues=common.splitValues(tot,"\\:");
				String TotalORDRecords=splitsvalues[1].trim();

				if(Integer.parseInt(TotalORDRecords)==0){
					Assert.assertEquals(colorcode.getText(), color,"color filter result is not appearing correctly");
					JavascriptExecutor js = (JavascriptExecutor)driver; 	
					js.executeScript("arguments[0].scrollIntoView();",orderTextbox);
					Thread.sleep(5000);
					String totPurple= totalOrderRecord.getText();
					String [] splitsPurplevalues=common.splitValues(totPurple,"\\:");
					String TotalORDPurpleRecords=splitsPurplevalues[1].trim();
					if(Integer.parseInt(TotalORDPurpleRecords)>0) {
						WebTestCase.getTest().log(LogStatus.FAIL, "Verified - ORD screen record with color filter Purple count:"+TotalORDPurpleRecords+common.captureScreenshot(ScreenshotRequire) );
						for(WebElement ele :webListOrder){
							if(ele.isDisplayed()==true){
								if(ele.getAttribute("innerHTML").contains("img"))
								{
									System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
								}
								else {
									String val=ele.getAttribute("innerHTML").trim();
									val=val+"_"+OrderTypeRecord.getText().trim()+"_"+ProductIdRecord.getText().trim()+"_"+scheduledQuanList.getText().trim()+"_"+goodQuanList.getText().trim()+"_"+badQuanList.getText().trim()+"_"+scheStartDate.getText().trim()+"_"+schEndDate.getText().trim()+"_"+actualStartDate.getText().trim();
									driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']")).click();
									Actions action =new Actions(driver);
									action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();
									System.out.println("clicked on order"+ val);
									break;
								}

							}
						}

					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with color filter Purple and machine status up count:"+TotalORDPurpleRecords+common.captureScreenshot(ScreenshotRequire) );

					}

				}else {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with color filter Purple count:"+TotalORDRecords+common.captureScreenshot(ScreenshotRequire) );

				}
			}
			driver.switchTo().defaultContent();


		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return ncNumber;
	}

	/**
	 * Method To search Order On Order Cockpit Page and validate status
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings("static-access")
	public String validateOrderColor(String orderId, String ScreenshotRequire) throws InterruptedException{

		String val=null;
		try{
			System.out.println("inside validateOrderColor function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(4000);
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(10000);
			common.setObjectValue(orderTextbox,"oId",orderId);
			orderTextbox.sendKeys(Keys.ENTER);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(10000);
			System.out.println("sent value on orderTextbox "+orderId);

			Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));

			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",colorfilterIcon);
			Thread.sleep(10000);

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalORDRecords=splitsvalues[1].trim();
			if(Integer.parseInt(TotalORDRecords)>0) {
				Assert.assertEquals(machinestatuslist.getText().trim(), "Down","Machine status is not coming correctly");
				Assert.assertEquals(colorcode.getText(), "Red","color filter result is not appearing correctly");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Machine status is down :"+machinestatuslist.getText().trim()+ common.captureScreenshot(ScreenshotRequire));
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Red Color order is available: "+ common.captureScreenshot(ScreenshotRequire));

			}else {
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Order id is not appearing in ORD screen "+ common.captureScreenshot(ScreenshotRequire));

			}


		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	/**
	 * validateOrderDetailsWithYellowColorFilter
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String validateOrderDetailsWithYellowColorFilter(String color, String ScreenshotRequire){	
		System.out.println("inside validateOrderDetailsWithYellowColorFilter details");
		String ncNumber=null;
		HashMap<Integer,String> hm1=new HashMap<Integer,String>();
		hm1.put(0, "Started");
		hm1.put(1, "New");
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );

			if(color.contains("Yellow")) {
				String tot= totalOrderRecord.getText();
				String [] splitsvalues=common.splitValues(tot,"\\:");
				String TotalORDRecords=splitsvalues[1].trim();

				if(Integer.parseInt(TotalORDRecords)==0){
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD Screen is displayed with no record for color:: "+ color+common.captureScreenshot(ScreenshotRequire) );

				}else {
					Assert.assertEquals(colorcode.getText(), color,"color filter result is not appearing correctly");
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD Screen is displayed with record count: "+TotalORDRecords+common.captureScreenshot(ScreenshotRequire) );

					SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
					Date date = new Date();
					String time = sdf.format(date);
					String previousDateStringval=Common.previousDateString(time)+" "+"12:00:00 AM";

					JavascriptExecutor js = (JavascriptExecutor)driver; 	
					js.executeScript("arguments[0].scrollIntoView();",expStartDate);
					Thread.sleep(5000);

					expStartDate.click();
					Thread.sleep(5000);
					common.setObjectValue(expStartDate, "expStartDate", previousDateStringval);
					expStartDate.sendKeys(Keys.TAB);
					Thread.sleep(15000);
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - From date entered"+ common.captureScreenshot(ScreenshotRequire));

					String [] splitsvaluesAfterexpDate=common.splitValues(totalOrderRecord.getText(),"\\:");
					String TotalORDRecordsExpDate=splitsvaluesAfterexpDate[1].trim();

					if(Integer.parseInt(TotalORDRecordsExpDate)==0){
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD Screen is displayed with no record if entered exp date as previous date"+common.captureScreenshot(ScreenshotRequire) );

					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD Screen is displayed with record if entered exp date as previous date: "+TotalORDRecords+common.captureScreenshot(ScreenshotRequire) );
					}

					js.executeScript("arguments[0].scrollIntoView();",statusDropDown);
					Thread.sleep(5000);
					for(int i=0; i<hm1.size();i++) {
						Select select = new Select(statusDropDown);
						select.selectByVisibleText(hm1.get(i));
						common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
						Thread.sleep(5000);
						System.out.println("sent value on statusDropDown: "+ hm1.get(i));

						String totval= totalOrderRecord.getText();
						String [] splitsval=common.splitValues(totval,"\\:");
						String TotalRecords=splitsval[1].trim();
						if(Integer.parseInt(TotalRecords)>0) {
							if(hm1.get(i).contains("Started")){
								WebTestCase.getTest().log(LogStatus.FAIL, "Verified - ORD screen record with status filter is :"+color+"--"+hm1.get(i)+"--"+TotalRecords+common.captureScreenshot(ScreenshotRequire) );
							}else {
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with status filter is :"+color+"--"+hm1.get(i)+"--"+TotalRecords+common.captureScreenshot(ScreenshotRequire) );
							}
						}else {
							if(hm1.get(i).contains("Started")){
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with status filter is :"+color+"--"+hm1.get(i)+"--"+TotalRecords+" , start time is already passed and order not yet started"+common.captureScreenshot(ScreenshotRequire) );
							}else {
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with status filter is: "+color+"--"+hm1.get(i)+"--"+TotalRecords+common.captureScreenshot(ScreenshotRequire) );
							}
						}
					}
				}
			}

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return ncNumber;
	}

	/**
	 * click on order
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String clickOrder(String color, String ScreenshotRequire){	
		System.out.println("inside clickOrder details");
		String ncNumber=null;
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Assert.assertEquals(colorcode.getText(), color,"color filter result is not appearing correctly");
			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",orderTextbox);
			Thread.sleep(5000);
			String totPurple= totalOrderRecord.getText();
			String [] splitsPurplevalues=common.splitValues(totPurple,"\\:");
			String TotalORDPurpleRecords=splitsPurplevalues[1].trim();
			if(Integer.parseInt(TotalORDPurpleRecords)>0) {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with color filter Purple count:"+TotalORDPurpleRecords+common.captureScreenshot(ScreenshotRequire) );
				for(WebElement ele :webListOrder){
					if(ele.isDisplayed()==true){
						if(ele.getAttribute("innerHTML").contains("img"))
						{
							System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
						}
						else {
							String val=ele.getAttribute("innerHTML").trim();
							val=val+"_"+OrderTypeRecord.getText().trim()+"_"+ProductIdRecord.getText().trim()+"_"+scheduledQuanList.getText().trim()+"_"+goodQuanList.getText().trim()+"_"+badQuanList.getText().trim()+"_"+scheStartDate.getText().trim()+"_"+schEndDate.getText().trim()+"_"+actualStartDate.getText().trim();
							driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']")).click();
							Actions action =new Actions(driver);
							action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();
							System.out.println("clicked on order"+ val);
							break;
						}

					}
				}

			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - ORD screen record with color filter Purple and machine status up count:"+TotalORDPurpleRecords+common.captureScreenshot(ScreenshotRequire) );

			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return ncNumber;
	}


	public void highLighterMethod(WebDriver driver, WebElement element){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
	}

	@SuppressWarnings("static-access")
	public String findOrderDetails(String oStatus,String oId, String line,String ScreenshotRequire) throws InterruptedException{

		String val=null;
		int flag=0;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPage function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(10000);
			orderSearchTextbox.clear();
			common.setObjectValue(orderSearchTextbox, "orderSearchTextbox", oId);
			orderSearchTextbox.sendKeys(Keys.RETURN);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(10000);
			System.out.println("sent value on orderTextbox "+oId);
			if(oId.length()==1) {

				Select select = new Select(statusDropDown);
				select.selectByVisibleText(oStatus);
				Thread.sleep(10000);

				System.out.println("sent value on statusDropDown "+oStatus);

				JavascriptExecutor js = (JavascriptExecutor)driver; 	
				js.executeScript("arguments[0].scrollIntoView();",selectProductLine);
				Thread.sleep(10000);

				Select select1 = new Select(selectProductLine);
				select1.selectByVisibleText(line);
				Thread.sleep(10000);
				System.out.println("selectProductLine:"+line);
			}
			String tot= totalOrderRecord.getText();
			String [] splitsvalues=common.splitValues(tot,"\\:");
			String TotalORDRecords=splitsvalues[1].trim();

			if(Integer.parseInt(TotalORDRecords)==0){
				val=null;
				System.out.println("order list not displaying, count: "+ TotalORDRecords);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List is not displayed for given search, total count is: "+ TotalORDRecords+ common.captureScreenshot(ScreenshotRequire));
			}else {
				Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
				Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));
				System.out.println("order list displaying, count: "+ TotalORDRecords);
				int Totalpage=0;
				if(Integer.parseInt(TotalORDRecords)>10) {
					Totalpage=Integer.parseInt(TotalORDRecords)/10;
				}else {
					Totalpage=1;
				}
				for(int i=0;i<Totalpage;i++) {
					for(WebElement ele :webListOrder){
						if(ele.isDisplayed()==true){
							if(ele.getAttribute("innerHTML").contains("img"))
							{
								System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
							}
							else {
								flag=1;
								val=ele.getAttribute("innerHTML");    
								val=val+"_"+OrderTypeRecord.getText()+"_"+ProductIdRecord.getText()+"_"+scheduledQuanList.getText()+"_"+goodQuanList.getText()+"_"+badQuanList.getText()+"_"+scheStartDate.getText()+"_"+schEndDate.getText()+"_"+actualStartDate.getText()+"_"+expStart.getText()+"_"+expEnd.getText();
								/*driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']")).click();
							Actions action =new Actions(driver);
							action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();*/
								break;
							}
						}
					}
					if(flag==1) {
						break;
					}else if(NextPage.isEnabled()) {
						System.out.println("val of I:: "+ i);
						common.clickOnObject(NextPage, "NextPage");
						Thread.sleep(3000);
					}
				}
				Assert.assertEquals(flag, 1,  "Valid order list of status: "+oStatus+" : is not displaying");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));

				//val=orderList.getText();
				//detailsButton.click();
				System.out.println("clicked on order"+ val);
			}
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}
	/**
	 * Method To searchOrderOnOrderCockpitPageWithOId
	 * @author Arpana
	 * @return 
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validatePOEScreenWithORDScreen(HashMap<String, String> poeData, String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside validatePOEScreenWithORDScreen function with oid: "+ poeData.get("orderNo"));
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			if(expectedstartdatelist.getText().trim().equals(poeData.get("expectedstartdatelist"))) {
				WebTestCase.getTest().log(LogStatus.PASS, "expected start date in POE and ORD screen: "+poeData.get("expectedstartdatelist")+"--"+expectedstartdatelist.getText()+" for order Id: "+ poeData.get("orderNo"));
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "expected start date not matching in POE and ORD screen:"+poeData.get("expectedstartdatelist")+"--"+expectedstartdatelist.getText());
			}
			if(expectedenddatelist.getText().trim().equals(poeData.get("expectedenddatelist")))
			{
				WebTestCase.getTest().log(LogStatus.PASS, "expected end date in POE and ORD screen: "+poeData.get("expectedenddatelist")+"--"+expectedenddatelist.getText()+" for order Id: "+ poeData.get("orderNo"));
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "expected end date not matching in POE and ORD screen:"+poeData.get("expectedenddatelist")+"--"+expectedenddatelist.getText());
			}
			if(actualstartdatelist.getText().trim().equals(poeData.get("actualstartdatelist"))) {
				WebTestCase.getTest().log(LogStatus.PASS, "actual start date in POE and ORD screen: "+poeData.get("actualstartdatelist")+"--"+actualstartdatelist.getText()+" for order Id: "+ poeData.get("orderNo"));
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "actual start date not matching in POE and ORD screen:"+poeData.get("actualstartdatelist")+"--"+actualstartdatelist.getText());
			}			
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To search Order On Order Cockpit history Page
	 * @author Arpana Kumari
	 * @throws InterruptedException 
	 */

	@SuppressWarnings("static-access")
	public String searchOrderOnHistoryPage(String title, String oStatus, String oId, String ScreenshotRequire) throws InterruptedException{
		String statusval=null;
		int flag=0;
		try{
			System.out.println("inside searchOrderOnHistoryPage function::oStatus::"+oStatus);

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, ORDHistoryPageTitle, IConstants.HIGH_WAIT_TIME);
			Assert.assertEquals(ORDHistoryPageTitle.getText(), title,  "Order Cockpit History page not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order Cockpit History page is displayed successfuly"+common.captureScreenshot(ScreenshotRequire) );
			
			
			String tot= totalOrderRecord.getText();
			String [] splitsvalues=common.splitValues(tot,"\\:");
			String TotalORDRecords=splitsvalues[1].trim();

			if(Integer.parseInt(TotalORDRecords)>0){
				productionordernolistvisTextBox.click();
				productionordernolistvisTextBox.clear();				
				common.setObjectValue(productionordernolistvisTextBox, "productionordernolistvisTextBox", oId);
				productionordernolistvisTextBox.sendKeys(Keys.ENTER);
				Thread.sleep(2000);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				tot= totalOrderRecord.getText();
				splitsvalues=common.splitValues(tot,"\\:");
				TotalORDRecords=splitsvalues[1].trim();
				if(Integer.parseInt(TotalORDRecords)>0){
					statusval= productionorderstatuslist.getText();
					Assert.assertEquals(statusval, "Closed","Order status is not matching");
				}else {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order id not appearing in history page "+ common.captureScreenshot(ScreenshotRequire));
				}
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order listing unavailable in history page "+ common.captureScreenshot(ScreenshotRequire));
			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return statusval;			
	}
}

