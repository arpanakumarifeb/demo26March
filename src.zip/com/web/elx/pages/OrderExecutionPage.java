package com.web.elx.pages;
import static org.junit.Assert.assertArrayEquals;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;
public class OrderExecutionPage {

	SoftAssert softAssert = new SoftAssert();
	private WebDriver driver;
	private Common common;

	@FindBy(xpath = "//tr[@data-class='ELX_GridColorCode_Red']")
	private List<WebElement> orders;

	@FindBy(xpath = "//span[text()='Create NC']")
	private WebElement createNC;

	@FindBy(xpath ="//td[contains(@data-field,'productionordernolist')]//span[@class='display']")
	private WebElement ordId;

	@FindBy(xpath = "//button[@class='ToolButton legend']")
	private WebElement startLegend;

	@FindBy(xpath = "((//input[@placeholder='Find a screen...'])[1]//..//../div/div[2])[1]")
	private WebElement searchItem;

	@FindBy(xpath = "//div[@id='ELX_SelectOperation']/div[1]")
	private WebElement selectOperation;

	@FindBy(xpath = "(//span[@class='fa fa-close ELX_window-close'])[5]")
	private WebElement windowClose;
	@FindBy(xpath = "//span[text()='Legend']//../..//td[@class='ELX_GridColorCode_Green']/../td/span")
	private WebElement gridClrCodeGreen;
	@FindBy(xpath = "//span[text()='Legend']//../..//td[@class='ELX_GridColorCode_Yellow']/../td/span")
	private WebElement gridClrCodeYellow;
	@FindBy(xpath = "//span[text()='Legend']//../..//td[@class='ELX_GridColorCode_Red']/../td/span")
	private WebElement gridClrCodeRed;
	@FindBy(xpath = "//span[text()='Legend']//../..//td[@class='ELX_GridColorCode_Purple']/../td/span")
	private WebElement gridClrCodePurple;
	@FindBy(xpath = "//span[text()='Legend']//../..//td[@class='ELX_GridColorCode_White']/../td/span")
	private WebElement gridClrCodeWhite;

	@FindBy(xpath = "//span[contains(@class,'apr-header-action return no-icon')]")
	private WebElement backIcon;

	@FindBy(xpath = "//*//h2[contains(text(),'Non-Conformity Information')]")
	private WebElement ncScreen;

	@FindBy(xpath = "//li[contains(@title,'Employee.SelectWorkArea')]")
	private WebElement returnScreen;

	@FindBy(xpath = "//tr[@class='HeadF']/td[4]/div/input")
	private WebElement productTextbox;

	@FindBy(xpath ="//*[contains(@class, 'ELX_GridColorCode')]/td[4]/div/span")
	private WebElement prodId;

	@FindBy(xpath ="//span[@title='Return']")
	private WebElement returnIcon;

	@FindBy(xpath = "//*[@class='ELX_Button_hexagon']")
	private WebElement stopIcon;

	@FindBy(xpath = "//*[@class='ELX_Button_Circle']")
	private WebElement helpIcon;

	@FindBy(xpath = "//*[@class='ELX_Button_Triangle']")
	private WebElement nonConfIcon;

	@FindBy(xpath = "//*[text()='DFP list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")
	private WebElement stopWindowClose;

	@FindBy(xpath = "//*[text()='Help list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")
	private WebElement helpWindowClose;

	@FindBy(xpath = "//*[text()='NonConformity list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")
	private WebElement nonConfWindowClose;

	@FindBy(xpath = "//*[text()='Machine Status']//..//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")
	private WebElement macdownstatusClose;

	@FindBy(xpath = "//*[@id='ctl03_ClientSFContainer']//../h2")
	private WebElement prod10;

	//@FindBy(xpath = "//div[@class='FormContainer']/h2")
	@FindBy(xpath = ".//li[@title='POE-010']")
	private WebElement header;

	@FindBy(xpath = ".//td[@class='Control fc_Area Bold']/span")
	private WebElement areaHeaderText;

	@FindBy(xpath = "//div[@class='Total']")
	private WebElement recValue;

	@FindBy(xpath = "//*[contains(@id,'ELX_SelectAction')]")
	private WebElement orderExecData;

	@FindBy(xpath = "//*[contains(@id,'ELX_SelectAction')]")
	private WebElement mousehoverIcons;

	@FindBy(xpath = "//*[@class='ELX_Button_hexagon']")
	private WebElement stopIconshexa;

	@FindBy(xpath = "(//span[@class='number'])[1]")
	private WebElement stopIco;

	@FindBy(xpath = "//*/div[@class='ELX_Button_Help']/div[@class='ELX_Button_Circle']/span[@class='number']")
	private WebElement helpIco;

	@FindBy(xpath = "//*/div[@class='ELX_Button_NC']/div[@class='ELX_Button_Triangle']//..//span[@class='number']")
	private WebElement ncIco;

	@FindBy(xpath = "//*/div[@class='ELX_Button_Machine']/div[@class='ELX_Machine_Circle ELX_red']")
	private WebElement mcstatusIco;

	@FindBy(xpath = "//*/div[@class='ELX_Button_Stop']")
	private WebElement stopIconst;

	@FindBy(xpath = "//div[@class='ELX_Button_Help']")
	private WebElement helpIconst;

	@FindBy(xpath = "//*/div[@class='ELX_Button_NC']")
	private WebElement ncIconst;

	@FindBy(xpath = "//*/div[@class='ELX_Button_Machine']")
	private WebElement mcdownIconst;

	@FindBy(xpath = "//*[@class='ELX_Button_Circle']")
	private WebElement helpIconscircle;

	@FindBy(xpath = "//*[@id='ToolTipHELP']/div")
	private WebElement helpnewwind;

	@FindBy(xpath = "//*[@class='ELX_Button_Triangle']")
	private WebElement nconfIconscircle;

	@FindBy(xpath = "//*[@class='ELX_Button_Machine']")
	private WebElement machinedwntime;

	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	@FindBy(xpath = "/*[@class='ELX_Button_hexagon']")
	private WebElement stopBtn;

	@FindBy(xpath = "//*[text()='DFP list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")
	private WebElement closeWindow;

	@FindBy(xpath = "(//*[text()='DFP list:']//following-sibling::span[contains(@class,'ELX_ToolTipText')]//*[contains(@style,'font-weight: bold;')])/td[2]")
	private List <WebElement> reasonCodeList;

	@FindBy(xpath = "(//*[text()='DFP list:']//following-sibling::span[contains(@class,'ELX_ToolTipText')]//*[contains(@style,'font-weight: bold;')])/td[3]")
	private List <WebElement> criticalityList;

	@FindBy(xpath = "(//*[text()='Help list:']//following-sibling::span[contains(@class,'ELX_ToolTipText')]//*[contains(@style,'font-weight: bold;')])/td[3]")
	private List <WebElement> criticalityHelpList;

	@FindBy(xpath = "(//*[text()='Help list:']//following-sibling::span[contains(@class,'ELX_ToolTipText')]//*[contains(@style,'font-weight: bold;')])/td[2]")
	private List <WebElement> helpReasonCodeList;

	@FindBy(xpath = "(//*[text()='NonConformity list:']//following-sibling::span[contains(@class,'ELX_ToolTipText')]//*[contains(@style,'font-weight: bold;')])/td[2]")
	private List <WebElement> NCReasonCodeList;

	@FindBy(xpath = "(//*[text()='NonConformity list:']//following-sibling::span[contains(@class,'ELX_ToolTipText')]//*[contains(@style,'font-weight: bold;')])/td[3]")
	private List <WebElement> criticalityNCList;

	@FindBy(xpath = "//div[contains(@class,'ELX_Button')]//span[(contains(@style,'top'))]")
	private List <WebElement> ELXSelectActionList;

	@FindBy(xpath = ".//button[contains(@class,'ELX_BigSize') and not(@disabled)]/span")
	private List <WebElement> ELXButtonList;

	@FindBy(xpath = "(//div[contains(@class,'Right')])[2]")
	private WebElement ELXPrimaryButtonList;

	@FindBy(xpath = "//tr[@class='HeadT']")
	private WebElement ELX17iconRow;

	@FindBy(xpath = "//tr[@class='HeadT']/td")
	private List <WebElement> ELX17FieldList;
	//Added

	@FindBy(xpath = "//input[contains(@data-field, 'productionordernolist')]")
	private WebElement orderSearchTextbox;

	@FindBy(xpath = "//input[contains(@data-field, 'productionordernolist')]")
	private WebElement orderTextbox;

	@FindBy(xpath = "//div[@class='DropDownWrapper']/select")
	private WebElement statusDropDown;

	@FindBy(xpath = ".//td[contains(@class, 'value')][1]//span")
	private  WebElement orderList	;

	@FindBy(xpath = ".//td[contains(@class, 'value')][1]//span")
	private List <WebElement> webListOrder;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[2]")
	private WebElement OrderTypeRecord;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[4]")
	private WebElement ProductIdRecord;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[6]")
	private WebElement scheduledQuanList;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[7]")
	private WebElement goodQuanList;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[9]")
	private WebElement badQuanList;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[12]")
	private WebElement scheStartDate;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[13]")
	private WebElement schEndDate;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[14]")
	private WebElement actualStartDate;

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[3]")
	private WebElement Status;

	@FindBy(xpath = "//button[@data-key='hold']")
	private  WebElement btnHold	;

	@FindBy(xpath = "//button/span[contains(@class,'translation')]")
	private WebElement holdButtonOnPopup;

	@FindBy(xpath = "//button[@data-key='report']")
	private  WebElement btnReport	;

	@FindBy(xpath = "//button[@data-key='start']")
	private  WebElement btnStart	;

	@FindBy(xpath = "//button[@data-key='OffHold']")
	private  WebElement btnOffHold	;

	@FindBy(xpath = "//button[@data-key='GOTONC']")
	private  WebElement btnCreateNC;

	@FindBy(xpath = "//button[@data-key='REASSIGNSERIAL']")
	private  WebElement btnAssign;

	@FindBy(xpath = ".//input[@data-field='equipmentlist']")
	private  WebElement equipmentlistInputBox;

	@FindBy(xpath = ".//div[@class='Total']")
	private WebElement totalOrderRecord;

	@FindBy(xpath = ".//span[@class='display']")
	private List <WebElement> displayOrderRecord;

	@FindBy(xpath = ".//td[@data-field='schedulquantitylist']//span[@class='display']")
	private  WebElement schedulquantitylist;

	@FindBy(xpath = ".//td[@data-field='goodquantitylist']//span[@class='display']")
	private  WebElement goodquantitylist;

	@FindBy(xpath = ".//td[@data-field='badquantitylist']//span[@class='display']")
	private  WebElement badquantitylist;

	@FindBy(xpath = ".//td[@data-field='remainingquantitylist']//span[@class='display']")
	private  WebElement remainingquantitylist;

	@FindBy(xpath = ".//div[@class='ELX_progress-bar']/span")
	private  WebElement ELX_progressBar;

	@FindBy(xpath = ".//tr[contains(@class,'ELX_GridColorCode_Purple')]/td[1]")
	private WebElement ELX_GridColorCode_Purple_order;

	@FindBy(xpath = ".//tr[contains(@class,'ELX_GridColorCode_Green')]/td[3]")
	private WebElement ELX_GridColorCode_Green_status;


	@FindBy(xpath = ".//tr[contains(@class,'ELX_GridColorCode')]")
	private List <WebElement> ELX_GridColorCode;

	@FindBy(xpath = ".//tr[contains(@class,'ELX_GridColorCode')]/td[1]")
	private List <WebElement> ELX_GridColorCode_Oid;

	@FindBy(xpath = "(//tr[contains(@class,'ELX_GridColorCode')])[1]/td")
	private List <WebElement> ELX_GridColorCodeList;



	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[14]")
	private WebElement expStart;
	//

	@FindBy(xpath = "(//tr[2]/td[contains(@class, 'value')])[15]")
	private WebElement expEnd;

	@FindBy(xpath = ".//td[contains(@class, 'value')][3]//span")
	private List <WebElement> webListStatus;

	@FindBy(xpath = "//button[@class='ToolButton Export action action_export']")
	private WebElement exportIcon;

	@FindBy(xpath = "//button[@id='default']")
	private WebElement exportBtn;

	@FindBy(xpath = ".//td[@data-field='expectedstartdatelist']//span[@class='display']")
	private WebElement expectedstartdatelist;

	@FindBy(xpath = ".//td[@data-field='expectedenddatelist']//span[@class='display']")
	private WebElement expectedenddatelist;

	@FindBy(xpath = ".//td[@data-field='actualstartdatelist']//span[@class='display']")
	private WebElement actualstartdatelist;

	public OrderExecutionPage(WebDriver driver2){
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}

	public String clickOnOrder()
	{
		common.switchToFrame(By.xpath(iframepage), 130);
		Common.isElementDisplayed(driver, startLegend, 130);
		common.waitTillElementDisappears(By.xpath(toolbox), 500);
		System.out.println("------2");
		Common.isElementDisplayed(driver, orders.get(0), 30);
		String order=orders.get(0).getText();
		orders.get(0).click();
		driver.switchTo().defaultContent();
		return order;
	}
	public String clickCreateNC(String ScreenshotRequire){
		System.out.println("inside clickCreateNC");
		String img=null;
		try {
			common.switchToFrame(By.xpath(iframepage), 120);
			Common.isElementDisplayed(driver, startLegend, 100);
			common.waitTillElementDisappears(By.xpath(toolbox), 800);
			img=common.captureScreenshot(ScreenshotRequire);
			common.clickOnObject(createNC, "createNC");
			common.waitTillElementDisappears(By.xpath(toolbox), 800);
			//Assert.assertTrue(ncScreen.isDisplayed(),"Navigate page failed"); //newly added
			System.out.println("clicked on CreateNC btn");
			driver.switchTo().defaultContent();
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}catch(Exception exp2){
			System.out.println("Got Exception Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}
	public String clickStartLegend(String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), 130);
		Common.isElementDisplayed(driver, startLegend, 130);
		String img=common.captureScreenshot(ScreenshotRequire);
		common.clickOnObject(startLegend,"startLegend");
		common.waitTillElementDisappears(By.xpath(toolbox), 800);
		Assert.assertTrue(gridClrCodeGreen.isDisplayed());
		Assert.assertTrue(gridClrCodeYellow.isDisplayed());
		Assert.assertTrue(gridClrCodeRed.isDisplayed());
		Assert.assertTrue(gridClrCodePurple.isDisplayed());
		Assert.assertTrue(gridClrCodeWhite.isDisplayed());
		windowClose.click();

		driver.switchTo().defaultContent();
		return img;

	}

	public String tapSelectOperation(String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), 30);
		String img=common.captureScreenshot(ScreenshotRequire);
		Common.isElementDisplayed(driver, selectOperation, 30);
		common.clickOnObject(selectOperation,"selectOperation");
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		driver.switchTo().defaultContent();
		return img;
	}

	public String validateOrderID(String orderId, String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), 30);
		Common.isElementDisplayed(driver, startLegend, 30);
		common.waitTillElementDisappears(By.xpath(toolbox), 800);
		String img=common.captureScreenshot(ScreenshotRequire);
		Assert.assertTrue(driver.findElement(By.xpath("//tr[@class='ELX_GridColorCode_Purple']//../div/span[text()='"+orderId+" ']")).isDisplayed());
		driver.switchTo().defaultContent();
		return img;
	}

	@SuppressWarnings("unused")
	public String clickBackIcon(String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), 120);
		Common.isElementDisplayed(driver, startLegend, 100);
		common.waitTillElementDisappears(By.xpath(toolbox), 800);
		String img=common.captureScreenshot(ScreenshotRequire);
		Assert.assertTrue(backIcon.isDisplayed(),"backIcon failed");
		boolean value=false;
		if( value=true)
		{
			value=returnScreen.isDisplayed();
			System.out.println(value);
			common.clickOnObject(returnScreen, "returnScreen");
			common.waitTillElementDisappears(By.xpath(toolbox), 800);
			System.out.println("Back clickon passed");
		}
		else 
		{
			System.out.println(value);
		}
		//Reporter.log("Back/Return screen passed");
		driver.switchTo().defaultContent();
		return img;
	}



	//Product# Verification
	public String productFilter(String productId, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
		productTextbox.clear();
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, productTextbox, IConstants.SYS_WAIT_TIME);
		Assert.assertTrue(productTextbox.isDisplayed(), "Product# Textbox not displayed");
		common.setObjectValue(productTextbox, "productTextbox", productId);
		productTextbox.sendKeys(Keys.RETURN);
		System.out.println("Passed value:"+productId);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Assert.assertEquals(prodId.getText(), productId, "Product# is not in the list");
		String img=common.captureScreenshot(ScreenshotRequire);
		driver.switchTo().defaultContent();
		return img;

	}

	@SuppressWarnings("unused")
	public String clickStopIconVerify(String stopId, String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), 120);
		Common.isElementDisplayed(driver, startLegend, 100);
		common.waitTillElementDisappears(By.xpath(toolbox), 800);
		String img=common.captureScreenshot(ScreenshotRequire);
		Assert.assertTrue(stopIcon.isDisplayed(),"stopIcon failed");
		System.out.println("stopId Passed");
		boolean value=false;
		if( value=true)
		{
			value=stopIcon.isDisplayed();
			System.out.println(value);
			common.clickOnObject(stopIcon, "stopIcon");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='ELX_SelectAction']//../div/span[text()='"+stopId+"']")).isDisplayed());
			System.out.println("stopIcon Verify successfully");
			common.clickOnObject(stopWindowClose, "stopWindowClose");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		}
		else 
		{
			System.out.println(value);
		}
		//Reporter.log("stopIcon screen passed");
		driver.switchTo().defaultContent();
		return img;
	}
	@SuppressWarnings("unused")
	public String clickHelpIconVerify(String helpId, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), 120);
		Common.isElementDisplayed(driver, startLegend, 100);
		common.waitTillElementDisappears(By.xpath(toolbox), 800);
		String img=common.captureScreenshot(ScreenshotRequire);
		Assert.assertTrue(helpIcon.isDisplayed(),"helpIcon failed");
		System.out.println("helpId Passed");
		Thread.sleep(40000);
		common.MouseHoverFunction(helpIcon);
		common.clickOnObject(helpIcon, "helpIcon");
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		System.out.println("123");


		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='ELX_SelectAction']//../div/span[text()='"+helpId+" ']")).isDisplayed());
		System.out.println("helpId Verify successfully");
		common.clickOnObject(helpWindowClose, "helpWindowClose");
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
		//Reporter.log("helpIcon screen passed");
		driver.switchTo().defaultContent();
		return img;
	}

	@SuppressWarnings("unused")
	public String clickNonConfIconVerify(String nconfId, String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), 120);
		Common.isElementDisplayed(driver, startLegend, 100);
		common.waitTillElementDisappears(By.xpath(toolbox), 800);
		String img=common.captureScreenshot(ScreenshotRequire);
		Assert.assertTrue(nonConfIcon.isDisplayed(),"nonConfIcon failed");
		System.out.println("nonconf Passed");
		boolean value=false;
		if( value=true)
		{
			value=nonConfIcon.isDisplayed();
			System.out.println(value);
			common.clickOnObject(nonConfIcon, "nonConfIcon");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='ELX_SelectAction']//../div/span[text()='"+nconfId+" ']")).isDisplayed());
			System.out.println("nconfId Verify successfully");
			common.clickOnObject(nonConfWindowClose, "nonConfWindowClose");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		}
		else 
		{
			System.out.println(value);
		}
		//Reporter.log("nonConfIcon screen passed");
		driver.switchTo().defaultContent();
		return img;
	}

	public void validatePOE10Screen(String prodtext, String ScreenshotRequire){
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			Common.isElementDisplayed(driver, startLegend, 100);
			common.waitTillElementDisappears(By.xpath(toolbox),800);
			Assert.assertTrue(prod10.isDisplayed(),"prod10 failed");
			Assert.assertTrue(common.isElementVisible(By.xpath("//*[@id='ctl03_ClientSFContainer']//../h2")));
			if(prod10.getText().contains(prodtext))
			{

				System.out.println("Passs:Production text POE10 Screen");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - POE10 Production Text displayed "+ common.captureScreenshot(ScreenshotRequire));
			}
			else 
			{
				System.out.println("Failed:Production text POE10 Screen");
				WebTestCase.getTest().log(LogStatus.FAIL, "Not Verified - POE10 Production Text Not displayed "+ common.captureScreenshot(ScreenshotRequire));
			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();

	}

	public void validateProdRecordTotalValue(String rcdvalue, String ScreenshotRequire){
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			Common.isElementDisplayed(driver, startLegend, 100);
			common.waitTillElementDisappears(By.xpath(toolbox), 800);
			Assert.assertTrue(recValue.isDisplayed(),"recValue failed");
			if(recValue.getText().contains(rcdvalue))
			{
				System.out.println("Passs:Production total recordValue:"+recValue.getText());
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Same total Number is displayed "+ common.captureScreenshot(ScreenshotRequire));
			}
			else 
			{
				System.out.println("Failed:Production total recordValue: "+recValue.getText());
				WebTestCase.getTest().log(LogStatus.FAIL, "failed Verified - Same total Number Varies "+ common.captureScreenshot(ScreenshotRequire));
			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	public void validateProductionScreen(String Area,String shift,String produced,String lineproduced,String remaining,String wcnc, String ScreenshotRequire){
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			Common.isElementDisplayed(driver, startLegend, 100);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Assert.assertTrue(orderExecData.isDisplayed(),"Production data validate failed");
			List<WebElement> verifydata =driver.findElements(By.xpath("//*[@id='ctl03_ClientSFContainer']//..//..//table[@class='Form']"));
			for(int i=0;i<verifydata.size();i++)
			{
				String datas=verifydata.get(i).getText();
				System.out.println("valid::"+datas);

				//if(datas.contains(Area)&&datas.contains(shift)&&datas.contains(produced)&&datas.contains(lineproduced)&&datas.contains(remaining)&&datas.contains(wcnc))
				if(datas.contains(Area)&&datas.contains(shift)||datas.contains(produced)||datas.contains(lineproduced)||datas.contains(remaining)||datas.contains(wcnc))
				{
					System.out.println("Passs:Validated Production Data");
					WebTestCase.getTest().log(LogStatus.PASS, "Verified -Production Data "+ common.captureScreenshot(ScreenshotRequire));
					break;
				}
				else 
				{
					System.out.println("Failed:Production data");
					WebTestCase.getTest().log(LogStatus.FAIL, "Failed -Production data Varies  "+ common.captureScreenshot(ScreenshotRequire));
				}
			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	public void validateMouseOverIcons(String stop,String help,String nonconf,String machdownstatus, String ScreenshotRequire){
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			Common.isElementDisplayed(driver, startLegend, 100);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Assert.assertTrue(orderExecData.isDisplayed(),"Order execution icons screen failed");
			List<WebElement> verifydata =driver.findElements(By.xpath("//*[contains(@id,'ELX_SelectAction')]"));
			for(int i=0;i<verifydata.size();i++)
			{
				String datas=verifydata.get(i).getText();
				System.out.println("valid::"+datas);

				//if(datas.contains(Area)&&datas.contains(shift)&&datas.contains(produced)&&datas.contains(lineproduced)&&datas.contains(remaining)&&datas.contains(wcnc))
				if(datas.contains(stop)&&datas.contains(help)||datas.contains(nonconf)||datas.contains(machdownstatus))
				{
					System.out.println("Passs:Validated Icons textName");
					WebTestCase.getTest().log(LogStatus.PASS, "Verified -Icons text "+ common.captureScreenshot(ScreenshotRequire));
					break;
				}
				else 
				{
					System.out.println("Failed:Production data");
					WebTestCase.getTest().log(LogStatus.FAIL, "Failed -Not Validate icons  "+ common.captureScreenshot(ScreenshotRequire));
				}
			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	//Clicked Action Stop/Help/NonConf/MachineStatusDown
	public void clickOnStopIcons(String ScreenshotRequire)
	{
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			Common.isElementDisplayed(driver, mousehoverIcons, 100);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver,stopIconst, IConstants.HIGH_WAIT_TIME);

			String stopCount=stopIco.getText();
			System.out.println("Count value shown:"+stopCount);
			if(stopCount.trim().equals("-")||Integer.parseInt(stopCount)==0) 
			{
				common.clickOnObject(stopIconst, "stopIconst");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Assert.assertFalse(common.isElementVisible(By.xpath("//*[text()='DFP list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")));
				System.out.println("Stop not clicked");
				WebTestCase.getTest().log(LogStatus.FAIL, "Failed -Stop not clicked  "+ common.captureScreenshot(ScreenshotRequire));

			}
			else {			
				common.clickOnObject(stopIconst, "stopIconst");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				System.out.println("Stop clicked");
				Assert.assertTrue(common.isElementVisible(By.xpath("//*[text()='DFP list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")));
				common.clickOnObject(stopWindowClose, "stopWindowClose");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				//Assert.assertFalse(common.isElementVisible(By.xpath("//*[text()='DFP list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")));
				System.out.println("Pass: closed Modal window");
				Thread.sleep(4000);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified Stop clicked and close button "+ common.captureScreenshot(ScreenshotRequire));

			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	public void clickOnHelpIcons(String ScreenshotRequire)
	{
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			Common.isElementDisplayed(driver, mousehoverIcons, 100);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(By.xpath("//*[@class='ELX_Button_hexagon']"), IConstants.LOW_WAIT_TIME);

			String helpCount=helpIco.getText();
			System.out.println("Count value shown:"+helpCount);
			if(helpCount.trim().equals("-")||Integer.parseInt(helpCount)==0) 
			{
				common.clickOnObject(helpIconst, "helpIconst");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				System.out.println("Help not clicked");	
				Assert.assertFalse(common.isElementVisible(By.xpath("//*[text()='Help list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")));
				WebTestCase.getTest().log(LogStatus.FAIL, "Failed -Help not clicked  "+ common.captureScreenshot(ScreenshotRequire));

			}
			else {
				common.clickOnObject(helpIconst, "helpIconst");  
				System.out.println("Help clicked");
				Assert.assertTrue(common.isElementVisible(By.xpath("//*[text()='Help list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")));
				common.clickOnObject(helpWindowClose, "helpWindowClose");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				//Assert.assertFalse(common.isElementVisible(By.xpath("//*[text()='Help list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")));
				System.out.println("Pass: closed Modal window");
				Thread.sleep(4000);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified Help clicked and Close button "+ common.captureScreenshot(ScreenshotRequire));
			}

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	public void clickOnNonConfIcons(String ScreenshotRequire)
	{
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			Common.isElementDisplayed(driver, mousehoverIcons, 100);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(By.xpath("//*[@class='ELX_Button_hexagon']"), IConstants.LOW_WAIT_TIME);

			String ncCount=ncIco.getText();
			System.out.println(ncCount);
			if(ncCount.trim().equals("-")||Integer.parseInt(ncCount)==0)
			{
				common.clickOnObject(ncIconst, "ncIconst");
				common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
				Assert.assertFalse((closeWindow).isDisplayed());
				System.out.println("NC not clicked");
				WebTestCase.getTest().log(LogStatus.FAIL, "Failed -NonConf not clicked  "+ common.captureScreenshot(ScreenshotRequire));
			}
			else {
				common.clickOnObject(ncIconst, "ncIconst");  
				System.out.println("NC clicked");	
				Assert.assertTrue(common.isElementVisible(By.xpath("//*[text()='NonConformity list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")));
				nonConfWindowClose.click();
				//Assert.assertFalse(common.isElementVisible(By.xpath("//*[text()='NonConformity list:']//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")));
				System.out.println("Pass: closed Modal window");
				Thread.sleep(4000);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified NonConfIcons clicked and close button "+ common.captureScreenshot(ScreenshotRequire));

			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	public void machineDwnStatusIcons(String ScreenshotRequire)
	{
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			Common.isElementDisplayed(driver, mousehoverIcons, 100);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(By.xpath("//*[@class='ELX_Button_hexagon']"), IConstants.LOW_WAIT_TIME);
			String mcCount=mcstatusIco.getText();
			System.out.println(mcCount);
			mcdownIconst.click();
			System.out.println("Mc clicked");		
			Assert.assertTrue(common.isElementVisible(By.xpath("//*[text()='Machine Status']//..//following-sibling::span[contains(@class,'fa fa-close ELX_window-close')]")));
			macdownstatusClose.click();
			System.out.println("Pass: closed Modal window");
			Thread.sleep(4000);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified Machine status icon clicked and close button "+ common.captureScreenshot(ScreenshotRequire));
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	/**
	 * Method To validate POE Screen
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	public void validatePOEScreen(String prodtext, String ScreenshotRequire){
		try
		{
			System.out.println("inside validatePOEScreen function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			Common.isElementDisplayed(driver, header, IConstants.MEDIUM_WAIT_TIME);	
			Thread.sleep(5000);
			Assert.assertTrue(header.getText().contains(prodtext),"Header is not appearing correctly in order execution page");

			WebTestCase.getTest().log(LogStatus.PASS, "Verified - POE Production Text displayed:-- "+header.getText()+ common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:"+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();

	}
	/**
	 * Method To validate POE Screen
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	public void validatePOEScreenAreaName(String areaName, String ScreenshotRequire){
		try
		{	System.out.println("validatePOEScreenAreaName function: "+ areaName);
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
		Common.isElementDisplayed(driver, areaHeaderText, IConstants.MEDIUM_WAIT_TIME);	
		Thread.sleep(5000);
		System.out.println("area name: "+areaHeaderText.getText().trim());
		System.out.println("area name global file: "+areaName);
		Assert.assertTrue(areaHeaderText.getText().trim().contains(areaName.trim()),"Area name is not appearing correctly in order execution page");
		//Assert.assertEquals(areaHeaderText.getText().trim(),areaName.trim(),"Area name is not appearing correctly in order execution page");

		WebTestCase.getTest().log(LogStatus.PASS, "Verified - POE area name displayed:-- "+areaHeaderText.getText()+ common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:"+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();

	}
	/**
	 * Method To vaidate Help Icon Count
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String vaidateHelpIconCount(String ScreenshotRequire)
	{
		String helpCount=null;

		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			Common.isElementDisplayed(driver, mousehoverIcons, IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver,helpIconst, IConstants.HIGH_WAIT_TIME);
			Thread.sleep(5000);
			helpCount=helpIco.getText();	
			System.out.println("Count value shown:"+helpCount);
			if(helpCount.trim().equals("-")||Integer.parseInt(helpCount)==0) 
			{
				System.out.println("Help count is not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "count of help is "+helpCount+ common.captureScreenshot(ScreenshotRequire));

			}
			else {			
				WebTestCase.getTest().log(LogStatus.PASS, "current help count:"+helpCount+ common.captureScreenshot(ScreenshotRequire));

			}}catch(java.lang.AssertionError e){
				System.out.println("Got Assertion Error "+e);
				WebTestCase.getTest().log(LogStatus.FAIL,
						e.getMessage() + common.captureScreenshot("true"));
				Assert.fail(e.getMessage());
			}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return helpCount;
	}

	public String vaidateNonConformityIconCount(String ScreenshotRequire)
	{
		String NCCount=null;

		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			Common.isElementDisplayed(driver, mousehoverIcons, IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver,ncIconst, IConstants.HIGH_WAIT_TIME);
			Thread.sleep(8000);
			NCCount=ncIco.getText();	
			System.out.println("Count value shown:"+NCCount);
			if(NCCount.trim().equals("-")||Integer.parseInt(NCCount)==0) 
			{
				System.out.println("NC count is not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "count of NC is "+NCCount+ common.captureScreenshot("true"));
				NCCount="0";

			}
			else {			
				WebTestCase.getTest().log(LogStatus.PASS, "current NC count:"+NCCount+ common.captureScreenshot(ScreenshotRequire));
			}
		}catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return NCCount;
	}
	public String vaidateStopIconCount(String ScreenshotRequire)
	{
		String stopCount=null;

		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, mousehoverIcons, IConstants.SYS_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver,stopIconst, IConstants.HIGH_WAIT_TIME);
			Thread.sleep(5000);
			stopCount=stopIco.getText();	
			System.out.println("Stop count value shown:"+stopCount);
			if(stopCount.trim().equals("-")||Integer.parseInt(stopCount)==0) 
			{
				System.out.println("Stop count is not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "count of stop is "+stopCount+ common.captureScreenshot(ScreenshotRequire));

			}
			else {			
				WebTestCase.getTest().log(LogStatus.PASS, "current stop count:"+stopCount+ common.captureScreenshot("true"));

			}}catch(java.lang.AssertionError e){
				System.out.println("Got Assertion Error: "+e);
				WebTestCase.getTest().log(LogStatus.FAIL,
						e.getMessage() + common.captureScreenshot("true"));
				Assert.fail(e.getMessage());
			}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return stopCount;
	}


	public String ValidateStopIcon(String option1, String option2, String option3, String status, String ScreenshotRequire)
	{
		String stopCount=null;
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, mousehoverIcons, 100);			
			Common.isElementDisplayed(driver,stopIconst, IConstants.HIGH_WAIT_TIME);

			stopCount=stopIco.getText();	
			System.out.println("Count value shown:"+stopCount);
			if(stopCount.trim().equals("-")||Integer.parseInt(stopCount)==0) 
			{
				common.clickOnObject(stopIconst, "stopIconst");
				Assert.assertFalse(stopWindowClose.isDisplayed());
				System.out.println("Stop not clicked");
				WebTestCase.getTest().log(LogStatus.FAIL, "Failed -Stop not clicked  "+ common.captureScreenshot(ScreenshotRequire));

			}
			else {			
				common.clickOnObject(stopIconst, "stopIconst");  
				System.out.println("Stop clicked");
				Thread.sleep(4000);
				Assert.assertTrue(stopWindowClose.isDisplayed());
				stopWindowClose.click();
				System.out.println("Pass: closed Modal window");
				Thread.sleep(4000);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified close button clicked"+ common.captureScreenshot(ScreenshotRequire));

			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return stopCount;
	}
	public void clickAndValidateOnStopIconAndClick(String [] NCReason, String status, String ScreenshotRequire)
	{
		String stopCount=null;

		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			Common.isElementDisplayed(driver, mousehoverIcons, 100);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver,stopIconst, IConstants.HIGH_WAIT_TIME);

			stopCount=stopIco.getText();	
			System.out.println("Count value shown:"+stopCount);
			if(stopCount.trim().equals("-")||Integer.parseInt(stopCount)==0) 
			{
				common.clickOnObject(stopIconst, "stopIconst");
				Assert.assertFalse(stopWindowClose.isDisplayed());
				System.out.println("Stop not clicked");
				WebTestCase.getTest().log(LogStatus.PASS, "Failed -Stop not clicked  "+ common.captureScreenshot("true"));
			}
			else {			
				common.clickOnObject(stopIconst, "stopIconst");  
				System.out.println("Stop clicked");
				common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
				Thread.sleep(2000);
				Assert.assertTrue(stopWindowClose.isDisplayed());
				int flag=0;
				int counter=0;
				for(int i=0;i<reasonCodeList.size();i++) {
					if((reasonCodeList.get(i).getAttribute("innerHTML").toLowerCase().contains(NCReason[NCReason.length-1].toLowerCase()))) {
						System.out.println(reasonCodeList.get(i).getAttribute("innerHTML") + " is present");
						WebTestCase.getTest().log(LogStatus.INFO, "reason code: "+reasonCodeList.get(i).getAttribute("innerHTML") + " is present" +common.captureScreenshot("true"));
						flag=1;
						counter=i;
						break;
					}
				}
				if(flag==1) {
					//WebTestCase.getTest().log(LogStatus.INFO, "reason code: "+reasonCodeList.get(counter).getAttribute("innerHTML") + " is present" +common.captureScreenshot(ScreenshotRequire));
					softAssert.assertTrue(criticalityList.get(counter).getAttribute("innerHTML").contains(status), " Correct Criticality is not appearing");
					//WebTestCase.getTest().log(LogStatus.INFO, "Criticality of reason is showing :"+criticalityList.get(counter).getAttribute("innerHTML") + " for reason code " +reasonCodeList.get(counter).getAttribute("innerHTML") +common.captureScreenshot(ScreenshotRequire));

				}else {
					softAssert.assertTrue(NCReason[NCReason.length-1].toLowerCase().contains(reasonCodeList.get(counter).getText().toLowerCase()),"Reason code text is not displaying correctly") ;
				}
				new Actions(driver);
				Thread.sleep(4000);
				reasonCodeList.get(counter).click();	
				//action.doubleClick(reasonCodeList.get(counter)).perform();
				Thread.sleep(4000);	
				WebTestCase.getTest().log(LogStatus.PASS, "Verified stop reason code clicked");

			}}catch(java.lang.AssertionError e){
				System.out.println("Got Assertion Error: "+e);
				WebTestCase.getTest().log(LogStatus.FAIL,
						e.getMessage() + common.captureScreenshot("true"));
				Assert.fail(e.getMessage());
			}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To click And Validate On Help Icon And Close
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String clickAndValidateOnHelpIconAndClose(String[] NCReason, String status, String ScreenshotRequire)
	{System.out.println("inside clickAndValidateOnHelpIconAndClose function");
	String helpCount=null;
	try
	{
		common.switchToFrame(By.xpath(iframepage), IConstants.SYS_WAIT_TIME);
		Common.isElementDisplayed(driver, mousehoverIcons, IConstants.SYS_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
		Common.isElementDisplayed(driver,helpIconst, IConstants.HIGH_WAIT_TIME);
		Thread.sleep(5000);
		helpCount=helpIco.getText();	
		System.out.println("Count value shown:"+helpCount);
		if(helpCount.trim().equals("-")||Integer.parseInt(helpCount)==0) 
		{
			common.clickOnObject(helpIconst, "helpIconst");
			Assert.assertFalse(helpWindowClose.isDisplayed());
			System.out.println("Help not clicked");
			WebTestCase.getTest().log(LogStatus.FAIL, "Failed - Help not clicked  "+ common.captureScreenshot("true"));

		}
		else {			
			common.clickOnObject(helpIconst, "helpIconst");  
			System.out.println("Help Button clicked");
			Assert.assertTrue(helpWindowClose.isDisplayed());
			int flag=0;
			int counter=0;
			for(int i=0;i<helpReasonCodeList.size();i++) {
				if((helpReasonCodeList.get(i).getAttribute("innerHTML").toLowerCase().contains(NCReason[NCReason.length-1].toLowerCase()))) {System.out.println(helpReasonCodeList.get(i).getAttribute("innerHTML") + " is present");
				WebTestCase.getTest().log(LogStatus.INFO, helpReasonCodeList.get(i).getAttribute("innerHTML")+ "is present" +common.captureScreenshot("true"));
				flag=1;
				counter=i;
				break;
				}
			}
			if(flag!=0) {
				//WebTestCase.getTest().log(LogStatus.INFO, helpReasonCodeList.get(counter).getAttribute("innerHTML") + " is present" +common.captureScreenshot(ScreenshotRequire));
				Assert.assertTrue(criticalityHelpList.get(counter).getAttribute("innerHTML").contains(status), " Correct Criticality is not appearing");
				WebTestCase.getTest().log(LogStatus.INFO, "Criticality of reason is showing :--"+criticalityHelpList.get(counter).getAttribute("innerHTML") + " -- for reason code " +helpReasonCodeList.get(counter).getAttribute("innerHTML") +common.captureScreenshot(ScreenshotRequire));

			}else {
				Assert.assertEquals(helpReasonCodeList.get(counter).getText().toLowerCase(),NCReason[NCReason.length-1].toLowerCase(),"Reason code text is not displaying correctly") ;
			}
			System.out.println("Latest reason code details:"+helpReasonCodeList.get(counter).getAttribute("innerHTML"));

			common.clickOnObject(helpWindowClose, "helpWindowClose");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			System.out.println("Pass: Closed Modal window");
			Thread.sleep(4000);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified close button clicked"+ common.captureScreenshot(ScreenshotRequire));

		}
	}
	catch(java.lang.AssertionError e){
		System.out.println("Got Assertion Error:" +e);
		WebTestCase.getTest().log(LogStatus.FAIL,
				e.getMessage() + common.captureScreenshot("true"));
		Assert.fail(e.getMessage());
	}
	catch(Exception e1){

		WebTestCase.getTest().log(LogStatus.FAIL,
				e1.getMessage() + common.captureScreenshot("true"));
		Assert.fail(e1.getMessage());
	}
	driver.switchTo().defaultContent();
	return helpCount;
	}

	public String clickAndValidateOnStopIconAndClose(String [] NCReason, String status, String ScreenshotRequire)
	{
		String stopCount=null;
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, mousehoverIcons, IConstants.SYS_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver,stopIconst, IConstants.HIGH_WAIT_TIME);
			Thread.sleep(5000);
			stopCount=stopIco.getText();	
			System.out.println("Count value shown:"+stopCount);
			if(stopCount.trim().equals("-")||Integer.parseInt(stopCount)==0) 
			{
				common.clickOnObject(stopIconst, "stopIconst");
				common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
				Assert.assertFalse(stopWindowClose.isDisplayed());
				System.out.println("Stop not clicked");
				WebTestCase.getTest().log(LogStatus.PASS, "Failed -Stop not clicked  "+ common.captureScreenshot(ScreenshotRequire));
			}
			else {			
				common.clickOnObject(stopIconst, "stopIconst");
				common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
				System.out.println("Stop clicked"); Thread.sleep(3000);
				Assert.assertTrue(stopWindowClose.isDisplayed());
				int flag=0;
				int counter=0;
				for(int i=0;i<reasonCodeList.size();i++) {
					if((reasonCodeList.get(i).getAttribute("innerHTML").toLowerCase().contains(NCReason[(NCReason.length)-1].toLowerCase()))) {
						System.out.println(reasonCodeList.get(i).getAttribute("innerHTML") + " is present");
						WebTestCase.getTest().log(LogStatus.INFO, "reason code: "+reasonCodeList.get(i).getAttribute("innerHTML")+ "is present");
						flag=1;
						counter=i;
						break;
					}
				}
				if(flag>0) {
					softAssert.assertTrue(criticalityList.get(counter).getAttribute("innerHTML").contains(status), " Correct Criticality is not appearing");
					WebTestCase.getTest().log(LogStatus.INFO, "Criticality is showing :--"+criticalityList.get(counter).getAttribute("innerHTML") + " -- for reason code " +reasonCodeList.get(counter).getAttribute("innerHTML"));

				}else {
					softAssert.assertTrue((NCReason[NCReason.length-1]).toLowerCase().contains(reasonCodeList.get(counter).getText().toLowerCase()),"Reason code text is not displaying correctly") ;
					WebTestCase.getTest().log(LogStatus.INFO, "Reason code text is not displaying correctly" +common.captureScreenshot(ScreenshotRequire));

				}
				//reasonCodeList.get(counter).click();


				common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
				common.clickOnObject(stopWindowClose, "stopWindowClose");
				common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
				System.out.println("Pass: Closed Modal window");
				Thread.sleep(4000);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified close button clicked");

			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		return stopCount;
	}
	/**
	 * Method To click And Validate On Help Icon And Click
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	public void clickAndValidateOnNCIconAndClick(String [] NCReason, String status,String ScreenshotRequire)
	{	
		System.out.println("inside clickAndValidateOnNCIconAndClick function::  "+NCReason+"  >> "+status);
		String NCCount=null;
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, mousehoverIcons, IConstants.SYS_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver,ncIconst, IConstants.HIGH_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "Count value shown:"+NCCount);
			NCCount=ncIco.getText();	
			System.out.println("Count value shown:"+NCCount);
			if(NCCount.trim().equals("-")||Integer.parseInt(NCCount)==0) 
			{
				common.clickOnObject(ncIconst, "ncIconst");
				common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
				Assert.assertFalse(nonConfWindowClose.isDisplayed());
				System.out.println("NC not clicked");
				WebTestCase.getTest().log(LogStatus.PASS, "Failed - NC not available  "+ common.captureScreenshot("true"));

			}
			else {			
				common.clickOnObject(ncIconst, "ncIconst");
				common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
				System.out.println("NC clicked");
				Thread.sleep(4000);
				Assert.assertTrue(nonConfWindowClose.isDisplayed());
				int counter=0;
				int i;
				for(i=0;i<NCReasonCodeList.size();i++) {
					if((NCReasonCodeList.get(i).getAttribute("innerText").toLowerCase().contains(NCReason[(NCReason.length)-1].toLowerCase()))) {
						System.out.println(NCReasonCodeList.get(i).getAttribute("innerHTML") + " is present");
						WebTestCase.getTest().log(LogStatus.INFO, NCReasonCodeList.get(i).getAttribute("innerText")+ " is present");
						counter=i;
						break;

					}
				}
				/*if(flag!=0) {
				WebTestCase.getTest().log(LogStatus.INFO, NCReasonCodeList.get(counter).getAttribute("innerText") + " is present" +common.captureScreenshot(ScreenshotRequire));
				//Assert.assertTrue(criticalityNCList.get(counter).getAttribute("innerHTML").contains(status), " Correct Criticality is not appearing");
				//WebTestCase.getTest().log(LogStatus.INFO, "Criticality of reason is showing :---"+criticalityNCList.get(counter).getAttribute("innerHTML") + " -- for reason code " +NCReasonCodeList.get(counter).getAttribute("innerHTML") +common.captureScreenshot(ScreenshotRequire));

			}else {
				Assert.assertEquals(NCReasonCodeList.get(counter).getText().toLowerCase(),option2.toLowerCase(),"Reason code text is not displaying correctly") ;
			}*/
				common.highLighterMethod(driver,NCReasonCodeList.get(counter));
				JavascriptExecutor js = (JavascriptExecutor)driver; 
				js.executeScript("arguments[0].click();", NCReasonCodeList.get(counter));
				//common.clickOnObject(NCReasonCodeList.get(counter),NCReasonCodeList.get(counter).getText());
				Thread.sleep(5000);
				//action.doubleClick(NCReasonCodeList.get(counter)).perform();
				//Thread.sleep(4000);	
				//	System.out.println("Latest reason code details:"+helpReasonCodeList.get(counter).getAttribute("innerHTML"));
				WebTestCase.getTest().log(LogStatus.PASS, "Verified NC reason code clicked");

			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
		//return helpCount;
	}


	/**
	 * Method To click And Validate On NC Icon And Close
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String clickAndValidateOnNCIconAndClose(String [] NCReason, String status, String ScreenshotRequire)
	{System.out.println("inside clickAndValidateOnNCIconAndClose function");
	String NCCount=null;

	try
	{
		common.switchToFrame(By.xpath(iframepage), 120);
		Common.isElementDisplayed(driver, mousehoverIcons, 100);
		common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
		Common.isElementDisplayed(driver,ncIconst, IConstants.HIGH_WAIT_TIME);

		NCCount=ncIco.getText();	
		System.out.println("Count value shown:"+NCCount);
		if(NCCount.trim().equals("-")||Integer.parseInt(NCCount)==0) 
		{
			common.clickOnObject(ncIconst, "ncIconst");
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Assert.assertFalse(nonConfWindowClose.isDisplayed());
			System.out.println("NC not clicked");
			WebTestCase.getTest().log(LogStatus.PASS, "Failed -NC not clicked  "+ common.captureScreenshot("true"));

		}
		else {			
			common.clickOnObject(ncIconst, "ncIconst"); 
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			Thread.sleep(4000);
			System.out.println("NC clicked");
			WebTestCase.getTest().log(LogStatus.INFO, "NC clicked");

			Assert.assertTrue(nonConfWindowClose.isDisplayed());
			int counter=0;
			for(int i=0;i<NCReasonCodeList.size();i++) {
				if((NCReasonCodeList.get(i).getAttribute("innerHTML").toLowerCase().contains(NCReason[(NCReason.length)-1].toLowerCase()))) {
					WebTestCase.getTest().log(LogStatus.INFO, NCReasonCodeList.get(i).getAttribute("innerText")+ " is present");
					System.out.println(NCReasonCodeList.get(i).getAttribute("innerText") + " is present");
					counter=i;
					break;

				}
			}
			/*if(flag!=0) {
				WebTestCase.getTest().log(LogStatus.INFO, NCReasonCodeList.get(counter).getAttribute("innerText") + " is present" +common.captureScreenshot(ScreenshotRequire));
				//Assert.assertTrue(criticalityNCList.get(counter).getAttribute("innerHTML").contains(status), " Correct Criticality is not appearing");
				//WebTestCase.getTest().log(LogStatus.INFO, "Criticality of reason is showing :---"+criticalityNCList.get(counter).getAttribute("innerHTML") + " -- for reason code " +NCReasonCodeList.get(counter).getAttribute("innerHTML") +common.captureScreenshot(ScreenshotRequire));

			}else {
				Assert.assertEquals(NCReasonCodeList.get(counter).getText().toLowerCase(),option2.toLowerCase(),"Reason code text is not displaying correctly") ;
			}*/


			/*System.out.println("Latest reason code details:"+NCReasonCodeList.get(counter).getAttribute("innerText"));
			WebTestCase.getTest().log(LogStatus.INFO, NCReasonCodeList.get(counter).getAttribute("innerText")+ " is present");*/
			
			Common.isElementDisplayed(driver, nonConfWindowClose, IConstants.SYS_WAIT_TIME);
			common.clickOnObject(nonConfWindowClose, "nonConfWindowClose");
			System.out.println("Pass: Closed Modal window");
			Thread.sleep(4000);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified close button clicked");

		}
	}
	catch(java.lang.AssertionError e){
		System.out.println("Got Assertion Error:" +e);
		WebTestCase.getTest().log(LogStatus.FAIL,
				e.getMessage() + common.captureScreenshot("true"));
		Assert.fail(e.getMessage());
	}
	catch(Exception e1){

		WebTestCase.getTest().log(LogStatus.FAIL,
				e1.getMessage() + common.captureScreenshot("true"));
		Assert.fail(e1.getMessage());
	}
	driver.switchTo().defaultContent();
	return NCCount;
	}


	/**
	 * Method To click And Validate On Help Icon And Click
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	public void clickAndValidateOnHelpIconAndClick(String[] NCReason, String status, String ScreenshotRequire)
	{	System.out.println("inside clickAndValidateOnHelpIconAndClick function:: "+NCReason.toString()+">>>"+status);
	String helpCount=null;
	try
	{
		common.switchToFrame(By.xpath(iframepage), 120);
		Common.isElementDisplayed(driver, mousehoverIcons, 100);
		common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
		Common.isElementDisplayed(driver,helpIconst, IConstants.HIGH_WAIT_TIME);

		helpCount=helpIco.getText();	
		System.out.println("Count value shown:"+helpCount);
		if(helpCount.trim().equals("-")||Integer.parseInt(helpCount)==0) 
		{
			common.clickOnObject(helpIconst, "helpIconst");
			Assert.assertFalse(helpWindowClose.isDisplayed());
			System.out.println("Help not clicked");
			WebTestCase.getTest().log(LogStatus.FAIL, "Failed - Help not clicked  "+ common.captureScreenshot(ScreenshotRequire));

		}
		else {			
			common.clickOnObject(helpIconst, "helpIconst");  
			System.out.println("Help clicked");
			Assert.assertTrue(helpWindowClose.isDisplayed());
			int flag=0;
			int counter=0;
			int i;
			for(i=0;i<helpReasonCodeList.size();i++) {
				if((helpReasonCodeList.get(i).getAttribute("innerHTML").toLowerCase().contains(NCReason[NCReason.length-1].toLowerCase()))) {System.out.println(helpReasonCodeList.get(i).getAttribute("innerHTML") + " is present");
				WebTestCase.getTest().log(LogStatus.INFO, helpReasonCodeList.get(i).getAttribute("innerHTML")+ "is present" +common.captureScreenshot(ScreenshotRequire));
				flag=1;
				counter=i;
				break;
				}
			}
			if(flag!=0) {
				WebTestCase.getTest().log(LogStatus.INFO, helpReasonCodeList.get(counter).getAttribute("innerHTML") + " is present" +common.captureScreenshot(ScreenshotRequire));

			}else {
				Assert.assertEquals(helpReasonCodeList.get(counter).getText().toLowerCase(),NCReason[NCReason.length-1].toLowerCase(),"Reason code text is not displaying correctly ") ;
			}
			common.clickOnObject(helpReasonCodeList.get(counter),helpReasonCodeList.get(counter).getText());
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Thread.sleep(4000);	
			WebTestCase.getTest().log(LogStatus.PASS, "Verified help reason code clicked"+ common.captureScreenshot(ScreenshotRequire));

		}
	}
	catch(java.lang.AssertionError e){
		System.out.println("Got Assertion Error: "+e);
		WebTestCase.getTest().log(LogStatus.FAIL,
				e.getMessage() + common.captureScreenshot("true"));
		Assert.fail(e.getMessage());
	}
	catch(Exception e1){

		WebTestCase.getTest().log(LogStatus.FAIL,
				e1.getMessage() + common.captureScreenshot("true"));
		Assert.fail(e1.getMessage());
	}
	driver.switchTo().defaultContent();
	}



	@SuppressWarnings("static-access")
	public void validateActionButtons(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateActionButtons function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, mousehoverIcons, 100);


			for(int i=0;i<ELXSelectActionList.size();i++) {				
				if((ELXSelectActionList.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("Action list:"+ELXSelectActionList.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "Action list Button"+(i+1)+"--"+ELXSelectActionList.get(i).getAttribute("innerHTML"));
				}
			}
			WebTestCase.getTest().log(LogStatus.INFO, "Action list validated successfully on POE screen"+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	@SuppressWarnings("static-access")
	public void validateAreaDetails(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateAreaDetails function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, ELXPrimaryButtonList, 100);


			for(int i=0;i<ELXButtonList.size();i++) {				
				if((ELXButtonList.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("Primary Button Enabled list:"+ELXButtonList.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "Primary Button Enabled Button"+(i+1)+"--"+ELXButtonList.get(i).getAttribute("innerHTML"));
				}

			}

			WebTestCase.getTest().log(LogStatus.INFO, "Primary Button list validated successfully on POE screen"+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To click return Icon
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void clickReturnIcon() throws InterruptedException{
		System.out.println("inside clickReturnIcon function");
		common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver,returnIcon, IConstants.MEDIUM_WAIT_TIME);
		Assert.assertTrue(returnIcon.isDisplayed(), "Home Icon not displayed");			
		//WebTestCase.getTest().log(LogStatus.PASS, "Verified - Home Icon present in Operation page"+ common.captureScreenshot(ScreenshotRequire));
		common.clickOnObject(returnIcon,returnIcon.getText());
		common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
		System.out.println("returnIcon clicked");
		//WebTestCase.getTest().log(LogStatus.PASS, "Verified - returnIcon page is appearing"+ common.captureScreenshot(ScreenshotRequire));
		driver.switchTo().defaultContent();



	}

	@SuppressWarnings("static-access")
	public void validatePrimaryButtons(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateActionButtons function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, ELXPrimaryButtonList, 100);
			for(int i=0;i<ELXButtonList.size();i++) {	
				System.out.println("online data:"+ ELXButtonList.get(i).getAttribute("innerHTML"));
				System.out.println("excel data:"+ hmAction.get(i+1).toLowerCase());
				if((ELXButtonList.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("Primary Button Enabled list:"+ELXButtonList.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "Primary Button Enabled Button"+(i+1)+"--"+ELXButtonList.get(i).getAttribute("innerHTML"));
				}

			}

			WebTestCase.getTest().log(LogStatus.INFO, "Primary Button list validated successfully on POE screen"+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	@SuppressWarnings("static-access")
	public void validateStatusFields(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateActionButtons function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			List <WebElement> list	=	common.getallvaluesfromSelectbox(statusDropDown, "SelectBox");
			System.out.println(list.size());
			for(int i=0;i<list.size();i++) {
				if((list.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("Action list:"+list.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.PASS, "Status Field Contains"+(i+1)+"--"+list.get(i).getAttribute("innerHTML").toLowerCase()+ " -- " + " Data in Global Sheet:- " +hmAction.get(i+1).toLowerCase());;
				}
				else{
					WebTestCase.getTest().log(LogStatus.FAIL, "Status Field Contains Expected "+" -- "+list.get(i).getAttribute("innerHTML")+ " -- " + "  But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
				}
			}
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	@SuppressWarnings("static-access")
	public void validate17Icons(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateActionButtons function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, ELX17iconRow, 100);

			System.out.println(ELX17FieldList.size());
			for(int i=0;i<ELX17FieldList.size();i++) {
				//System.out.println(ELX17FieldList.get(i).getText());
				if((ELX17FieldList.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("Action list:"+ELX17FieldList.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "Action list Button"+(i+1)+"--"+ELX17FieldList.get(i).getAttribute("innerHTML"));
				}

			}

			WebTestCase.getTest().log(LogStatus.INFO, "Action list validated successfully on POE screen"+common.captureScreenshot(ScreenshotRequire));

		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	@SuppressWarnings("static-access")
	public void validateAllPOEScreenSearchHeaderValidation(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateAllPOEScreenSearchHeaderValidation function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.SYS_WAIT_TIME);
			Common.isElementDisplayed(driver, ELX17iconRow, 100);

			System.out.println(ELX17FieldList.size());
			for(int i=0;i<ELX17FieldList.size();i++) {
				if((ELX17FieldList.get(i).getAttribute("innerText").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("POE screen Table Headers:"+ELX17FieldList.get(i).getAttribute("innerText"));
					WebTestCase.getTest().log(LogStatus.INFO, "POE screen Table Headers"+"--"+ELX17FieldList.get(i).getAttribute("innerText").toLowerCase()+ " -- " + " Data in Global Sheet:- " +hmAction.get(i+1).toLowerCase());
				}else{
					WebTestCase.getTest().log(LogStatus.INFO, "POE screen Table Headers Expected "+" -- "+ELX17FieldList.get(i).getAttribute("innerText")+ " -- " + "  But Data in Global Sheet " +hmAction.get(i+1).toLowerCase());	
				}
			}
			WebTestCase.getTest().log(LogStatus.INFO, "POE screen Table Headers validated successfully on POE screen"+common.captureScreenshot(ScreenshotRequire));
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}


	@SuppressWarnings("static-access")
	public String searchOrderOnOrderCockpitPage(String oStatus,String oId, String line, String ScreenshotRequire) throws InterruptedException{

		String val=null;
		int flag=0;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPage function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(5000);
			common.setObjectValue(orderTextbox, "orderTextbox", oId);
			orderTextbox.sendKeys(Keys.RETURN);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			System.out.println("sent value on orderTextbox "+oId);
			if(oId.length()==1) {

				Select select = new Select(statusDropDown);
				select.selectByVisibleText(oStatus);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Thread.sleep(5000);
				System.out.println("sent value on statusDropDown "+oStatus);
			}

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalPOERecords=splitsvalues[1].trim();

			if(Integer.parseInt(TotalPOERecords)>0) {
				Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);

				Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));


				//List<WebElement> webList =driver.findElements(By.xpath(".//td[contains(@class, 'value')][1]//span"));
				if(webListOrder==null){
				}
				for(WebElement ele :webListOrder){
					if(ele.isDisplayed()==true){
						if(ele.getAttribute("innerHTML").contains("img"))
						{
							System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
						}
						else {
							flag=1;
							val=ele.getAttribute("innerText");
							val=val+"_"+OrderTypeRecord.getText()+"_"+ProductIdRecord.getText()+"_"+scheduledQuanList.getText()+"_"+goodQuanList.getText()+"_"+badQuanList.getText()+"_"+scheStartDate.getText()+"_"+schEndDate.getText()+"_"+actualStartDate.getText();
							driver.findElement(By.xpath(".//span/div[contains(text(),'"+ele.getAttribute("innerText")+"')]")).click();
							Actions action =new Actions(driver);
							action.doubleClick(driver.findElement(By.xpath(".//span/div[contains(text(),'"+ele.getAttribute("innerText")+"')]"))).perform();
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							Thread.sleep(5000);
							break;
						}

					}
				}
				Assert.assertEquals(flag, 1,  "Valid order list of status: "+oStatus+" : is not displaying");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));

				System.out.println("clicked on order"+ val);
			}else {
				System.out.println("TotalORDRecords are 0");
			}}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	@SuppressWarnings("static-access")
	public String searchOrderOnOrderExecutionPage(String oStatus,String oId, String line, String ScreenshotRequire) throws InterruptedException{

		String val=null;
		int flag=0;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPage function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(5000);
			orderTextbox.clear();
			common.setObjectValue(orderTextbox, "orderTextbox", oId);
			orderTextbox.sendKeys(Keys.RETURN);
			Thread.sleep(5000);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			System.out.println("sent value on orderTextbox "+oId);
			if(oId.length()==1) {

				Select select = new Select(statusDropDown);
				select.selectByVisibleText(oStatus);
				Thread.sleep(5000);

				System.out.println("sent value on statusDropDown "+oStatus);

			}
			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalPOERecords=splitsvalues[1].trim();

			if(Integer.parseInt(TotalPOERecords)>0) {
				//Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);

				Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));


				//List<WebElement> webList =driver.findElements(By.xpath(".//td[contains(@class, 'value')][1]//span"));
				if(webListOrder==null){
				}
				for(WebElement ele :webListOrder){
					if(ele.isDisplayed()==true){
						if(ele.getAttribute("innerHTML").contains("img"))
						{
							System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
						}
						else {
							flag=1;
							val=ele.getAttribute("innerText");
							val=val+"_"+OrderTypeRecord.getText()+"_"+ProductIdRecord.getText()+"_"+scheduledQuanList.getText()+"_"+goodQuanList.getText()+"_"+badQuanList.getText()+"_"+scheStartDate.getText()+"_"+schEndDate.getText()+"_"+actualStartDate.getText()+"_"+Status.getText();
							driver.findElement(By.xpath(".//span/div[contains(text(),'"+ele.getAttribute("innerText")+"')]")).click();
							/*Actions action =new Actions(driver);
					action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();*/
							Thread.sleep(5000);
							break;
						}

					}
				}
				Assert.assertEquals(flag, 1,  "Valid order list of status: "+oStatus+" : is not displaying");
				WebTestCase.getTest().log(LogStatus.PASS, val+ ": - Order number is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));

				System.out.println("clicked on order"+ val);
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "No Order Available"+ common.captureScreenshot(ScreenshotRequire));

			}
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	public void validateFooterButtons(String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		System.out.println("inside validateFooterButtons function");
		if(btnHold.isEnabled()){
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the hold button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
		}
		else{
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the hold button is disabled as expected"+ common.captureScreenshot(ScreenshotRequire));	
		}
		if(btnReport.isEnabled()){
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Report button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
		}
		else{
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Report button is disabled as expected"+ common.captureScreenshot(ScreenshotRequire));	
		}
		if(btnStart.isEnabled()){
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Start button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
		}
		else{
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Start button is disabled as expected"+ common.captureScreenshot(ScreenshotRequire));	
		}

		if(btnCreateNC.isEnabled()){
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the CreateNC button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
		}
		else{
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the CreateNC button is disabled as expected"+ common.captureScreenshot(ScreenshotRequire));	
		}

		if(btnAssign.isEnabled()){
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Assign button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
		}
		else{
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Assign button is disabled as expected"+ common.captureScreenshot(ScreenshotRequire));	
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To search Order On Order execution Page
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings({ "static-access" })
	public String searchOrderOnOrderExecutionPageWithLineAndMachineDetails(Hashtable<String, String> data,HashMap<String,String> orderDetails,String areaName,String equipmentName, String ScreenshotRequire) throws InterruptedException{

		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPageWithLineAndMachineDetails function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(4000);
			common.setObjectValue(equipmentlistInputBox, "equipmentlistInputBox", equipmentName);
			equipmentlistInputBox.sendKeys(Keys.ENTER);
			Thread.sleep(5000);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			System.out.println("selectequipmentName:"+equipmentName+" total records:"+ totalOrderRecord.getText());


			Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalPOERecords=splitsvalues[1].trim();
			System.out.println("total records in POE for: "+areaName+"---"+equipmentName+"--" + TotalPOERecords);
			System.out.println("total records in MCM:"+ orderDetails.get("TotalCount"));

			softAssert.assertEquals(TotalPOERecords,orderDetails.get("TotalCount"),"Order Records counts are not same in MCS and POE screen");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Total Order Records counts are same in MCS and POE screen"+ TotalPOERecords+"--"+orderDetails.get("TotalCount"));

			//order status verification from MCS and POE screen
			if(Integer.parseInt(TotalPOERecords)>0) {
				Select selectstatus = new Select(statusDropDown);
				selectstatus.selectByVisibleText("Started");
				Thread.sleep(5000);		
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
				String [] splitsStartedvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
				TotalPOERecords=splitsStartedvalues[1].trim();
				if(Integer.parseInt(TotalPOERecords) >0) {
					softAssert.assertEquals(ordId.getText(),orderDetails.get("startOrderIdDetails"),"Started Order ID are not same in MCS and POE screen");

				}
				System.out.println("TotalPOERecords started"+TotalPOERecords+"--mCS started"+orderDetails.get("Started"));

				softAssert.assertEquals(TotalPOERecords,orderDetails.get("Started"),"Started Order Records counts are not same in MCS and POE screen");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Started Order Records counts are same in MCS and POE screen"+ TotalPOERecords+">>>"+orderDetails.get("Started")+ common.captureScreenshot(ScreenshotRequire));

				selectstatus.selectByVisibleText("New");
				Thread.sleep(5000);		
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
				String [] splitsNewvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
				TotalPOERecords=splitsNewvalues[1].trim();
				System.out.println("TotalORDRecords new"+TotalPOERecords+">>> MCS new"+orderDetails.get("New"));

				softAssert.assertEquals(TotalPOERecords,orderDetails.get("New"),"New Order Records counts are not same in MCS and POE screen");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - New Records counts are same in MCS and POE screen"+ TotalPOERecords+">>>"+orderDetails.get("New")+ common.captureScreenshot(ScreenshotRequire));

				selectstatus.selectByVisibleText("On Hold");
				Thread.sleep(5000);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );

				Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
				String [] splitsHeldvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
				TotalPOERecords=splitsHeldvalues[1].trim();

				softAssert.assertEquals(TotalPOERecords,orderDetails.get("Held"),"Hold Order Records counts are not same in MCS and POE screen");
				System.out.println("TotalORDRecords held"+TotalPOERecords+">>> MCS held"+orderDetails.get("Held"));

				selectstatus.selectByVisibleText("Off-Hold");
				Thread.sleep(5000);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );

				Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
				String [] splitsOffHeldvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
				TotalPOERecords=splitsOffHeldvalues[1].trim();

				softAssert.assertEquals(TotalPOERecords,orderDetails.get("Off-Hold"),"Off Hold Order Records counts are not same in MCS and POE screen");
				System.out.println("TotalORDRecords held"+TotalPOERecords+">>> MCS Off-hold"+orderDetails.get("Off-Hold"));
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Off-Hold Order Records counts are same in MCS and POE screen: "+TotalPOERecords+">>>"+orderDetails.get("Off-Hold")+ common.captureScreenshot(ScreenshotRequire));
			}else {
				System.out.println("TotalORDRecords are 0");
			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	/**
	 * Method To search Order On Order execution Page
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings({ "static-access" })
	public HashMap<Integer, String> searchOrderOnOrderExecutionPageWithEquipmentDetails(Hashtable<String, String> data, String ScreenshotRequire) throws InterruptedException{
		System.out.println(" inside searchOrderOnOrderExecutionPageWithEquipmentDetails function");
		HashMap<Integer, String> map  = new HashMap<Integer, String>();
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageWithEquipmentDetails function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(4000);
			common.setObjectValue(equipmentlistInputBox, "equipmentlistInputBox", data.get("machineName"));
			equipmentlistInputBox.sendKeys(Keys.ENTER);
			Thread.sleep(5000);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			System.out.println("selectequipmentName : "+data.get("machineName"));

			Select selectstatus = new Select(statusDropDown);
			selectstatus.selectByVisibleText("Started");
			Thread.sleep(5000);				
			String [] splitsStartedvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			int TotalPOERecords=Integer.parseInt(splitsStartedvalues[1].trim());
			if(TotalPOERecords >0) {
				for(int i=0; i<displayOrderRecord.size();i++)
				{
					map.put(i+1, displayOrderRecord.get(i).getText());
				}
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Started Order is displaying in POE screen"+ common.captureScreenshot(ScreenshotRequire));
				Actions action =new Actions(driver);
				common.clickOnObject(ordId,ordId.getText());
				action.doubleClick(ordId).perform();
			}
			else {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - No Started Order is displaying in POE screen"+ common.captureScreenshot(ScreenshotRequire));

			}

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return map;			
	}

	@SuppressWarnings("static-access")
	public String validateOrderAndQtyOnOrderCockpitPage(HashMap<String, String> mCScreenOrderDetails,String ScreenshotRequire) throws InterruptedException{

		String val=null;
		try{
			System.out.println("inside validateOrderAndQtyOnOrderCockpitPage function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(5000);
			common.setObjectValue(orderTextbox, "orderTextbox", mCScreenOrderDetails.get("OrderNo"));
			orderTextbox.sendKeys(Keys.RETURN);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			Thread.sleep(5000);
			Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));
			softAssert.assertEquals(schedulquantitylist.getText().trim(),mCScreenOrderDetails.get("targetQty").trim(),"schedul quantity list is not same in MCS and POE screen");
			softAssert.assertTrue(Integer.parseInt(goodquantitylist.getText())>=Integer.parseInt(mCScreenOrderDetails.get("goodqty")),"Good quantity list is not same in MCS and POE screen");
			softAssert.assertTrue(Integer.parseInt(badquantitylist.getText())>=Integer.parseInt(mCScreenOrderDetails.get("afterReportscrapqty")),"Bad or Scrap quantity list is not same in MCS and POE screen");
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}
	@SuppressWarnings({ "static-access" })
	public boolean validateOrderAndQtyOnOrderExecutionPage(HashMap<String, String> mCScreenOrderDetails,String equipdetails, String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside validateOrderAndQtyOnOrderCockpitPage function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			common.setObjectValue(orderTextbox, "orderTextbox", String.valueOf(mCScreenOrderDetails.get("OrderNo")));
			orderTextbox.sendKeys(Keys.RETURN);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(3000);
			Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
			common.setObjectValue(equipmentlistInputBox, "equipmentlistInputBox",equipdetails);
			equipmentlistInputBox.sendKeys(Keys.ENTER);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);
			Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed for Order ID:"+mCScreenOrderDetails.get("OrderNo")+ common.captureScreenshot(ScreenshotRequire));
			Assert.assertEquals(schedulquantitylist.getText().trim(),mCScreenOrderDetails.get("targetQty").trim(),"schedule quantity list is not same in MCS and POE screen");
			Assert.assertTrue(Integer.parseInt(goodquantitylist.getText())>=Integer.parseInt(mCScreenOrderDetails.get("goodqty")),"Good quantity list is not same in MCS and POE screen");
			/*if(badquantitylist.getText()!="") {
				Assert.assertTrue(Integer.parseInt(badquantitylist.getText())>=Integer.parseInt(mCScreenOrderDetails.get("afterReportscrapqty")),"Bad or Scrap quantity list is not same in MCS and POE screen");
			}*/
			WebTestCase.getTest().log(LogStatus.PASS, "schedule quantity list in MCS and POE screen:"+mCScreenOrderDetails.get("targetQty")+"--"+schedulquantitylist.getText());
			WebTestCase.getTest().log(LogStatus.PASS, "Good quantity list in MCS and POE screen:"+mCScreenOrderDetails.get("goodqty")+"--"+goodquantitylist.getText());
			WebTestCase.getTest().log(LogStatus.PASS, "Bad quantity list in MCS and POE screen:"+mCScreenOrderDetails.get("afterReportscrapqty")+"--"+badquantitylist.getText());

			JavascriptExecutor js = (JavascriptExecutor)driver; 	
			js.executeScript("arguments[0].scrollIntoView();",actualstartdatelist);
			Thread.sleep(5000);

			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm");
			Date expectedstartdateList = sdf.parse(expectedstartdatelist.getText().trim());
			Date ExpectedStartDate = sdf.parse(mCScreenOrderDetails.get("ExpectedStartDate").trim());

			System.out.println("date1 : " + sdf.format(expectedstartdateList));
			System.out.println("date2 : " + sdf.format(ExpectedStartDate));

			if(expectedstartdateList.equals(ExpectedStartDate)) {
				WebTestCase.getTest().log(LogStatus.PASS, "expected start date in MCS and POE screen:"+mCScreenOrderDetails.get("ExpectedStartDate")+"--"+expectedstartdatelist.getText());
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "expected start date not matching in MCS and POE screen:"+mCScreenOrderDetails.get("ExpectedStartDate")+"--"+expectedstartdatelist.getText());
			}

			Date expectedenddateList = sdf.parse(expectedenddatelist.getText().trim());
			Date ExpectedCompletionDate = sdf.parse(mCScreenOrderDetails.get("ExpectedCompletionDate").trim());

			if(expectedenddateList.equals(ExpectedCompletionDate))
			{
				WebTestCase.getTest().log(LogStatus.PASS, "expected end date in MCS and POE screen:"+mCScreenOrderDetails.get("ExpectedCompletionDate")+"--"+expectedenddatelist.getText());

			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "expected end date not matching in MCS and POE screen:"+mCScreenOrderDetails.get("ExpectedCompletionDate")+"--"+expectedenddatelist.getText());

			}
			Date actualstartdateList = sdf.parse(actualstartdatelist.getText().trim());
			Date ActualStartDate = sdf.parse(mCScreenOrderDetails.get("ActualStartDate").trim());

			if(actualstartdateList.equals(ActualStartDate)) {
				WebTestCase.getTest().log(LogStatus.PASS, "actual start date in MCS and POE screen:"+mCScreenOrderDetails.get("ActualStartDate")+"--"+actualstartdatelist.getText());

			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "actual start date not matching in MCS and POE screen:"+mCScreenOrderDetails.get("ActualStartDate")+"--"+actualstartdatelist.getText());

			}
			//Assert.assertEquals(date1.(date2),"ExpectedStartDate is not same in MCS and POE screen");
			//Assert.assertEquals(expectedenddatelist.getText().trim().contains(mCScreenOrderDetails.get("ExpectedCompletionDate").trim()),"ExpectedCompletionDate is not same in MCS and POE screen");
			//Assert.assertEquals(actualstartdatelist.getText().trim().contains(mCScreenOrderDetails.get("ActualStartDate").trim()),"ActualStartDate is not same in MCS and POE screen");



		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return true;			
	}

	@SuppressWarnings({ "static-access" })
	public void validateOrderAndQtyOnOrderExecutionPageAfterBuildPallet(HashMap<String, String> mCScreenOrderDetails, String ScreenshotRequire)throws InterruptedException{
		try{
			System.out.println("inside validateOrderAndQtyOnOrderExecutionPageAfterBuildPallet function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(5000);
			common.setObjectValue(orderTextbox, "orderTextbox", String.valueOf(mCScreenOrderDetails.get("orderId")));
			orderTextbox.sendKeys(Keys.RETURN);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			Thread.sleep(5000);
			Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed for Order ID:"+mCScreenOrderDetails.get("orderId")+ common.captureScreenshot(ScreenshotRequire));
			Assert.assertEquals(schedulquantitylist.getText().trim(),mCScreenOrderDetails.get("targetqty").trim(),"schedule quantity is not same in MCS and POE screen");
			Assert.assertTrue(Integer.parseInt(goodquantitylist.getText())>=Integer.parseInt(mCScreenOrderDetails.get("completedqty")),"Good quantity  is not same in MCS and POE screen");
			Assert.assertTrue(Integer.parseInt(remainingquantitylist.getText())>=Integer.parseInt(mCScreenOrderDetails.get("palletqty")),"Remaining quantity is not same in MCS and POE screen");

			WebTestCase.getTest().log(LogStatus.PASS, "schedule quantity in MCS and POE screen:"+mCScreenOrderDetails.get("targetqty")+"--"+schedulquantitylist.getText());
			WebTestCase.getTest().log(LogStatus.PASS, "Completed/Good quantity in MCS and POE screen:"+mCScreenOrderDetails.get("completedqty")+"--"+goodquantitylist.getText());
			WebTestCase.getTest().log(LogStatus.PASS, "Remaining quantity in MCS and POE screen:"+mCScreenOrderDetails.get("palletqty")+"--"+remainingquantitylist.getText());


		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();

	}
	/**
	 * Method To validate Total Order count in order execution page
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public int validateTotalOrderDetails(String ScreenshotRequire) {
		String TotalPOERecords=null;
		try{
			System.out.println("inside validateTotalOrderDetails function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			orderTextbox.clear();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Select select1 = new Select(statusDropDown);
			select1.selectByVisibleText("[All]");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(7000);	
			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();
			System.out.println("total records in POE Screen: "+TotalPOERecords);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Total records on POE screen: "+ TotalPOERecords+ common.captureScreenshot(ScreenshotRequire));

		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return Integer.parseInt(TotalPOERecords);

	}
	/**
	 * Method To convert off-hold to start
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void searchOrderOnOrderExecutionPageAndOffHoldStart(String oStatus, String ScreenshotRequire) throws InterruptedException{
		String TotalPOERecords=null;
		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageAndStart function for "+ oStatus);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			orderTextbox.clear();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Select select = new Select(statusDropDown);
			select.selectByVisibleText(oStatus);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();
			System.out.println("total records in POE for status : "+oStatus+"--"+TotalPOERecords);
			int flag=0;
			if(Integer.parseInt(TotalPOERecords)>0) {				
				for(WebElement ele :webListOrder){
					if(ele.getAttribute("innerHTML").contains("img"))
					{
						System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));

					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed for status : <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
						val=ele.getText();
						driver.findElement(By.xpath(".//span/div[contains(text(),'"+ele.getAttribute("innerText")+"')]")).click();
						System.out.println("clicked on order :"+ val);
						if(btnStart.isEnabled()){
							common.clickOnObject(btnStart, "Start Button");
							WebTestCase.getTest().log(LogStatus.PASS, "Clicked on order to start: "+ val);
							System.out.println("clicked on start btn");
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							Thread.sleep(4000);
							Select select1 = new Select(statusDropDown);
							select1.selectByVisibleText("[All]");
							System.out.println("select -ALL- status");
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							Thread.sleep(7000);	
							common.clickOnObject(orderTextbox, "orderTextbox");
							orderTextbox.sendKeys(val);
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							orderTextbox.sendKeys(Keys.ENTER);
							Thread.sleep(5000);

							System.out.println("Search order:" +val );
							String [] splitsvalues1=common.splitValues(totalOrderRecord.getText(),"\\:");
							TotalPOERecords=splitsvalues1[1].trim();
							System.out.println("total records in POE for order"+val+"--"+TotalPOERecords);
							if(Integer.parseInt(TotalPOERecords)>0) {
								Assert.assertEquals(Status.getText(), "Started","Order status not changed to started");
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order has changed to status: <b>"+Status.getText()+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
								flag=1;
							}else {
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order not available in list"+ common.captureScreenshot(ScreenshotRequire));

							}
						}else {
							System.out.println("start button not enabled");
							WebTestCase.getTest().log(LogStatus.FAIL, "Verified - start button disabled to perform"+ common.captureScreenshot(ScreenshotRequire));

						}
						break;
					}


				}
			}else {
				System.out.println("Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));

			}	
			if(flag==0) {
				System.out.println("valid Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));

			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To convert hold to off-hold
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void searchOrderOnOrderExecutionPageAndHoldToOffHold(String oStatus, String ScreenshotRequire) throws InterruptedException{
		String TotalPOERecords=null;
		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageAndHoldToOffHold function for "+ oStatus);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			orderTextbox.clear();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Select select = new Select(statusDropDown);
			select.selectByVisibleText(oStatus);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();
			System.out.println("total records in POE for status : "+oStatus+"--"+TotalPOERecords);
			int flag=0;
			if(Integer.parseInt(TotalPOERecords)>0) {				
				for(WebElement ele :webListOrder){
					if(ele.getAttribute("innerHTML").contains("img"))
					{
						System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));

					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed for status : <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
						val=ele.getText();
						driver.findElement(By.xpath(".//span/div[contains(text(),'"+ele.getAttribute("innerText")+"')]")).click();
						System.out.println("clicked on order :"+ val);
						if(btnOffHold.isEnabled()){
							common.clickOnObject(btnOffHold, "Off-hold Button");
							WebTestCase.getTest().log(LogStatus.PASS, "Clicked on order to Off-Hold: "+ val);
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							Thread.sleep(4000);
							Select select1 = new Select(statusDropDown);
							select1.selectByVisibleText("[All]");
							System.out.println("select -ALL- status");
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							Thread.sleep(7000);	
							common.clickOnObject(orderTextbox, "orderTextbox");
							orderTextbox.sendKeys(val);
							orderTextbox.sendKeys(Keys.ENTER);
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							Thread.sleep(8000);
							String [] splitsvalues1=common.splitValues(totalOrderRecord.getText(),"\\:");
							TotalPOERecords=splitsvalues1[1].trim();
							System.out.println("total records in POE for order::"+val+" -- "+TotalPOERecords);
							if(Integer.parseInt(TotalPOERecords)>0) {
								Assert.assertEquals(Status.getText(), "Off-Hold","Order status not changed to Off-Hold");
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order has changed to status: <b>"+Status.getText()+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
								flag=1;
							}else {
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order not available in list"+ common.captureScreenshot(ScreenshotRequire));
							}
						}else {
							WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Off-Hold button disabled to perform"+ common.captureScreenshot(ScreenshotRequire));
						}
						break;
					}
				}
			}else {
				System.out.println("Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
			}	
			if(flag==0) {
				System.out.println("valid Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));

			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To search order status from dropdown and hold
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void searchOrderOnOrderExecutionPageAndHold(String oStatus, String ScreenshotRequire) throws InterruptedException{
		String TotalPOERecords=null;
		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageAndHold function for "+ oStatus);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			orderTextbox.clear();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Select select = new Select(statusDropDown);
			select.selectByVisibleText(oStatus);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();
			System.out.println("total records in POE for status : "+oStatus+"--"+TotalPOERecords);
			int flag=0;
			if(Integer.parseInt(TotalPOERecords)>0) {				
				for(WebElement ele :webListOrder){
					if(ele.getAttribute("innerHTML").contains("img"))
					{
						System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));

					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Valid Order List displayed for status : <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
						val=ele.getText();
						System.out.println("clicked on order :"+ val);
						driver.findElement(By.xpath(".//span/div[contains(text(),'"+ele.getAttribute("innerText")+"')]")).click();
						if(btnHold.isDisplayed()){
							common.clickOnObject(btnHold, "hold Button");
							WebTestCase.getTest().log(LogStatus.PASS, "selected order to hold: "+val);
							System.out.println("clicked on btnHold btn");
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							Thread.sleep(8000);

							common.isElementDisplayed(driver, holdButtonOnPopup, IConstants.HIGH_WAIT_TIME);
							Thread.sleep(4000);
							JavascriptExecutor js = (JavascriptExecutor)driver; 
							js.executeScript("arguments[0].click();", holdButtonOnPopup);
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							WebTestCase.getTest().log(LogStatus.INFO, "Verified - Clicked on Hold PopUp Button"+ common.captureScreenshot(ScreenshotRequire));
							Thread.sleep(8000);

							Select select1 = new Select(statusDropDown);
							select1.selectByVisibleText("[All]");
							System.out.println("select -ALL- status");
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							Thread.sleep(5000);	
							common.clickOnObject(orderTextbox, "orderTextbox");
							common.setObjectValue(orderTextbox, "orderTextbox", val);
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							orderTextbox.sendKeys(Keys.TAB);
							//orderTextbox.sendKeys(Keys.ENTER);
							Thread.sleep(15000);

							System.out.println("Search order:" +val );
							String [] splitsvalues1=common.splitValues(totalOrderRecord.getText(),"\\:");
							TotalPOERecords=splitsvalues1[1].trim();
							System.out.println("total records in POE for order"+val+"--"+TotalPOERecords);
							if(Integer.parseInt(TotalPOERecords)==1) {
								Assert.assertEquals(Status.getText(), "On Hold","Order status not changed to On Hold");
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order has changed to status: <b>"+Status.getText()+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
								flag=1;
							}else {
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order not available in list"+ common.captureScreenshot(ScreenshotRequire));

							}
						}else {
							System.out.println("start button not enabled");
							WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Hold button disabled"+ common.captureScreenshot(ScreenshotRequire));

						}
						break;
					}


				}
			}else {
				System.out.println("Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));

			}	
			if(flag==0) {
				System.out.println("valid Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));

			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To search order and validate the statua
	 * @author Arpana Kumari
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void searchOrderOnOrderExecutionPageAndValidateStatus(HashMap<String,String> hm,String ScreenshotRequire) throws InterruptedException{
		String TotalPOERecords=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageAndValidateStatus function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );

			Select select1 = new Select(statusDropDown);
			select1.selectByVisibleText("[All]");
			System.out.println("select -ALL- status");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);	

			orderTextbox.clear();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			common.setObjectValue(orderTextbox, "orderTextbox", hm.get("orderNo"));
			orderTextbox.sendKeys(Keys.RETURN);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();

			System.out.println("Search order:" +hm.get("orderNo") );
			String [] splitsvalues1=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues1[1].trim();
			System.out.println("total records in POE for order"+hm.get("orderNo")+"--"+TotalPOERecords);
			if(Integer.parseInt(TotalPOERecords)==1) {
				Assert.assertEquals(Status.getText(), "Started","Order status not changed to started");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order has changed to status: <b>"+Status.getText()+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order not available in list"+ common.captureScreenshot(ScreenshotRequire));

			}

		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To searchOrderOnOrderExecutionPageAndClickDetails
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public HashMap<String, String> searchOrderOnOrderExecutionPageAndClickDetails(String oStatus, String ScreenshotRequire) throws InterruptedException{
		String TotalPOERecords=null;
		String val=null;
		HashMap<String, String> map  = new HashMap<String, String>();
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageAndClickDetails function for "+ oStatus);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			orderTextbox.clear();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Select select = new Select(statusDropDown);
			select.selectByVisibleText(oStatus);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();
			System.out.println("total records in POE for status : "+oStatus+"--"+TotalPOERecords);
			if(Integer.parseInt(TotalPOERecords)>0) {				
				for(WebElement ele :webListOrder){
					if(ele.getAttribute("innerHTML").contains("img"))
					{
						System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));

					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Valid Order List displayed for status : <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
						val=ele.getText();
						System.out.println("clicked on order :"+ val);
						driver.findElement(By.xpath(".//span/div[contains(text(),'"+ele.getAttribute("innerText")+"')]")).click();
						map.put("orderNo", val);
						map.put("TotPOERecords", TotalPOERecords);
						map.put("ProductNo", driver.findElement(By.xpath(".//div[contains(text(),'"+ele.getAttribute("innerText")+"')]/../../../../td[@data-field='productnumberlist']//span[@class='display']")).getText());
						map.put("WC", driver.findElement(By.xpath(".//div[contains(text(),'"+ele.getAttribute("innerText")+"')]/../../../../td[@data-field='workcenterdesclist']//span[@class='display']")).getText());
						map.put("PlannedQuantity", driver.findElement(By.xpath(".//div[contains(text(),'"+ele.getAttribute("innerText")+"')]/../../../../td[@data-field='schedulquantitylist']//span[@class='display']")).getText());
						map.put("GoodQuantity", driver.findElement(By.xpath(".//div[contains(text(),'"+ele.getAttribute("innerText")+"')]/../../../../td[@data-field='goodquantitylist']//span[@class='display']")).getText());
						Actions action =new Actions(driver);
						//action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();
						action.doubleClick(driver.findElement(By.xpath(".//span/div[contains(text(),'"+ele.getAttribute("innerText")+"')]"))).perform();
						System.out.println("clicked on order"+ val);
						break;
					}
				}
			}else {
				System.out.println("Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));

			}	
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return map;
	}

	/**
	 * Method To search order status from dropdown
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public String searchOrderOnOrderExecutionPageWithStatus(String oStatus, String ScreenshotRequire) throws InterruptedException{
		String TotalPOERecords=null;
		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageWithStatus function for "+ oStatus);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			orderTextbox.clear();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Select select = new Select(statusDropDown);
			select.selectByVisibleText(oStatus);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();
			System.out.println("total records in POE for status : "+oStatus+"--"+TotalPOERecords);
			if(Integer.parseInt(TotalPOERecords)>0) {				
				for(WebElement ele :webListOrder){
					if(ele.getAttribute("innerHTML").contains("img"))
					{
						System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));

					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Valid Order List displayed for status : <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
						val=ele.getText();
						int gQ=Integer.parseInt(goodquantitylist.getText());
						int sQ=Integer.parseInt(schedulquantitylist.getText());
						double percentage_bar= (double)gQ*100/sQ;
						//long bar= Math.round(percentage_bar);

						String [] splitsperVal=common.splitValues(String.valueOf(percentage_bar),"\\.");
						String progressValCal=splitsperVal[0].trim();
						WebTestCase.getTest().log(LogStatus.PASS, "Progress bar value after calculation: "+progressValCal+ common.captureScreenshot(ScreenshotRequire));
						String [] splitsbarValOnline=common.splitValues(ELX_progressBar.getText(),"\\%");
						String progressVal=splitsbarValOnline[0].trim();
						WebTestCase.getTest().log(LogStatus.PASS, "Progress bar value online: "+progressVal+ common.captureScreenshot(ScreenshotRequire));

						if(progressValCal.contains(progressVal)) {
							System.out.println("progress bar value is coming correctly");
							WebTestCase.getTest().log(LogStatus.PASS, "Verified - progress bar value is coming correctly in POE screen: "+val+" >> "+oStatus+" >> "+progressValCal+ common.captureScreenshot(ScreenshotRequire));

						}else {
							System.out.println("progress bar value is not coming correctly");
							WebTestCase.getTest().log(LogStatus.FAIL, "Verified - progress bar value is coming not correctly in POE screen: "+val+" >> "+oStatus+" >> "+progressValCal+ common.captureScreenshot(ScreenshotRequire));

						}

					}
					break;
				}
			}else {
				System.out.println("Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));

			}	
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;
	}


	/**
	 * Method To search Order On Order execution Page with color code
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings({ "static-access" })
	public String searchOrderOnOrderExecutionPageWithColorCodePurple(String ScreenshotRequire) throws InterruptedException{

		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageWithColorCodePurple function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(4000);
			Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalPOERecords=splitsvalues[1].trim();
			//order color verification in POE screen
			if(Integer.parseInt(TotalPOERecords)>0) {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Total Order Records counts in POE screen: "+TotalPOERecords+ common.captureScreenshot(ScreenshotRequire));
				for(int i=0;i<ELX_GridColorCode.size();i++) {
					if(ELX_GridColorCode.get(i).getAttribute("class").contains("Purple")) {
						val=ELX_GridColorCode_Oid.get(i).getText();
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Purple Color order is available: "+val+ common.captureScreenshot(ScreenshotRequire));
						break;
					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Purple Color order is not available in POE screen for the current Workcenters "+ common.captureScreenshot(ScreenshotRequire));
					}
				}
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Total Records are 0 in POE screen"+ common.captureScreenshot(ScreenshotRequire));
			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	/**
	 * Method To search Order On Order execution Page with color code Green
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings({ "static-access" })
	public String searchOrderOnOrderExecutionPageWithColorCodeGreen(String ScreenshotRequire) throws InterruptedException{

		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageWithColorCodeGreen function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(4000);
			Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalPOERecords=splitsvalues[1].trim();
			int flag=0;
			//order color verification in POE screen
			if(Integer.parseInt(TotalPOERecords)>0) {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Total Order Records counts in POE screen: "+TotalPOERecords+ common.captureScreenshot(ScreenshotRequire));
				for(int i=0;i<ELX_GridColorCode.size();i++) {
					if(ELX_GridColorCode.get(i).getAttribute("class").contains("Green")) {
						if(ELX_GridColorCode_Green_status.getText().contains("Started")) {
							WebTestCase.getTest().log(LogStatus.PASS, "Verified - Green Color code order status is started: "+ELX_GridColorCode_Green_status.getText()+ common.captureScreenshot(ScreenshotRequire));
							break;
						}else {
							WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Green Color code order status is not started: "+ELX_GridColorCode_Green_status.getText()+ common.captureScreenshot(ScreenshotRequire));
						}
						flag=1;
					}else {
						flag=0;
					}
				}
				if(flag==0) {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - Green Color code order is not available in POE screen for the current Workcenters "+ common.captureScreenshot(ScreenshotRequire));
				}
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Total Records are 0 in POE screen"+ common.captureScreenshot(ScreenshotRequire));
			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}
	/**
	 * Method To search Order On Order execution Page with color code
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings({ "static-access" })
	public String searchOrderOnOrderExecutionPageWithColorCode(String ScreenshotRequire) throws InterruptedException{

		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageWithColorCode function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(4000);
			Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalPOERecords=splitsvalues[1].trim();

			//order color verification in POE screen
			if(Integer.parseInt(TotalPOERecords)>0) {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Total Order Records counts in POE screen: "+TotalPOERecords+ common.captureScreenshot(ScreenshotRequire));
				for(int i=0;i<ELX_GridColorCode.size();i++) {
					if(ELX_GridColorCode.get(i).getAttribute("class").contains("Green")) {
						if(ELX_GridColorCode_Green_status.getText().contains("Started")) {
							WebTestCase.getTest().log(LogStatus.PASS, "Verified - Green Color code order status is started: "+ELX_GridColorCode_Green_status.getText()+ common.captureScreenshot(ScreenshotRequire));
						}else {
							WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Green Color code order status is not started: "+ELX_GridColorCode_Green_status.getText()+ common.captureScreenshot(ScreenshotRequire));
						}
					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Green Color code order is not available in POE screen for the current Workcenters "+ common.captureScreenshot(ScreenshotRequire));
					}
					if(ELX_GridColorCode.get(i).getAttribute("class").contains("Purple")) {
						val=ELX_GridColorCode_Oid.get(i).getText()+"_"+"Purple";
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Purple Color order is available: "+val+ common.captureScreenshot(ScreenshotRequire));
					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Purple Color order is not available in POE screen for the current Workcenters "+ common.captureScreenshot(ScreenshotRequire));
					}
					if(ELX_GridColorCode.get(i).getAttribute("class").contains("Red")) {
						val=ELX_GridColorCode_Oid.get(i).getText()+"_"+"Red";
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Red Color order is available: "+ common.captureScreenshot(ScreenshotRequire));
					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Red Color order is not available in POE screen for the current Workcenters "+ common.captureScreenshot(ScreenshotRequire));
					}
					if(ELX_GridColorCode.get(i).getAttribute("class").contains("Yellow")) {
						val=ELX_GridColorCode_Oid.get(i).getText()+"_"+"Yellow";
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Yellow Color order is available: "+ common.captureScreenshot(ScreenshotRequire));
					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Yellow Color order is not available in POE screen for the current Workcenters "+ common.captureScreenshot(ScreenshotRequire));
					}
				}
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Total Records are 0 in POE screen"+ common.captureScreenshot(ScreenshotRequire));
			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}

	/**
	 * Method To search Order On Order execution Page with color code red
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings({ "static-access" })
	public String searchOrderOnOrderExecutionPageWithColorCodeRed(String ScreenshotRequire) throws InterruptedException{

		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageWithColorCodeRed function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(4000);
			Assert.assertTrue(totalOrderRecord.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalPOERecords=splitsvalues[1].trim();
			int flag=0;
			//order color verification in POE screen
			if(Integer.parseInt(TotalPOERecords)>0) {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Total Order Records counts in POE screen: "+TotalPOERecords+ common.captureScreenshot(ScreenshotRequire));
				for(int i=0;i<ELX_GridColorCode.size();i++) {
					if(ELX_GridColorCode.get(i).getAttribute("class").contains("Red")) {
						val=ELX_GridColorCode_Oid.get(i).getText();
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Red Color order is available: "+ common.captureScreenshot(ScreenshotRequire));
						break;
					}else {
						flag=0;
					}

				}
				if(flag==0) {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - Red Color order is not available in POE screen for the current Workcenters "+ common.captureScreenshot(ScreenshotRequire));
				}
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Total Records are 0 in POE screen"+ common.captureScreenshot(ScreenshotRequire));
			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}


	@SuppressWarnings("static-access")
	public String findOrderDetails(String oStatus,String oId, String line, String ScreenshotRequire) throws InterruptedException{

		String val=null;
		int flag=0;
		try{
			System.out.println("inside searchOrderOnOrderCockpitPage function");

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, orderSearchTextbox, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(orderSearchTextbox.isDisplayed(), "Order# Textbox not displayed");
			Thread.sleep(5000);
			orderTextbox.clear();
			common.setObjectValue(orderTextbox, "orderTextbox", oId);
			orderTextbox.sendKeys(Keys.RETURN);
			Thread.sleep(5000);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			System.out.println("sent value on orderTextbox "+oId);
			if(oId.length()==1) {

				Select select = new Select(statusDropDown);
				select.selectByVisibleText(oStatus);
				Thread.sleep(5000);

				System.out.println("sent value on statusDropDown "+oStatus);

			}
			Common.isElementDisplayed(driver,orderList, IConstants.HIGH_WAIT_TIME);

			Assert.assertTrue(orderList.isDisplayed(), "Order List not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed"+ common.captureScreenshot(ScreenshotRequire));


			//List<WebElement> webList =driver.findElements(By.xpath(".//td[contains(@class, 'value')][1]//span"));
			if(webListOrder==null){
			}
			for(WebElement ele :webListOrder){
				if(ele.isDisplayed()==true){
					if(ele.getAttribute("innerHTML").contains("img"))
					{
						System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));
					}
					else {
						flag=1;
						val=ele.getAttribute("innerText");
						val=val+"_"+OrderTypeRecord.getText()+"_"+ProductIdRecord.getText()+"_"+scheduledQuanList.getText()+"_"+goodQuanList.getText()+"_"+badQuanList.getText()+"_"+scheStartDate.getText()+"_"+schEndDate.getText()+"_"+actualStartDate.getText()+"_"+Status.getText()+"_"+expStart.getText()+"_"+expEnd.getText();
						//driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']")).click();
						/*Actions action =new Actions(driver);
					action.doubleClick(driver.findElement(By.xpath(".//span[text()='"+ele.getAttribute("innerHTML")+"']"))).perform();*/
						Thread.sleep(5000);
						break;
					}

				}
			}
			Assert.assertEquals(flag, 1,  "Valid order list of status: "+oStatus+" : is not displaying");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order number is displayed and clicked"+ common.captureScreenshot(ScreenshotRequire));

			System.out.println("clicked on order"+ val);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;			
	}


	/**
	 * Method To search order status from dropdown
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public String compareorderStatusWithStatusDropdown(String oStatus, String ScreenshotRequire) throws InterruptedException{
		String TotalPOERecords=null;
		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageWithStatus function for "+ oStatus);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			orderTextbox.clear();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Select select = new Select(statusDropDown);
			select.selectByVisibleText(oStatus);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();
			System.out.println("total records in POE for status : "+oStatus+"--"+TotalPOERecords);
			if(Integer.parseInt(TotalPOERecords)>0) {
				List< String > statusValues = new ArrayList<String>();
				System.out.println(webListStatus.size());
				for(int i=0;i<webListStatus.size();i++){
					System.out.println(webListStatus.get(i).getText());
					statusValues.add(webListStatus.get(i).getText());
					/*if(webListStatus.contains(oStatus)){
						statusValues.add(webListStatus.get(i).getText());	
					}*/
				}


				if(!statusValues.contains(oStatus)){

					WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Mismatch in order status : <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
				}

				else{
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - All status  in order status table are matched with  : <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
				}

			}else {
				System.out.println("Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));

			}	
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return val;
	}

	/**
	 * Method To search order status from dropdown
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")

	public void clickonExport(String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), 120);
		Common.isElementDisplayed(driver, startLegend, 100);
		common.waitTillElementDisappears(By.xpath(toolbox), 800);
		common.captureScreenshot(ScreenshotRequire);
		Assert.assertTrue(exportIcon.isDisplayed()," Export Icon not clicked");

		boolean value=false;
		if( value=true)
		{
			value=exportIcon.isDisplayed();
			System.out.println(value);
			common.clickOnObject(exportIcon, "exportIcon");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Export icon  is clicked  : <b>"+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
			Assert.assertTrue(exportBtn.isDisplayed()," Export button  not Displayed");
			common.clickOnObject(exportBtn, "exportBtn");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified -  Export Button  is Verified and File is downloaded : <b>"+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
			Thread.sleep(8000);
			//WebTestCase.getTest().log(LogStatus.PASS, "Verified - Export icon  is clicked And Export Icon is Verified : <b>"+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
		}
		else 
		{
			WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Export button is Not clicked: <b>"+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
		}
		//Reporter.log("stopIcon screen passed");
		driver.switchTo().defaultContent();

	}

	public boolean isFileDownloaded(String downloadPath, String fileName, String ScreenshotRequire) {
		//zz//s
		File dir = new File(downloadPath);
		File[] dirContents = dir.listFiles();

		for (int i = 0; i < dirContents.length; i++) {
			if (dirContents[i].getName().equals(fileName)) {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - File is downloaded Sucessfully: in  <b>" + downloadPath + "<b/>"+ common.captureScreenshot(ScreenshotRequire));



			}
		}
		return true;
	}
	/**
	 * Method To search order status from dropdown and compare buttons
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validatePrimaryButtonsWithStatus(String oStatus,HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		String TotalPOERecords=null;
		int flag=1;
		try{
			System.out.println("inside validatePrimaryButtonsWithStatus function for "+ oStatus+">>"+hmAction);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Select select = new Select(statusDropDown);
			select.selectByVisibleText(oStatus);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);
			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();
			System.out.println("total records in POE for status : "+oStatus+"--"+TotalPOERecords);
			if(Integer.parseInt(TotalPOERecords)>0) {
				ordId.click();
				for (int i = 0; i < ELXButtonList.size(); i++) {
					if(ELXButtonList.get(i).isDisplayed()) {
						if((ELXButtonList.get(i).getAttribute("innerText").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
							WebTestCase.getTest().log(LogStatus.PASS, "Verified - Valid Footer  Button List displayed for status : <b>"+oStatus+"<b/> is >> "+ELXButtonList.get(i).getAttribute("innerHTML"));
						}else{
							Assert.assertEquals(ELXButtonList.get(i).getAttribute("innerText").toLowerCase(),hmAction.get(i+1).toLowerCase(),"buttons are not matching for the status:: "+oStatus);
							WebTestCase.getTest().log(LogStatus.FAIL, "POE screen  Footer Buttons Expected for status : <b>"+oStatus+"<b/> is >>"+" -- "+hmAction.get(i+1)+ " -- " + "  But  appearing as  " +ELXButtonList.get(i).getText());	
							flag=0;
						}
					}}
				//WebTestCase.getTest().log(LogStatus.INFO, "Verified - Button List displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
			}else {
				System.out.println("Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.INFO, "*** No order available for status: <b>"+oStatus+"<b/> *** "+ common.captureScreenshot(ScreenshotRequire));

			}

		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To getFirstRowDetails
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public HashMap<String, String> getFirstPOEScreenOrderDetails(String ScreenshotRequire) throws InterruptedException{
		String TotalPOERecords=null;
		HashMap<String, String> map  = new HashMap<String, String>();
		try{
			System.out.println("inside getFirstRowDetails function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();
			if(Integer.parseInt(TotalPOERecords)>0) {				
				map.put("orderNo", ELX_GridColorCodeList.get(0).getText());
				WebTestCase.getTest().log(LogStatus.PASS, "orderid: "+ ELX_GridColorCodeList.get(0).getText()+common.captureScreenshot(ScreenshotRequire));
				JavascriptExecutor js = (JavascriptExecutor)driver; 	
				js.executeScript("arguments[0].scrollIntoView();",actualstartdatelist);
				Thread.sleep(5000);
				map.put("expectedstartdatelist", ELX_GridColorCodeList.get(13).getText().trim());
				WebTestCase.getTest().log(LogStatus.PASS, "expectedstartdatelist: "+ ELX_GridColorCodeList.get(13).getText()+common.captureScreenshot(ScreenshotRequire));

				map.put("expectedenddatelist", ELX_GridColorCodeList.get(14).getText().trim());
				WebTestCase.getTest().log(LogStatus.PASS, "expectedenddatelist: "+ ELX_GridColorCodeList.get(14).getText()+common.captureScreenshot(ScreenshotRequire));

				map.put("actualstartdatelist", ELX_GridColorCodeList.get(16).getText().trim());
				WebTestCase.getTest().log(LogStatus.PASS, "actualstartdatelist: "+ ELX_GridColorCodeList.get(16).getText().trim()+common.captureScreenshot(ScreenshotRequire));


			}else {
				System.out.println("Order list not appearing");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List not displayed");
			}	
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return map;
	}

	/**
	 * Method To search order status from dropdown and start
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void searchOrderOnOrderExecutionPageAndStart(String oStatus, String ScreenshotRequire) throws InterruptedException{
		String TotalPOERecords=null;
		String val=null;
		try{
			System.out.println("inside searchOrderOnOrderExecutionPageAndStart function for "+ oStatus);
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			orderTextbox.clear();
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Select select = new Select(statusDropDown);
			select.selectByVisibleText(oStatus);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(7000);

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			TotalPOERecords=splitsvalues[1].trim();
			System.out.println("total records in POE for status : "+oStatus+"--"+TotalPOERecords);
			int flag=0;
			if(Integer.parseInt(TotalPOERecords)>0) {				
				for(WebElement ele :webListOrder){
					if(ele.getAttribute("innerHTML").contains("img"))
					{
						System.out.println("----ignore order---"+ele.getAttribute("innerHTML"));

					}else {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order List displayed for status : <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
						val=ele.getText();
						driver.findElement(By.xpath(".//span/div[contains(text(),'"+ele.getAttribute("innerText")+"')]")).click();

						System.out.println("clicked on order :"+ val);
						if(btnStart.isEnabled()){
							common.clickOnObject(btnStart, "Start Button");
							System.out.println("clicked on start btn");
							WebTestCase.getTest().log(LogStatus.PASS, "Clicked on order to start: "+ val);
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							Thread.sleep(4000);
							Select select1 = new Select(statusDropDown);
							select1.selectByVisibleText("[All]");
							System.out.println("select -ALL- status");
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
							Thread.sleep(7000);	
							common.clickOnObject(orderTextbox, "orderTextbox");
							orderTextbox.sendKeys(val);
							orderTextbox.sendKeys(Keys.ENTER);
							common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
							Thread.sleep(8000);

							System.out.println("Search order:" +val );
							String [] splitsvalues1=common.splitValues(totalOrderRecord.getText(),"\\:");
							TotalPOERecords=splitsvalues1[1].trim();
							System.out.println("total records in POE for order"+val+"--"+TotalPOERecords);
							if(Integer.parseInt(TotalPOERecords)>0) {
								Assert.assertEquals(Status.getText(), "Started","Order status not changed to started");
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order has changed to status: <b>"+Status.getText()+"<b/>"+ common.captureScreenshot(ScreenshotRequire));
								flag=1;
							}else {
								WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order not available in list"+ common.captureScreenshot(ScreenshotRequire));

							}
						}else {
							System.out.println("start button not enabled");
							WebTestCase.getTest().log(LogStatus.FAIL, "Verified - start button disabled to perform"+ common.captureScreenshot(ScreenshotRequire));

						}
						break;
					}


				}
			}else {
				System.out.println("Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Valid Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));

			}	
			if(flag==0) {
				System.out.println("valid Order list not appearing for status:" + oStatus);
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Valid Order List not displayed for status: <b>"+oStatus+"<b/>"+ common.captureScreenshot(ScreenshotRequire));

			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
	}
	/**
	 * Method To get Last downloaded file name
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	public File getLatestFilefromDir(String dirPath){
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		return lastModifiedFile;
	}

}