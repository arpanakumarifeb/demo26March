package com.web.elx.pages;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.elx.common.Common;
import com.elx.helper.*;
import com.relevantcodes.extentreports.LogStatus;

public class OrderOperationPage {



	@FindBy(xpath = "//li[@title='ORD-010']")
	private WebElement ORDPageTitle;



	@FindBy(xpath ="//td[contains(@data-value,'M914670')]")
	private WebElement loginUser;

	@FindBy(xpath = "//button[(@value='GENERAL')]")
	private WebElement genetalTab;


	@FindBy(xpath ="//td[@class='Control fc_InRepair']/span")
	private WebElement inRepairSection;

	@FindBy(xpath = "//tr[@class='HeadF']/td[4]/div/input")
	private WebElement productTextbox;

	@FindBy(xpath ="//button[@value='SERIALNO']")
	private WebElement serialNoTab;

	@FindBy(xpath =".//span[@class='TabNotify']")
	private WebElement nonConformanceCount;
	
	@FindBy(xpath = "//tr[@data-disable]/td[@data-field='cycle']//span")
	private List <WebElement> serialNoList;

	@FindBy(xpath = "(//tr//td[@data-field='serialno'])[4]")
	private  WebElement orderList	;

	@FindBy(xpath = ".//span[@title='Home']")
	private  WebElement homeIcon	;

	@FindBy(xpath ="//button[@value='NONCONFORMANCE']")
	private WebElement NCTab;

	@FindBy(xpath = ".//div[@class='Container vpBody']//tr[2]/td")
	private List <WebElement> ncFirstRowdetails;

	@FindBy(xpath =".//div[@class='Container vpBody']")
	private WebElement ContainerBodySerial;
	
	@FindBy(xpath ="//td[@class='Control fc_WipOrderNo']/span[contains(@class,'Bold')]")
	private WebElement orderNumber;

	@FindBy(xpath = "//div[@class='Container vpBody']/table//tr")
	private  WebElement NCList	;

	@FindBy(xpath = "//apr-image[@class='apr-font-me apr-image apr-and-img-status-started']")
	private  WebElement orderDetailsLeftPanel	;

	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	@FindBy(xpath = "//apr-image[contains(@class,'apr-font-me apr-image apr-and-img-status-')]")
	private List <WebElement> leftPanelLine;

	@FindBy(xpath = "//tr[@data-level='1']//apr-image[contains(@class,'apr-font-me apr-image apr-and-img-status-')]")
	private List <WebElement> leftPanelLineLevel1;

	@FindBy(xpath = "//tr[contains(@data-key,'FBOD')]//span[contains(@class,'ExpandIcon')]")
	private  WebElement FBODIcon	;
	
	@FindBy(xpath = ".//div[@class='ButtonList Right ELX_FooterButtons_Edi right  Count3']/button[contains(@class,'apr') and not(@disabled)]/span")
	private List <WebElement> footerBtn;

	@FindBy(xpath = "//apr-image[@class='apr-font-me apr-image apr-and-img-status-started']")
	private List <WebElement> leftPanelLineStarted;

	@FindBy(xpath = "//button[@value='START']/span")
	private  WebElement btnStart	;

	@FindBy(xpath = "//button[@value='HOLD']/span")
	private  WebElement btnHold	;
	
	@FindBy(xpath = "//button[@value='CLOSE']/span")
	private  WebElement btnClose	;
	
	@FindBy(xpath = "//button[@value='SAVE']/span")
	private  WebElement btnSave	;

	
	@FindBy(xpath = "//button[@value='OFFHOLD']/span")
	private  WebElement btnoffHold	;
	
	@FindBy(xpath = "//table[contains(@id,'_Control')]//span/apr-image")
	private List <WebElement> webCenterStatus;


	@FindBy(xpath = "//tr[@data-level='0']//span/apr-image")
	private WebElement dataLevel0;



	@FindBy(xpath = ".//td[@class='Control fc_WipOrderStatus']/span")
	private  WebElement WipOrderStatusGT	;

	@FindBy(xpath = ".//td[@class='Control fc_WipOrderTypeName']/span")
	private  WebElement WipOrderTypeNameGT	;

	@FindBy(xpath = ".//td[@class='Control fc_ProductNo']/span")
	private  WebElement ProductNoGT	;

	@FindBy(xpath = ".//input[contains(@class,'_ScheduledStartDate')]")
	private  WebElement ScheduledStartDate	;	

	@FindBy(xpath = ".//input[contains(@class,'_ScheduledEndDate')]")
	private  WebElement ScheduledEndDate	;	

	@FindBy(xpath = ".//input[contains(@class,'_ExpectedStartDate')]")
	private  WebElement ExpectedStartDate;

	@FindBy(xpath = ".//input[contains(@class,'_ExpectedEndDate')]")
	private  WebElement ExpectedEndDate;

	@FindBy(xpath = ".//input[contains(@class,'_ActualStartDate')]")
	private  WebElement ActualStartDate;

	@FindBy(xpath = ".//td[contains(@class,'ScheduledQuantity')]/span")
	private  WebElement ScheduledQuantity;

	@FindBy(xpath = ".//td[contains(@class,'GoodQuantityProduced')]/span")
	private  WebElement GoodQuantityProduced;

	@FindBy(xpath = ".//td[contains(@class,'BadQuantityProduced')]/span")
	private  WebElement BadQuantity;


	@FindBy(xpath = ".//div[@class='Container TreeData']")
	private  WebElement ContainerTreeData;

	@FindBy(xpath = ".//div[@class='Total']")
	private WebElement totalOrderRecord;


	@FindBy(xpath = "//button/span[contains(@class,'translation')]")
	private WebElement holdButtonOnPopup;

	@FindBy(xpath = "//button[contains(@class,'Primary ELX_BigSizeButton')]/span")
	private List <WebElement> closedReasonCodes ;
	
	
	@FindBy(xpath = "//tr[contains(@data-level,'2')]//span[2]")
	private List <WebElement> TreeStructureLevel2;

	@FindBy(xpath = "//*[contains(@class,'ExpandIcon open')]")
	private List <WebElement> ExpandIconOpenList ;

	@FindBy(xpath = "//*[contains(@class,'ExpandIcon close')]")
	private WebElement ExpandIconClose ;

	@FindBy(xpath = "//span[contains(@class,'ExpandIcon close')]")
	private List <WebElement> ExpandIconCloseList;

	@FindBy(xpath = "//button[@value='HOLD']")
	private  WebElement btnHold1	;

	@FindBy(xpath = "//button[@value='SAVE']")
	private  WebElement btnSave1	;

	@FindBy(xpath = "//button[@value='START']")
	private  WebElement btnStart1;
	
	@FindBy(xpath = ".//div[@class='ELX_BigSize ELX_GridWhite']")
	private  WebElement serialNoDiv;
	
	@FindBy(xpath = "//div[@class='ButtonList Right ELX_FooterButtons_Edi right  Count3']//button/span")
	private List <WebElement> footerBtnList;
	
	@FindBy(xpath = ".//td[@class='Control fc_GoodQuantityProduced']/span")
	private  WebElement goodQty;
	
	@FindBy(xpath = ".//td[@class='Control fc_ScheduledQuantity']/span")
	private  WebElement scheduledQty;
	
	

	private WebDriver driver;
	private Common common;
	ReadConfig testData = new ReadConfig();

	public OrderOperationPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}

	/**
	 * Method To validate Operation Page Title
	 * @author Arpana
	 * @throws InterruptedException 
	 */ 
	@SuppressWarnings("static-access")
	public void validateOperationPageTitle(String title, String ScreenshotRequire) throws InterruptedException{
		try
		{	
			System.out.println("inside validate operation page title function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(8000);
			common.isElementDisplayed(driver, ORDPageTitle, IConstants.MEDIUM_WAIT_TIME);
			//Assert.assertEquals(ORDPageTitle.getText(), title,  "Order Operation page not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order Operation page is displayed successfuly"+ common.captureScreenshot(ScreenshotRequire));
			System.out.println("operation page title:"+ORDPageTitle.getText());
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	//Validate Login User
	public void validateUser(String user, String ScreenshotRequire) throws InterruptedException{
		try {
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			Common.isElementDisplayed(driver, loginUser, IConstants.SYS_WAIT_TIME);
			Assert.assertEquals(loginUser.getText(), user, "Not a valid user");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Login user displayed as expected"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To validate Order Details
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public String validateOrderDetails(String orderId,String ScreenshotRequire) throws InterruptedException{
		String GoogSchQuantity=null;
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			System.out.println("inside validateOrderDetails function");
			Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+orderId+"']")).getText(),orderId,"Expected order number is not appearing on order operation page");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order id "+orderId+ " is displayed successfuly in Operation page"+ common.captureScreenshot(ScreenshotRequire));
			GoogSchQuantity=goodQty.getText()+":"+scheduledQty.getText();
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return GoogSchQuantity;
	}

	/**
	 * Method To validate General Tab Order Details
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateGeneralTabOrderDetails(String orderId, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		common.isElementDisplayed(driver, genetalTab, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(genetalTab.isDisplayed(), "General Tab not displayed");
		System.out.println("general tab displayed");
		common.isElementDisplayed(driver, inRepairSection, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(inRepairSection.isDisplayed(), "In-Repair section not displayed");
		if(!(inRepairSection.getText().contains("--"))) {
			if(Integer.parseInt(inRepairSection.getText())>0) {
				if(Integer.parseInt(nonConformanceCount.getText())>0) {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - In-Repair is displayed in Operation page with value "+inRepairSection.getText()+" And NC count is:" +nonConformanceCount.getText()+ common.captureScreenshot(ScreenshotRequire));
				}else {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - In-Repair is displayed in Operation page with value "+inRepairSection.getText()+" And NC count is:" +nonConformanceCount.getText()+common.captureScreenshot(ScreenshotRequire));
				}
			}
		}else {
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - In-Repair is displayed in Operation page with value "+inRepairSection.getText()+" And NC count is:" +nonConformanceCount.getText()+common.captureScreenshot(ScreenshotRequire));

		}
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - In-Repair is displayed in Operation page with value "+inRepairSection.getText()+""+ common.captureScreenshot(ScreenshotRequire));
		driver.switchTo().defaultContent();


	}


	//General tab Verification
	@SuppressWarnings("static-access")
	public void validateAllGeneralTabOrderDetails(String orderDetails, String ScreenshotRequire) throws InterruptedException{
		String ScheduledQuan=null;
		String GoodQuantityProd=null;
		String BadQuan=null;

		common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		common.isElementDisplayed(driver, genetalTab, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(genetalTab.isDisplayed(), "General Tab not displayed");
		System.out.println("general tab displayed");

		String separator = new String("_");
		String [] splits = orderDetails.split(separator);
		if(ScheduledQuantity.getText().contains("--")) {ScheduledQuan="0";}else {ScheduledQuan=ScheduledQuantity.getText();}
		if(GoodQuantityProduced.getText().contains("--")) {GoodQuantityProd="0";}else {GoodQuantityProd=GoodQuantityProduced.getText();}
		if(BadQuantity.getText().contains("--")) {BadQuan="0";}else {BadQuan=BadQuantity.getText();}

		common.isElementDisplayed(driver, inRepairSection, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(inRepairSection.isDisplayed(), "In-Repair section not displayed");
		//System.out.println(splits[1]+"_"+WipOrderTypeNameGT.getText());
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - In-Repair is displayed in Operation page with value "+inRepairSection.getText()+""+ common.captureScreenshot(ScreenshotRequire));
		Assert.assertEquals(WipOrderTypeNameGT.getText(), splits[1],  "Valid order type is not displaying");
		Assert.assertEquals(ProductNoGT.getText(),splits[2],   "Valid Product number is not displaying");
		Assert.assertEquals(ScheduledQuan,splits[3],   "Valid Scheduled Quantity is not displaying");
		Assert.assertEquals(GoodQuantityProd,splits[4],  "Valid Good Quantity Produced is not displaying");
		Assert.assertEquals(BadQuan,splits[5],   "Valid Bad Quantity is not displaying");
		//Assert.assertEquals(ScheduledStartDate.getText(),splits[6],   "Valid Scheduled Start Date is not displaying");
		//Assert.assertEquals(ScheduledEndDate.getText(),splits[7],   "Valid Scheduled End Date is not displaying");
		//Assert.assertEquals(ActualStartDate.getText(),splits[8],   "Valid Actual Start Date is not displaying");

		common.isElementDisplayed(driver, serialNoTab, IConstants.HIGH_WAIT_TIME);
		Assert.assertTrue(serialNoTab.isDisplayed(), "Serial No Tab is not displayed in screen");
		common.clickOnObject(serialNoTab, "serialNoTab");
		System.out.println("serial no tab clicked ");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Serial No Tab is clicked	"+ common.captureScreenshot(ScreenshotRequire));
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );

		System.out.println("ssd "+ ScheduledQuantity.getText()+"--"+totalOrderRecord.getText().substring(9, 12).trim());

		if(totalOrderRecord.getText().contains(ScheduledQuan)) {
			Assert.assertTrue(totalOrderRecord.getText().contains(ScheduledQuan),  "Scheduled Quantity is not same as serial list records");
		}
		driver.switchTo().defaultContent();


	}

	/**
	 * Method To validate Serial No Tab Details
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	@SuppressWarnings("static-access")
	public String validateSerialNoTabDetails(String orderId, String ScreenshotRequire) throws InterruptedException{
		String serailNO= null;
		try{
			System.out.println("inside validateSerialNoTabDetails function");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(5000);
			common.isElementDisplayed(driver, serialNoTab, IConstants.HIGH_WAIT_TIME);
			Assert.assertTrue(serialNoTab.isDisplayed(), "Serial No Tab is not displayed in screen");
			common.clickOnObject(serialNoTab, "serialNoTab");
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			System.out.println("serial no tab clicked ");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Serial No Tab is clicked	");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(7000);
			if(!(serialNoDiv.getText().contains("Error"))) {
				if(ContainerBodySerial.isDisplayed()) {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified -Serial No details section displayed"+ common.captureScreenshot(ScreenshotRequire));
				Thread.sleep(2000);
				serailNO= orderList.getText();
				}
			}else {
				serailNO= "";
				
			}}
		
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return serailNO;

	}

	/**
	 * Method To click Home Icon
	 * @author Arpana Kumari
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void clickHomeIcon(String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside click homeIcon function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			common.isElementDisplayed(driver, homeIcon, IConstants.MEDIUM_WAIT_TIME);
			Assert.assertTrue(homeIcon.isDisplayed(), "Home Icon not displayed");			
			common.clickOnObject(homeIcon, "homeIcon");
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			System.out.println("homeIcon clicked");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Home page is appearing"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}

	}

	/**
	 * Method To validate NC Count On Order Operation Page
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public String validateNCCountOnOrderOperationPage(String orderId, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		System.out.println("Inside NC Count check function");
		common.isElementDisplayed(driver, nonConformanceCount, IConstants.MEDIUM_WAIT_TIME);
		Assert.assertTrue(nonConformanceCount.isDisplayed(), "NC Count not displayed in order operation page");
		String NCCount=nonConformanceCount.getText();
		System.out.println("NC value: " +nonConformanceCount.getText());
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Count "+nonConformanceCount.getText()+ " is displayed successfuly in Operation page"+ common.captureScreenshot(ScreenshotRequire));
		driver.switchTo().defaultContent();
		return NCCount;
	}


	/**
	 * Method To validate NC Tab Order Details
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public int validateNCTabOrderDetails(String NCID,String NCCOUNT,String SERIALNO,String ORDERID,String status, String ScreenshotRequire) throws InterruptedException{
		int NewNCCount=0;
		SoftAssert softAssert = new SoftAssert();
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);

			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			NewNCCount=Integer.parseInt(nonConformanceCount.getText());
			int previousNCCOunt=Integer.parseInt(NCCOUNT);
			softAssert.assertEquals(NewNCCount, previousNCCOunt+1,  "NC count not increased");
			System.out.println("Nc Value was " +NCCOUNT+" and get increased to: "+NewNCCount);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Value was " + NCCOUNT+" and increased to "+NewNCCount+ common.captureScreenshot(ScreenshotRequire));
			common.clickOnObject(NCTab, "NCTab");
			System.out.println("clicked on NC tab");
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "NC tab clicked"+ common.captureScreenshot(ScreenshotRequire));
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(10000);
			String tot= totalOrderRecord.getText();
			String [] splitsvalues=common.splitValues(tot,"\\:");
			String TotalORDRecords=splitsvalues[1].trim();

			if(Integer.parseInt(TotalORDRecords)>0){

				WebTestCase.getTest().log(LogStatus.PASS, "NC List is appearing"+ common.captureScreenshot(ScreenshotRequire));
				//String ncId=ncFirstRowdetails.get(0).getText();
				//Thread.sleep(1000);
				System.out.println("nc value"+(driver.findElement(By.xpath(".//span[text()='"+NCID+"']"))).getText());
				Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+NCID+"']")).getText(),NCID,"NC Code is not displaying");
				System.out.println("match NC code found in nc tab");				
				//String serialNo=ncFirstRowdetails.get(3).getText();
				Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+SERIALNO+"']")).getText(),SERIALNO, "Serial No not is displaying");

				//String ncStatus=ncFirstRowdetails.get(6).getText();
				Assert.assertEquals(driver.findElement(By.xpath(".//span[contains(text(),'New')]")).getText(),status, "Status new is displaying for new NC");
			}
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return NewNCCount;

	}


	/**
	 * Method To validate NC Tab Order Details After NC Resolve
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public int validateNCTabOrderDetailsAfterNCResolve(String NCID,int NCCOUNT,String SERIALNO,String ORDERID, String ScreenshotRequire) throws InterruptedException{
		int NewNCCountAfterResolve=0;
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);

			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			NewNCCountAfterResolve=Integer.parseInt(nonConformanceCount.getText());
			System.out.println("New NC count:" +NewNCCountAfterResolve);
			if(NewNCCountAfterResolve < NCCOUNT) {
				System.out.println("Nc Value was "+ NCCOUNT+" and get decreased to "+NewNCCountAfterResolve);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Nc Value was "+NCCOUNT+" and decreased after NC get resolved:"+NewNCCountAfterResolve+ common.captureScreenshot(ScreenshotRequire));

			}
			else
			{
				System.out.println("Nc Value not decreased");
				WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Nc Value not decreased after NC Resolve:"+NewNCCountAfterResolve+ common.captureScreenshot("true"));

			}

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return NewNCCountAfterResolve;

	}

	//NC tab Verification
	@SuppressWarnings("static-access")
	public int validateNCTabOrderDetailsAfterNCCancel(String NCID,int NCCOUNT,String SERIALNO,String ORDERID, String ScreenshotRequire) throws InterruptedException{
		int NewNCCountAfterCancel=0;
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			NewNCCountAfterCancel=Integer.parseInt(nonConformanceCount.getText());
			if(NewNCCountAfterCancel < NCCOUNT) {
				System.out.println("Nc Value was "+ NCCOUNT+"and get decreased to "+NewNCCountAfterCancel);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - Nc Value was "+NCCOUNT+"and decreased after NC resolved:"+NewNCCountAfterCancel+ common.captureScreenshot(ScreenshotRequire));

			}
			else
			{
				System.out.println("Nc Value not decreased");
				WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Nc Value not decreased after NC Cancel:"+NewNCCountAfterCancel+ common.captureScreenshot(ScreenshotRequire));

			}

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return NewNCCountAfterCancel;

	}

	@SuppressWarnings("static-access")
	public void validateOrderDetailsOperationPage(String orderId,String orderStatus, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateOrderDetailsOperationPage"+orderId+"--"+orderStatus);
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Thread.sleep(6000);
		if(orderDetailsLeftPanel.getText().contains(orderId)) {
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order id "+orderId+ " is displayed successfuly in Operation page"+ common.captureScreenshot(ScreenshotRequire));

		}else {
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Order id "+orderId+ " is not displayed successfuly in Operation page"+ common.captureScreenshot(ScreenshotRequire));

		}
		System.out.println("Verified - Order id "+orderId+ " is displayed successfuly in Operation page");
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To validate Left Panel Order Details Hold And Start
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public int validateLeftPanelOrderDetailsHoldAndStart(String oId,String oStatus,String oLine,String wc, HashMap<Integer,String> hm, String ScreenshotRequire) throws InterruptedException{
		int NewNCCount=0;
		int workCenter=Integer.parseInt(wc);
		System.out.println("inside validateLeftPanelOrderDetailsHoldAndStart function");

		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertTrue(WipOrderStatusGT.isEnabled(),  "Order status is not displayed correctly");
			//Assert.assertEquals(WipOrderStatusGT.getText(), oStatus,"Order status is not correct in general tab");
			Assert.assertTrue(dataLevel0.getAttribute("innerHTML").contains("Started"),"work center status is not correct");
			WebTestCase.getTest().log(LogStatus.INFO, "Initial work Center Header status:"+dataLevel0.getAttribute("innerHTML"));
			System.out.println("wc header actual:"+ dataLevel0.getAttribute("innerHTML"));

			for(int i=1;i<leftPanelLine.size();i++) {
				if((leftPanelLine.get(i).getAttribute("innerHTML").contains(hm.get(i+1)))) {
					System.out.println("Initial work Center list:"+leftPanelLine.get(i).getAttribute("innerHTML")+"---global file: "+hm.get(i+1));
					WebTestCase.getTest().log(LogStatus.INFO, "Initial work Center list:"+leftPanelLine.get(i).getAttribute("innerHTML"));
				}
			}
			if(leftPanelLine.get(workCenter).getText().contains("Started")) {
				common.clickOnObject(leftPanelLine.get(workCenter), "workcenter");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(4000);
				WebTestCase.getTest().log(LogStatus.INFO, "Work center clicked :"+hm.get(workCenter)+ common.captureScreenshot(ScreenshotRequire));	

				Assert.assertTrue(btnHold.isEnabled(),  "Hold  button not enabled");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - the hold button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
				common.clickOnObject(btnHold,"btnHold");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(8000);
				System.out.println("Verified - hold button clicked");

				common.isElementDisplayed(driver, holdButtonOnPopup, IConstants.HIGH_WAIT_TIME);
				Thread.sleep(4000);
				JavascriptExecutor js = (JavascriptExecutor)driver; 
				js.executeScript("arguments[0].click();", holdButtonOnPopup);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Clicked on Hold PopUp Button"+ common.captureScreenshot(ScreenshotRequire));
				Thread.sleep(8000);

				WebTestCase.getTest().log(LogStatus.INFO, "Verified - hold button clicked"+ common.captureScreenshot(ScreenshotRequire));

				String [] splits1=common.splitValues(leftPanelLine.get(0).getText(),"\\(");
				String [] splits2=common.splitValues(splits1[1].trim(),"\\)");
				System.out.println("status " + splits2[0].trim());

				Assert.assertEquals(splits2[0].trim(),"Held","work center status is not correct");
				WebTestCase.getTest().log(LogStatus.INFO, "Initial work Center Header status:"+leftPanelLine.get(0).getAttribute("innerHTML"));
				int counter=0;
				for(int i=1;i<leftPanelLine.size();i++) {
					if((leftPanelLine.get(i).getAttribute("innerHTML").contains(hm.get(i+1))&&((leftPanelLine.get(i).getAttribute("innerHTML").contains("On Hold"))))) {
						System.out.println("work Center list after hold:"+leftPanelLine.get(i).getAttribute("innerHTML"));
						WebTestCase.getTest().log(LogStatus.INFO, "Work Center list after hold:"+leftPanelLine.get(i).getAttribute("innerHTML"));
						counter++;
					}else {
						System.out.println("work Center list after hold:"+leftPanelLine.get(i).getAttribute("innerHTML"));
						WebTestCase.getTest().log(LogStatus.INFO, "Work Center list after hold:<b>"+leftPanelLine.get(i).getAttribute("innerHTML")+"</b>");
						String [] splits3=common.splitValues(leftPanelLine.get(i).getText(),"\\(");
						String [] splits4=common.splitValues(splits3[1].trim(),"\\)");
						//System.out.println("status " + splits4[0].trim());

						//Assert.assertEquals(splits4[0].trim(),"On Hold","Work center not displayed correctly");
						counter++;
					}
				}
				//Assert.assertEquals(counter,5,"All 5 work centers status is not showing correctly.");

				common.clickOnObject(leftPanelLine.get(workCenter), "workcenter");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(2000);
				WebTestCase.getTest().log(LogStatus.INFO, "Work center clicked :"+hm.get(workCenter)+ common.captureScreenshot(ScreenshotRequire));

				common.isElementDisplayed(driver, btnoffHold, IConstants.HIGH_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - the offhold button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
				common.clickOnObject(btnoffHold,"btnoffHold");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(8000);
				System.out.println("Verified - off-hold button clicked");
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - off-hold button clicked"+ common.captureScreenshot(ScreenshotRequire));

				System.out.println("Workcenter status after off-hold is:"+ WipOrderStatusGT.getText());

				//Assert.assertEquals(WipOrderStatusGT.getText(), "Started","Order status is not correct in general tab");
				String [] splits4=common.splitValues(leftPanelLine.get(0).getText(),"\\(");
				String [] splits5=common.splitValues(splits4[1].trim(),"\\)");
				System.out.println("status " + splits5[0].trim());

				Assert.assertTrue(leftPanelLine.get(workCenter).getText().contains("Off-Hold"),"work center status is not correct");
				//WebTestCase.getTest().log(LogStatus.INFO, "Work Center Header status:"+leftPanelLine.get(0).getAttribute("innerHTML"));
				int i=0;
				for(i=1;i<leftPanelLine.size();i++) {				
					//if(((leftPanelLine.get(i).getAttribute("innerHTML").contains("Started")))) {
						System.out.println("Work Center list "+leftPanelLine.get(i).getAttribute("innerHTML"));
						WebTestCase.getTest().log(LogStatus.INFO, "Work Center list after clicked on off-hold button"+leftPanelLine.get(i).getAttribute("innerHTML"));
						//Assert.assertEquals(leftPanelLine.get(i).getAttribute("innerHTML").substring(9,16).trim(), oStatus, "status of "+leftPanelLine.get(i).getAttribute("innerHTML").substring(1,6).trim()+ " is not displaying correctly.");
					//}
				}
				
				///verify started orders
				
				common.clickOnObject(leftPanelLine.get(workCenter), "workcenter");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(4000);
				WebTestCase.getTest().log(LogStatus.INFO, "Work center clicked :"+hm.get(workCenter)+ common.captureScreenshot(ScreenshotRequire));

				common.isElementDisplayed(driver, btnStart, IConstants.HIGH_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - the start button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
				common.clickOnObject(btnStart,"btnStart");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(8000);
				System.out.println("Verified - Start button clicked");
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - start button clicked"+ common.captureScreenshot(ScreenshotRequire));

				System.out.println("Workcenter status after start:"+ WipOrderStatusGT.getText());

				//Assert.assertEquals(WipOrderStatusGT.getText(), "Started","Order status is not correct in general tab");
				String [] splits6=common.splitValues(leftPanelLine.get(0).getText(),"\\(");
				String [] splits7=common.splitValues(splits6[1].trim(),"\\)");
				System.out.println("status " + splits6[0].trim());

				Assert.assertTrue(leftPanelLine.get(workCenter).getText().contains("Started"),"work center status is not correct");
				//WebTestCase.getTest().log(LogStatus.INFO, "Work Center Header status:"+leftPanelLine.get(0).getAttribute("innerHTML"));
				for(int j=1;j<leftPanelLine.size();j++) {				
					if(((leftPanelLine.get(j).getAttribute("innerHTML").contains("Started")))) {
						System.out.println("Work Center list "+leftPanelLine.get(j).getAttribute("innerHTML"));
						WebTestCase.getTest().log(LogStatus.INFO, "Work Center list after clicked on stated button"+leftPanelLine.get(j).getAttribute("innerHTML"));
						//Assert.assertEquals(leftPanelLine.get(i).getAttribute("innerHTML").substring(9,16).trim(), oStatus, "status of "+leftPanelLine.get(i).getAttribute("innerHTML").substring(1,6).trim()+ " is not displaying correctly.");
					}
				}

				//Assert.assertEquals(counter1, 5, "status of "+leftPanelLine.get(counter1).getAttribute("innerHTML")+ " is not displaying correctly.");


			
			}else {
				WebTestCase.getTest().log(LogStatus.INFO, "Work Center list is not coming as started instead coming as: "+leftPanelLine.get(workCenter).getText()+ common.captureScreenshot(ScreenshotRequire));
			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return NewNCCount;

	}

	/**
	 * Method To validate Left Panel Order Details Started
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public int validateLeftPanelOrderDetailsStarted(String oId,String oStatus,String oLine,String wc,HashMap<Integer,String> hm, String ScreenshotRequire) throws InterruptedException{
		int NewNCCount=0;
		int workCenter=Integer.parseInt(wc);


		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertTrue(WipOrderStatusGT.isEnabled(),  "Order status is not displayed");
			Assert.assertEquals(WipOrderStatusGT.getText(), oStatus,"Order status is not correct in general tab");
			System.out.println("wc header actual:"+ dataLevel0.getAttribute("innerHTML"));

			for(int i=1;i<leftPanelLine.size();i++) {
				if((leftPanelLine.get(i).getAttribute("innerHTML").contains(hm.get(i+1))&&((leftPanelLine.get(i).getAttribute("innerHTML").contains(oStatus))))) {
					System.out.println("Initial work Center list:"+leftPanelLine.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "Initial work Center list:"+leftPanelLine.get(i).getAttribute("innerHTML"));
				}
			}
			common.clickOnObject(leftPanelLine.get(workCenter), leftPanelLine.get(workCenter).getText());
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(4000);
			WebTestCase.getTest().log(LogStatus.INFO, "Work center clicked :"+hm.get(workCenter));

			Assert.assertTrue(btnStart.isEnabled(),  "Start  button not enabled");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - the Start button is enabled as expected");
			common.clickOnObject(btnStart,"btnStart");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Thread.sleep(10000);
			common.isElementDisplayed(driver, WipOrderStatusGT, IConstants.HIGH_WAIT_TIME);
			System.out.println("Verified - Start button clicked");
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - Start button clicked");
			System.out.println("wc header after start:"+ webCenterStatus.get(0).getAttribute("innerHTML"));
			Thread.sleep(5000);
			/*for(int i=1;i<leftPanelLine.size();i++) {
				System.out.println("Work center list after start:"+webCenterStatus.get(i).getAttribute("innerHTML"));
				WebTestCase.getTest().log(LogStatus.INFO, "Work Center list after start:"+webCenterStatus.get(i).getAttribute("innerHTML"));

			}*/
			WebTestCase.getTest().log(LogStatus.PASS, "Start button clicked"+ common.captureScreenshot("true"));
			Assert.assertEquals(WipOrderStatusGT.getText(), "Started","Order status is not correct in general tab");
			for(int i=1;i<=5;i++) {

				if(i>=(workCenter+1))
				{
					if(((leftPanelLine.get(i).getAttribute("innerHTML").contains("Started")))) {

						System.out.println("Work Center list "+leftPanelLine.get(i).getAttribute("innerHTML"));
						WebTestCase.getTest().log(LogStatus.INFO, "Work Center list verification: "+leftPanelLine.get(i).getAttribute("innerHTML"));
						Assert.assertEquals(leftPanelLine.get(i).getAttribute("innerHTML").substring(9,16).trim(), "Started", "status of "+leftPanelLine.get(i).getAttribute("innerHTML").substring(1,6).trim());
					}
				}else {
					if(((leftPanelLine.get(i).getAttribute("innerHTML").contains("Started")))) {
						System.out.println("Work Center list verification "+leftPanelLine.get(i).getAttribute("innerHTML"));
						WebTestCase.getTest().log(LogStatus.INFO, "Work Center list verification: "+leftPanelLine.get(i).getAttribute("innerHTML"));
					}else {
						WebTestCase.getTest().log(LogStatus.INFO, "Work Center list verification: "+leftPanelLine.get(i).getAttribute("innerHTML"));

					}
				}
			}



		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return NewNCCount;

	}

	public String ValidateWorkCenterAndOperation(String[][] hm2,int rowCount, String ScreenshotRequire){
		String img=common.captureScreenshot(ScreenshotRequire);
		try{
			common.switchToFrame(By.xpath(iframepage), 80);	
			Common.isElementDisplayed(driver, ContainerTreeData, 100);

			System.out.println("ValidateWorkCenterAndOperation");
			for (int i = 0; i < rowCount; i++) {

				// Loop through all elements of current row 
				for (int j = 0; j < hm2[i].length; j++) {
					System.out.print(hm2[i][j] + " ");
				}
				System.out.println();
			}
			Thread.sleep(4000);
			Common.isElementDisplayed(driver, ExpandIconOpenList.get(0), 100);
			common.clickOnObject(ExpandIconOpenList.get(0),ExpandIconOpenList.get(0).getText());
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			Thread.sleep(2000);

			Common.isElementDisplayed(driver, ExpandIconClose, 100);
			common.clickOnObject(ExpandIconClose,"ExpandIconClose");
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			Thread.sleep(2000);

			WebTestCase.getTest().log(LogStatus.PASS, "clicked on level 0:"+ common.captureScreenshot(ScreenshotRequire));



			int i=0;
			for (int j = 0; j < rowCount; j++) {
				if((leftPanelLineLevel1.get(j).getAttribute("innerHTML").toLowerCase().contains((hm2[j][i]).toLowerCase()))) {
					System.out.println(leftPanelLineLevel1.get(j).getAttribute("innerHTML")+"---"+hm2[j][i]);
					WebTestCase.getTest().log(LogStatus.PASS, "Level 1 Operation verification on online and Global file :" +leftPanelLineLevel1.get(j).getAttribute("innerHTML")+"***"+hm2[j][i]);
					// test for fabrication only
					System.out.println("work center value:  "+ hm2[j][i]);
					if(hm2[j][i].contains("Outer Door")) {
						common.clickOnObject(FBODIcon,"FBODIcon");
					}else {
						driver.findElement(By.xpath(".//td[contains(@data-value,'"+hm2[j][i]+"')]//span[contains(@class,'ExpandIcon')]")).click();
					}Thread.sleep(4000);
					for(int k=0;k<TreeStructureLevel2.size();k++) {	
						if((TreeStructureLevel2.get(k).getAttribute("innerHTML").toLowerCase().contains((hm2[j][k+1]).toLowerCase()))) {
							System.out.println(TreeStructureLevel2.get(k).getAttribute("innerHTML")+"***"+hm2[j][k+1]);
							WebTestCase.getTest().log(LogStatus.PASS, "Level 2 Operation verification on online and Global file:"+TreeStructureLevel2.get(k).getAttribute("innerHTML")+"---"+hm2[j][k+1]+ common.captureScreenshot(ScreenshotRequire));
						}
						//WebTestCase.getTest().log(LogStatus.PASS, "Total Operations online is: "+TreeStructureLevel2.size());
					}
					if(hm2[j][i].contains("Outer Door")) {
						//driver.findElement(By.xpath("//td[contains(@data-value,'FBOD')]//span[contains(@class,'ExpandIcon')]")).click();
						driver.findElement(By.xpath(".//td[contains(@data-value,'"+hm2[j][i]+"')]//span[contains(@class,'ExpandIcon')]")).click();
					}else {
						driver.findElement(By.xpath(".//td[contains(@data-value,'"+hm2[j][i]+"')]//span[contains(@class,'ExpandIcon')]")).click();
					}
					Thread.sleep(2000);

				}

			}
			img=common.captureScreenshot(ScreenshotRequire);			
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}

	/**
	 * Method To validate Status Details
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateStatusDetails(String statusField, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		System.out.println("inside validateStatusDetails function");
		Assert.assertEquals(driver.findElement(By.xpath(".//span[text()='"+statusField+"']")).getText(),statusField,"Expected order number is not appearing on order operation page");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Status id - "+statusField+ " - is displayed successfuly in Operation page"+ common.captureScreenshot(ScreenshotRequire));
		driver.switchTo().defaultContent();
	}

	public void validateFooterButtons(String ScreenshotRequire){
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		System.out.println("inside validateFooterButtons function");
		int Fsize= footerBtnList.size();
		for(int i=0;i<Fsize;i++) {
			if(footerBtnList.get(i).getText().contains("Hold")){
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - the hold button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
			}
			else{
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - the hold button is disabled as expected"+ common.captureScreenshot(ScreenshotRequire));	
			}	
		}
		if(btnHold1.isEnabled()){
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the hold button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
		}
		else{
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the hold button is disabled as expected"+ common.captureScreenshot(ScreenshotRequire));	
		}
		//btnSave
		if(btnSave1.isEnabled()){
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Save button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
		}
		else{
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Save button is disabled as expected"+ common.captureScreenshot(ScreenshotRequire));	
		}
		//btnStart
		if(btnStart1.isEnabled()){
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Start button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
		}
		else{
			WebTestCase.getTest().log(LogStatus.INFO, "Verified - the Start button is disabled as expected"+ common.captureScreenshot(ScreenshotRequire));	
		}
		driver.switchTo().defaultContent();
	}
	
	/**
	 * Method To  compare buttons
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void validateFooterButtonsWithStatus(String Status,HashMap<Integer,String> hmAction,String ScreenshotRequire) throws InterruptedException{
		//String TotalPOERecords=null;
		try{
			System.out.println("inside validateFooterButtonsWithStatus function for ");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			
				for (int i = 0; i < footerBtn.size(); i++) {
					Thread.sleep(4000);
					if((footerBtn.get(i).getAttribute("innerText").toLowerCase().trim().contains(hmAction.get(i+1).toLowerCase().trim()))) {
						WebTestCase.getTest().log(LogStatus.PASS, "Verified - Valid Footer Enabled Button List displayed for status : <b>"+Status+"<b/> is "+footerBtn.get(i).getAttribute("innerHTML")+ common.captureScreenshot(ScreenshotRequire));
					}else{
						WebTestCase.getTest().log(LogStatus.FAIL, "ORD screen Enabled Footer Buttons Expected "+" -- "+hmAction.get(i+1)+ " -- " + "  But UI appearing as  " +footerBtn.get(i).getText()+ common.captureScreenshot(ScreenshotRequire));	
					}
				}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	
	/**
	 * Method To  validateSerialNoCycleDetails
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public boolean validateSerialNoCycleDetails(String GoogSchQuantity, String ScreenshotRequire) throws InterruptedException{
		boolean flag=false;
		try{
			System.out.println("inside validateSerialNoCycleDetails function for ");
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			String tot= totalOrderRecord.getText();
			String [] splitsvalues=common.splitValues(tot,"\\:");
			int TotalSerialNumberRecords=Integer.parseInt(splitsvalues[1].trim());
			String [] expectedVal=common.splitValues(GoogSchQuantity,"\\:");
			int TotalGoodQty=Integer.parseInt(expectedVal[0].trim());
			int TotalScheQty=Integer.parseInt(expectedVal[1].trim());
			
			
			if(TotalSerialNumberRecords>0){
				Assert.assertEquals(TotalSerialNumberRecords, TotalScheQty,"Serial number list count is wrong");
				int counter=0;
				for (int i = 0; i < serialNoList.size(); i++) {
					String val= serialNoList.get(i).getText();
					String [] splitscyclevalues=common.splitValues(val,"\\:");
					int TotalCycleTime=Integer.parseInt(splitscyclevalues[0].trim())+Integer.parseInt(splitscyclevalues[1].trim())+Integer.parseInt(splitscyclevalues[2].trim());
					if(TotalCycleTime==0) {
						counter++;
					}
					if(counter>TotalGoodQty) {
						System.out.println("expected serial number list :: and actail list ::" + TotalGoodQty + " : "+counter);
						flag=false;
						WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Serial number cycle value is appearing incorrect.");
						break;
					}else {
						flag=true;
					}
					
				}
				if(flag) {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - Serial number cycle value is appearing correctly");
				}else {
					WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Serial number cycle values are incorrect, expected " +TotalGoodQty +" Actiual: "+ counter);
				}
			}else {
				flag=false;
				Assert.assertTrue(flag, "Serial number list is not appearing");
			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return flag;
	}

	/**
	 * Method To validate Left Panel Order Details Start and closed
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public int validateLeftPanelOrderDetailsStartAndClosed(String oId,String oStatus,HashMap<Integer,String> hm, String ScreenshotRequire) throws InterruptedException{
		int NewNCCount=0;
		System.out.println("inside validateLeftPanelOrderDetailsStartAndClosed function");

		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			Assert.assertTrue(WipOrderStatusGT.isEnabled(),  "Order status is not displayed correctly");
			Assert.assertTrue(dataLevel0.getAttribute("innerHTML").contains("Started"),"work center status is not correct");
			WebTestCase.getTest().log(LogStatus.INFO, "Initial work Center Header status:"+dataLevel0.getAttribute("innerHTML"));
			System.out.println("wc header actual:"+ dataLevel0.getAttribute("innerHTML"));

			for(int i=1;i<leftPanelLine.size();i++) {
				if((leftPanelLine.get(i).getAttribute("innerHTML").contains(hm.get(i+1)))) {
					System.out.println("Initial work Center list:"+leftPanelLine.get(i).getAttribute("innerHTML")+"---global file: "+hm.get(i+1));
					WebTestCase.getTest().log(LogStatus.INFO, "Initial work Center list:"+leftPanelLine.get(i).getAttribute("innerHTML"));
				}
			}
			if(leftPanelLine.get(0).getText().contains("Started")) {
				common.clickOnObject(leftPanelLine.get(0), "clicked on order");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(2000);
				Assert.assertTrue(btnClose.isEnabled(),  "Close  button not enabled");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - the Close button is enabled as expected"+ common.captureScreenshot(ScreenshotRequire));
				common.clickOnObject(btnClose,"btnClose");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				Thread.sleep(4000);
				System.out.println("Verified - Close button clicked");

				common.isElementDisplayed(driver, closedReasonCodes.get(0), IConstants.HIGH_WAIT_TIME);
				JavascriptExecutor js = (JavascriptExecutor)driver; 
				js.executeScript("arguments[0].click();", closedReasonCodes.get(0));
				Thread.sleep(10000);
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
				WebTestCase.getTest().log(LogStatus.INFO, "Verified - Clicked on closed PopUp Button"+ common.captureScreenshot(ScreenshotRequire));
				String [] splits1=common.splitValues(leftPanelLine.get(0).getText(),"\\(");
				String [] splits2=common.splitValues(splits1[1].trim(),"\\)");
				System.out.println("status:: " + splits2[0].trim());
				Assert.assertEquals(splits2[0].trim(),"Closed","work center status is not correct");
			}else {
				WebTestCase.getTest().log(LogStatus.INFO, "Work Center list is not coming as started instead, coming as: "+leftPanelLine.get(0).getText()+ common.captureScreenshot(ScreenshotRequire));
			}
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		driver.switchTo().defaultContent();
		return NewNCCount;

	}

}
