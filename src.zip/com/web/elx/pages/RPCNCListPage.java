package com.web.elx.pages;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.elx.common.Common;
import com.elx.helper.*;
import com.relevantcodes.extentreports.LogStatus;

public class RPCNCListPage {


	public WebDriver driver;
	private Common common;
	ReadConfig testData = new ReadConfig();
	SoftAssert softAssert = new SoftAssert();

	public RPCNCListPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}


	//NC Title
	@FindBy(xpath = "//li[@title='RPC-010']")
	private WebElement ncTitle;

	//NC Textbox
	@FindBy(xpath = "//input[@data-field='ncno']")
	private WebElement ncTextbox;

	@FindBy(xpath = ".//input[contains(@class,'SerialNo')]")
	private WebElement SerialNo;

	@FindBy(xpath = ".//input[@data-field='serialno']")
	private WebElement serialnoInput;

	@FindBy(xpath = ".//td[@data-field='serialno']//span[@class='display']")
	private List <WebElement> serialnoDisplay;

	@FindBy(xpath = ".//input[@class='filter multifiltervalue active']")
	private WebElement statusTestBox;

	@FindBy(xpath = ".//input[@class='datetime filter active k-input']")
	private WebElement createdOnTextBox;

	@FindBy(xpath = ".//input[@data-field='createdbylist']")
	private WebElement createdByTextBox;


	@FindBy(xpath = ".//td[@data-field='statuslist']//a")
	private WebElement statuslistIcon;

	@FindBy(xpath = ".//td[@data-field='productionlinenolist']//a")
	private WebElement productionlinenolist;



	@FindBy(xpath = ".//div[@class='Total']")
	private WebElement totalOrderRecord;

	@FindBy(xpath = "//*[contains(@data-field,'createdonlist') and contains(@placeholder,'From')]")
	private  WebElement createdonlistFrom	;

	@FindBy(xpath = ".//div[@class='Container vpBody']//tr[2]/td")
	private List <WebElement> ncFirstRowdetails;

	@FindBy(xpath = ".//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//button[contains(@title,'deselect all') and not (contains(@style,'cursor: auto'))]")
	private WebElement deselectAllSelectedBtn;

	@FindBy(xpath = ".//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//button[contains(@title,'Remove selected') and not (contains(@style,'cursor: auto'))]")
	private WebElement removeSelectedBtn;


	@FindBy(xpath = "(//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//div[contains(@class,'vpBody')])[2]")
	private WebElement leftSideDivPanel;

	@FindBy(xpath = ".//div[contains(@class,'ui-dialog ui-widget') and (contains(@style,'display: block'))]//span[contains(text(),'OK')]")
	private WebElement okBtn;

	@FindBy(xpath = ".//input[@data-field='workcenterlist']")
	private WebElement workcenterlist;


	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	/**
	 * Method To validate NC List Page Title
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public void validateRPCNCListPageTitle(String title, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
		Common.isElementDisplayed(driver, ncTitle, IConstants.LOW_WAIT_TIME);
		System.out.println("inside validateRPCNCListPageTitle function");
		driver.switchTo().defaultContent();
		Assert.assertEquals(ncTitle.getText(), title,"Repair Non-Conformity List page title is not appearing correctly");
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Repair Non-Conformity List page loaded: Title is:"+ncTitle.getText()+ common.captureScreenshot(ScreenshotRequire));
	}
	/**
	 * Method To validate Nc Details On Nc List Page
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String validateNcDetailsOnNcListPage( Hashtable<String, String> data,  String ncID, String ScreenshotRequire){	
		System.out.println("inside validate NC details");
		String ncNumber=null;
		try
		{

			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			/*Common.isElementDisplayed(driver, createdOnTextBox, IConstants.SYS_WAIT_TIME);
			common.clickOnObject(createdOnTextBox,"statusTestBox");
			createdOnTextBox.clear();*/
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalPOERecords=splitsvalues[1].trim();
			if(Integer.parseInt(TotalPOERecords)>0) {
				ncNumber=ncFirstRowdetails.get(1).getText();
				String ncStatus=ncFirstRowdetails.get(7).getText();
				Assert.assertEquals(ncFirstRowdetails.get(12).getText(), data.get("WorkCenter"),"Work center details are not coming correctly in RPC NC list page");
				if(ncStatus.contains("New")) {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - Clicked on NC: "+ncNumber+ common.captureScreenshot(ScreenshotRequire));
					common.clickOnObject(ncFirstRowdetails.get(6), "Details Button");
					System.out.println("clicked on order: "+ncNumber );
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );

				}
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Total record is 0 in RPC list page."+ common.captureScreenshot(ScreenshotRequire));
			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return ncNumber;
	}


	/**
	 * Method To validate completed Nc Details On Nc List Page
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String validateCompletedNCDetailsOnRPCPage(String ncNum, String ScreenshotRequire){	
		System.out.println("inside validateCompletedNCDetailsOnRPCPage details");
		String ncNumber=null;
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Common.isElementDisplayed(driver, statuslistIcon, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(statuslistIcon,"statusListIcon");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );

			Common.isElementDisplayed(driver, deselectAllSelectedBtn, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(deselectAllSelectedBtn,"deselectAllSelectedBtn");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );

			if(removeSelectedBtn.isEnabled()) {
				common.clickOnObject(removeSelectedBtn,"removeSelectedBtn");
				common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			}

			if(leftSideDivPanel.getAttribute("innerText").length()==0) {
				System.out.println("value removed from popup window");
				if(okBtn.isEnabled()) {
					common.clickOnObject(okBtn,"okBtn");
					System.out.println("ok button clicked");
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
					Thread.sleep(8000);
				}
			}
			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalPOERecords=splitsvalues[1].trim();
			if(Integer.parseInt(TotalPOERecords)>0) {

				if(ncTextbox.getText()==null) {
					Common.isElementDisplayed(driver, ncTextbox, IConstants.SYS_WAIT_TIME);
					common.setObjectValue(ncTextbox, "ncTextbox", ncNum);
					ncTextbox.sendKeys(Keys.ENTER);
					Thread.sleep(20000);
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
				}
				ncNumber=ncFirstRowdetails.get(1).getText();
				String ncStatus=ncFirstRowdetails.get(7).getText();
				System.out.println("ncNumber in RPC "+ ncNumber);

				Assert.assertEquals(ncNumber, ncNum,  "NC Number is not displayed correctly.");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC Number is displayed as expected"+ common.captureScreenshot(ScreenshotRequire));

				Assert.assertEquals(ncStatus, "Closed",  "NC status is not displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - NC status is displayed as expected: "+ncStatus+ common.captureScreenshot(ScreenshotRequire));

			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Total record is 0 in RPC list page."+ common.captureScreenshot(ScreenshotRequire));

			}
			driver.switchTo().defaultContent();


		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return ncNumber;
	}
	/**
	 * Method To search Nc Details On Nc List Page
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String searchNcDetailsOnNcListPage( Hashtable<String, String> data,  String ncID, String serialNumber,String workcenter, String ScreenshotRequire){	
		System.out.println("inside searchNcDetailsOnNcListPage function, serial number: "+ serialNumber);
		String ncNumber=null;
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			/*Common.isElementDisplayed(driver, createdOnTextBox, IConstants.SYS_WAIT_TIME);
			common.clickOnObject(createdOnTextBox,"statusTestBox");
			createdOnTextBox.clear();*/
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );

			Common.isElementDisplayed(driver, workcenterlist, IConstants.SYS_WAIT_TIME);
			if(workcenterlist.getAttribute("value").contains(workcenter)) {
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - WorkCenter details "+workcenterlist.getAttribute("value")+ common.captureScreenshot(ScreenshotRequire));
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Workcenter details appearing incorrect "+workcenterlist.getAttribute("value")+ common.captureScreenshot(ScreenshotRequire));
			}
			Common.isElementDisplayed(driver, SerialNo, IConstants.SYS_WAIT_TIME);
			common.setObjectValue(SerialNo, "SerialNo", serialNumber);
			SerialNo.sendKeys(Keys.ENTER);
			Thread.sleep(15000);
			Assert.assertEquals(serialnoInput.getAttribute("value").trim(),serialNumber.trim(),"serial number is not matching");
			String [] values=common.splitValues(totalOrderRecord.getText(),"\\:");
			String RPCRecords=values[1].trim();
			if(Integer.parseInt(RPCRecords)>0) {
				for(int i=0;i<serialnoDisplay.size();i++) {
					softAssert.assertTrue(serialnoDisplay.get(i).getText().contains(serialNumber),"Serial number is not matching");
					//WebTestCase.getTest().log(LogStatus.PASS, "Verified - Serial number is matching in the order details"+ common.captureScreenshot());
				}
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, "Verified - Serial number is not matching in the order details"+ common.captureScreenshot(ScreenshotRequire));

			}

			Common.isElementDisplayed(driver, ncTextbox, IConstants.SYS_WAIT_TIME);
			common.setObjectValue(ncTextbox, "ncTextbox", ncID);
			//ncTextbox.sendKeys(Keys.ENTER);
			Thread.sleep(20000);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );
			System.out.println("NC ID entered: "+ncID );

			String [] splitsvalues=common.splitValues(totalOrderRecord.getText(),"\\:");
			String TotalRPCRecords=splitsvalues[1].trim();
			if(Integer.parseInt(TotalRPCRecords)>0) {

				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				Date date = new Date();
				String time = sdf.format(date);
				System.out.println(time);

				/*String previousDateStringval=DateString(time)+" "+"12:00:00 AM";
			    JavascriptExecutor js = (JavascriptExecutor)driver; 	
				js.executeScript("arguments[0].scrollIntoView();",createdonlistFrom);
				Thread.sleep(5000);

			    createdonlistFrom.click();
			    Thread.sleep(5000);
				common.setObjectValue(createdonlistFrom, "createdonlistFrom", previousDateStringval);
				createdonlistFrom.sendKeys(Keys.TAB);
				Thread.sleep(15000);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - created on date entered"+ common.captureScreenshot(ScreenshotRequire));
				 */
				ncNumber=ncFirstRowdetails.get(1).getText();
				String ncCreatedDate=ncFirstRowdetails.get(8).getText();
				Assert.assertTrue(ncCreatedDate.contains(DateString(time)), "created date is not apeparing correctly");
				String ncStatus=ncFirstRowdetails.get(7).getText();
				Assert.assertTrue(ncFirstRowdetails.get(12).getText().contains(workcenter),"Work center details are not coming correctly in RPC NC list page");
				if(ncStatus.contains("New")) {
					WebTestCase.getTest().log(LogStatus.PASS, "Verified - Clicked on NC: "+ncNumber+ common.captureScreenshot(ScreenshotRequire));
					common.clickOnObject(ncFirstRowdetails.get(6), "Details Button");
					System.out.println("clicked on order: "+ncNumber );
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );

				}
			}else {
				WebTestCase.getTest().log(LogStatus.PASS, "Total record is 0 in RPC list page."+ common.captureScreenshot(ScreenshotRequire));
			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return ncNumber;
	}
	public static String DateString(String dateString)
			throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

		Date myDate = dateFormat.parse(dateString);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(myDate);
		calendar.add(Calendar.DAY_OF_YEAR, 0);

		Date previousDate = calendar.getTime();
		String result = dateFormat.format(previousDate);

		return result;
	}

}
