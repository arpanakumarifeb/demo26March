package com.web.elx.pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import com.elx.common.Common;
import com.elx.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;


public class SearchPage {

	@FindBy(xpath = ".//li[@class='appbar-menu-item apr-searchbox-container']//input")
	private WebElement search;

	//@FindBy(xpath = "//input[@placeholder='Find a screen...'])[1]//..//../div/div[2])[1]")
	@FindBy(xpath = "((//input[@placeholder='Find a screen...'])[1]//..//../div/div[2])[1]")
	private WebElement searchItem;

	@FindBy(xpath = "//h3//span[contains(text(),'Recently used')]")
	private WebElement se;

	@FindBy(xpath = "//h3[@class='subheader underlined section-header-font collapse-hide']//i[@class='fa collapse-button']")
	private WebElement showAll;


	@FindBy(xpath = ".//span[@class='toggle-user']")
	private WebElement toggleUser;

	@FindBy(xpath = ".//span[@apr-localize='PERSONALIZATION.LOGOUT']")
	private WebElement logout;
	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";


	private WebDriver driver;
	private Common common;

	public SearchPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}

	/*public String searchWith(String val) throws InterruptedException{
		Common.isElementDisplayed(driver, search, 80);
		String img=common.captureScreenshot();
		Assert.assertTrue(search.isDisplayed());
		search.clear();
		search.sendKeys(val);
		return img;
	}
	public String clickOnSearchItem(){
		Common.isElementDisplayed(driver, searchItem, 80);
		String img=common.captureScreenshot();
		searchItem.click();
		return img;
	}
	public String clickOnSearchItem1(){

		//common.scrollIntoViewPage(se);
		Common.isElementDisplayed(driver, se, 80);
		String img=common.captureScreenshot();
		se.click();
		return img;
	}*/

	/*public String clickOnShowAll(){

		Common.isElementDisplayed(driver, showAll, 80);
		WebTestCase.getTest().log(LogStatus.INFO, "Verify the Show All icon is present");
		String img=common.captureScreenshot();
		showAll.click();
		return img;
	}*/
	/**
	 * Method To click On Delmia Apriso Portal Item
	 * @author Arpana
	 * @throws InterruptedException
	 */
	public String clickOnDelmiaAprisoPortalItem(String val,String ScreenshotRequire) throws InterruptedException{
		String img=common.captureScreenshot(ScreenshotRequire);
		try{
			System.out.println("clickOnDelmiaAprisoPortalItem method : selecting icon "+val);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME );	
			Thread.sleep(4000);
			WebElement searchOption=driver.findElement(By.xpath("//div[contains(text(),'"+val+"')]"));
			if(searchOption.isDisplayed()) {
				WebTestCase.getTest().log(LogStatus.INFO, "Verified the " +val +" item is present");
				common.highLighterMethod(driver,searchOption);
				common.clickOnObject(searchOption,searchOption.getText());
				common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
			}else {
				Common.isElementDisplayed(driver, search, IConstants.MEDIUM_WAIT_TIME);
				search.clear();
				search.sendKeys(val);
				WebTestCase.getTest().log(LogStatus.INFO, "Verified the " +val +" item has appeared on search and click");
			}

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}


	/*public String clickOnUserIcon(){

		Common.isElementDisplayed(driver, toggleUser, 80);
		WebTestCase.getTest().log(LogStatus.INFO, "Verify the toggleUser icon is present"+common.captureScreenshot());
		common.clickOnObject(toggleUser,toggleUser.getText());
		common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
		common.clickOnObject(logout,logout.getText());
		common.waitTillElementDisappears(By.xpath(toolbox),IConstants.HIGH_WAIT_TIME);
		return common.captureScreenshot();
	}
*/

}
