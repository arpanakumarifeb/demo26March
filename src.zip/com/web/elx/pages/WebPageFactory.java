package com.web.elx.pages;

import org.openqa.selenium.WebDriver;

public class WebPageFactory {

	/**
	 * @return the elxLogin
	 */
	public AprisoLoginPage getElxLogin() {
		return elxLogin;
	}
	/**
	 * @param elxLogin the elxLogin to set
	 */
	public static void setElxLogin(AprisoLoginPage elxLogin) {
		WebPageFactory.elxLogin = elxLogin;
	}
	private static AprisoLoginPage elxLogin=null;
	
	/**
	 * @return the aprisoCommon
	 */
	public AprisoCommonPage getAprisoCommonPage() {
		return aprisoCommonPage;
	}
	/**
	 * @param AprisoCommonPage the AprisoCommonPage to set
	 */
	public static void setAprisoCommon(AprisoCommonPage aprisoCommonPage) {
		WebPageFactory.aprisoCommonPage = aprisoCommonPage;
	}
	private static AprisoCommonPage aprisoCommonPage=null;
	
	
	/**
	 * @return the createNC
	 */
	public CreateNCPage getCreateNC() {
		return createNC;
	}
	/**
	 * @param createNC the createNC to set
	 */
	public static void setCreateNC(CreateNCPage createNC) {
		WebPageFactory.createNC = createNC;
	}
	private static CreateNCPage createNC= null;
	
	/**
	 * @return the orderExecution
	 */
	public OrderExecutionPage getOrderExecution() {
		return orderExecution;
	}
	/**
	 * @param orderExecution the orderExecution to set
	 */
	public static void setOrderExecution(OrderExecutionPage orderExecution) {
		WebPageFactory.orderExecution = orderExecution;
	}
	private static OrderExecutionPage orderExecution=null;
	/**
	 * @return the workAreaPage
	 */
	public WorkAreaSelectionPage getWorkAreaPage() {
		return workAreaPage;
	}
	/**
	 * @param workAreaPage the workAreaPage to set
	 */
	public static void setWorkAreaPage(WorkAreaSelectionPage workAreaPage) {
		WebPageFactory.workAreaPage = workAreaPage;
	}
	private static WorkAreaSelectionPage workAreaPage= null;
	
	
//************************************
/**
 * @return the orderCockpitPage
 */
public OrderCockpitPage getOrderCockPage() {
	return orderCockPage;
}
/**
 * @param OrderCockpitPage the OrderCockpitPage to set
 */
public static void setOrderCockPage(OrderCockpitPage orderCockPage) {
	WebPageFactory.orderCockPage=orderCockPage;
}
public static OrderCockpitPage orderCockPage= null;

//************
/**
 * @return the ORD20Page
 */
public ORD20Page getORD20() {
	return oRD20;
}
/**
 * @return the operatorConsole
 */

public OperatorConsolePage getOperatorConsole() {
	return operatorConsole;
}

public static void setOperatorConsole(OperatorConsolePage operatorExecution) {
	WebPageFactory.operatorConsole = operatorConsole;
}
private static OperatorConsolePage operatorConsole=null;
/**
 * @param ORD20Page the ORD20Page to set
 */
public static void setORD20(ORD20Page oRD20) {
	WebPageFactory.oRD20=oRD20;
}
public static ORD20Page oRD20= null;


//************************
/**
* @return the ORD20Page
*/
public HelpPOPage getHelpPO() {
	return helpPO;
}
/**
* @param ORD20Page the ORD20Page to set
*/
public static void setHelpPO(HelpPOPage helpPO) {
	WebPageFactory.helpPO=helpPO;
}
public static HelpPOPage helpPO= null;

//*********************
/**
* @return the HelpResolvefromNCM
*/
public HelpResolvefromNCM getHelpResolve() {
	return helpResolve;
}
/**
* @param ORD20Page the ORD20Page to set
*/
public static void setHelpResolve(HelpResolvefromNCM helpResolve) {
	WebPageFactory.helpResolve=helpResolve;
}
public static HelpResolvefromNCM helpResolve= null;

//*************
/**
* @return the CancelNCPage
*/
public CancelNCPage getCancelNCPage() {
	return cancelNC;
}
/**
* @param CancelNCPage to set
*/
public static void setCancelNCPage(CancelNCPage cancelNC) {
	WebPageFactory.cancelNC=cancelNC;
}
public static CancelNCPage cancelNC= null;



	/**
	 * @return the searchPage
	 */
	
	
	public SearchPage getSearchPage() {
		return searchPage;
	}
	/**
	 * @param searchPage the searchPage to set
	 */
	public static void setSearchPage(SearchPage searchPage) {
		WebPageFactory.searchPage = searchPage;
	}
	private static SearchPage searchPage=null;
	
	
	/**
	 * @return the dashboardLine
	 */
	public DashboardLinePage getDashboardLine() {
		return dashboardLine;
	}
	/**
	 * @param dashboardLine the dashboardLine to set
	 */
	public static void setDashboardLine(DashboardLinePage dashboardLine) {
		WebPageFactory.dashboardLine = dashboardLine;
	}
	private static DashboardLinePage dashboardLine=null;
	

	/**
	 * @return the orderCockpitExecution
	 */
	
	
	public WebPageFactory(WebDriver driver) {
		instance(driver);
	}
	public static void instance(WebDriver driver){ 
			elxLogin = new AprisoLoginPage(driver);
			searchPage = new SearchPage(driver);
			workAreaPage = new WorkAreaSelectionPage(driver);
		
			orderExecution = new OrderExecutionPage(driver);
			createNC = new CreateNCPage(driver);
			orderCockPage = new OrderCockpitPage(driver);
			oRD20 = new ORD20Page(driver);
			helpPO = new HelpPOPage(driver);
			helpResolve = new HelpResolvefromNCM(driver);
			dashboardLine = new DashboardLinePage(driver);
			
			operatorReasonPage = new OperatorReasonPage(driver);
			
			operatorConsole= new OperatorConsolePage(driver);
			
			cancelNC = new CancelNCPage(driver);
			orderOperationPage  = new OrderOperationPage(driver);
			aprisoCommonPage = new AprisoCommonPage(driver);
			ncListPage=new NCListPage(driver);
			ncInfoPage=new NCInfoPage(driver);
			mcsPage=new MCSPage(driver);
			buildPalletPage=new BuildPalletPage(driver);
			rpcNCListPage=new RPCNCListPage(driver);
		
		
	}
	
	/**
	 * @return the aprisoCommon
	 */
	public OrderOperationPage getOrderOperationPage() {
		return orderOperationPage;
	}
	/**
	 * @param AprisoCommonPage the AprisoCommonPage to set
	 */
	public static void setOrderOperationPage(OrderOperationPage orderOperationPage) {
		WebPageFactory.orderOperationPage = orderOperationPage;
	}
	private static OrderOperationPage orderOperationPage=null;
	
	
//
	
	/**
	 * @return the aprisoCommon
	 */
	public NCListPage getNCListPage() {
		return ncListPage;
	}
	/**
	 * @param AprisoCommonPage the AprisoCommonPage to set
	 */
	public static void setNCListPage(NCListPage ncListPage) {
		WebPageFactory.ncListPage = ncListPage;
	}
	private static NCListPage ncListPage=null;
	
	
	
	/**
	 * @return the aprisoCommon
	 */
	public NCInfoPage getNCInfoPage() {
		return ncInfoPage;
	}
	/**
	 * @param AprisoCommonPage the AprisoCommonPage to set
	 */
	public static void setNCInfoPage(NCInfoPage ncInfoPage) {
		WebPageFactory.ncInfoPage = ncInfoPage;
	}
	private static NCInfoPage ncInfoPage=null;

	

	/**
	 * @return the operatorReason
	 */
	public OperatorReasonPage getOperatorReasonPage() {
		return operatorReasonPage;
	}
	/**
	 * @param OperatorReasonPage the OperatorReasonPage to set
	 */
	public static void setOperatorReasonPage(OperatorReasonPage operatorReasonPage) {
		WebPageFactory.operatorReasonPage = operatorReasonPage;
	}
	
	
	private static OperatorReasonPage operatorReasonPage=null;
	
	
	/**
	 * @return the aprisoCommon
	 */
	public MCSPage getMCSPage() {
		return mcsPage;
	}
	/**
	 */
	public static void setMCSPage(MCSPage mcsPage) {
		WebPageFactory.mcsPage = mcsPage;
	}
	private static MCSPage mcsPage=null;
	
	
	
	/**
	 * @return the elxbuildpallet
	 */
	public BuildPalletPage getBuildPallet() {
		return buildPalletPage;
	}
	/**
	 * @param elxbuildpallet the elxbuildpallet to set
	 */
	public static void setBuildPallet(BuildPalletPage buildPalletPage) {
		WebPageFactory.buildPalletPage = buildPalletPage;
	}
	private static BuildPalletPage buildPalletPage=null;
	
	
	/**
	 * @return the elxRPCNCPage
	 */
	public RPCNCListPage getRPCNCList() {
		return rpcNCListPage;
	}
	/**
	 * @param rpcnclistpage the rpcnclistpage to set
	 */
	public static void setRPCNCList(RPCNCListPage rpcNCListPage) {
		WebPageFactory.rpcNCListPage = rpcNCListPage;
	}
	private static RPCNCListPage rpcNCListPage=null;
}