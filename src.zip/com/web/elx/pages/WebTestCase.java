package com.web.elx.pages;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.xml.sax.SAXException;

import com.elx.common.Common;
import com.elx.common.GetEnvValues;
import com.elx.core.IConstants;
import com.elx.core.util.WriteExcel;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.web.elx.pages.WebPageFactory;


//import junit.framework.TestCase;
import jxl.write.WritableWorkbook;

public class WebTestCase{
	protected static   WebDriver driver = null;
	//protected WebDriver driver = selenium.getDriver();
	private WritableWorkbook workbook;
	//private TestSession session;
	protected WebPageFactory pageFactory;
	public static ExtentReports extent;
	public static ExtentTest test;
	public static String result_FolderNamePath = ".//Reports/";
	public static String result_FolderNamePathLocal = "/Reports/";
	public static String result_FolderName = null;

	protected String browserValue=null;
	protected String enviornment=null;

	protected ITestContext testContextValue;

	protected GetEnvValues getenvvalues = null;
	private com.elx.common.ExcelManager xls = new com.elx.common.ExcelManager(System.getProperty("user.dir")
			+ "\\data\\" + this.getClass().getSimpleName() + ".xlsx");

	public WebTestCase() {
		//session = new TestSession();
		/* setDriver(driver);
        pageFactory = new WebPageFactory(driver);*/
	}
	@DataProvider(name = "inputdata")
	public Object[][] readExcelData(Method m) {
		Object[][] sheetData = null;

		sheetData = xls.getData1(m.getName(), "Test Data");
		return sheetData;
	}


	public void initilizeWebfactory(WebDriver driver)
	{
		pageFactory = new WebPageFactory(driver);
	}
	public WebDriver getDriver() {
		return driver;
	}
	//*****
	public static ExtentTest getTest() {
		return test;
	}
	/**
	 * @param test the test to set
	 */
	public static void setTest(ExtentTest test) {
		WebTestCase.test = test;
	}



	//****

	public void setDriver(WebDriver driver) {
		// super.setDriver(driver);
		WebTestCase.driver = driver;
	}
	public WritableWorkbook getWorkbook() {
		return workbook;
	}

	public void setWorkbook(WritableWorkbook workbook) {
		this.workbook = workbook;
	}

	/*public TestSession getSession() {
return session;
}

public void setSession(TestSession session) {
this.session = session;
}*/

	public WebPageFactory getPageFactory() {
		return pageFactory;
	}

	public void setPageFactory(WebPageFactory pageFactory) {
		this.pageFactory = pageFactory;
	}
	@BeforeSuite(alwaysRun = true)
	public void beforeSuite(){
		Reporter.log("*********************************************************",true);
		Reporter.log("*****************  Before Suite  *************************",true);
		int ss_path=Common.generateRandomIntIntRange(0,100);
		try {
			File directory = new File(System.getProperty("user.dir") +"/"+IConstants.SCREENSHOTS_LOCATION+"_"+ss_path );
			if (directory.exists()){
				FileUtils.cleanDirectory(new File(System.getProperty("user.dir") +"/"+IConstants.SCREENSHOTS_LOCATION+"_"+ss_path ));
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		} 

		//Date d = new Date();
		//String date = d.toString().replaceAll(" ", "_");
		//date = date.replaceAll(":", "_");
		//date = date.replaceAll("\\+", "_");
		//result_FolderName = result_FolderNamePath + date.substring(0, 10) + "/ELX_TEST_REPORT" + "_" + date;
		//new File(result_FolderName).mkdirs();
		//extent = new ExtentReports(createDir(result_FolderName)+"/ELXReport.html",true);

		Reporter.log("*********************************************************",true);
	}
	public static String createDir(String directoryName){
		File directory = new File(directoryName);
		if (! directory.exists()){
			directory.mkdir();
		}else{
			Reporter.log("Directory already exists..."+directory,true);
		}
		return directoryName;
	}

	@BeforeMethod(alwaysRun=true)
	public void beforeMethod(Method method){
		Reporter.log("*********************************************************",true);
		Reporter.log("*****************  Before Method  ************************",true);

		Date d = new Date();
		SimpleDateFormat ft = new SimpleDateFormat ("MM_dd_HH_mm_ss");
		System.out.println("Current Date: " + ft.format(d));
		String date = d.toString().replaceAll(" ", "_");
		date = date.replaceAll(":", "_");
		date = date.replaceAll("\\+", "_");
		result_FolderName = result_FolderNamePath + date.substring(0, 10) + "/"+method.getName()+"_"+date;
		new File(result_FolderName).mkdirs();
		extent = new ExtentReports(createDir(result_FolderName)+"/ELXReport"+ "_" +method.getName()+".html",true);

		synchronized (method) {
			try{
				test=extent.startTest(method.getName());
				test.assignAuthor("HCL");
				test.assignCategory("ELX TestReport-QA");
				setTest(test);	
			}
			catch(Exception e){

				System.out.println("error:" + e );
			}
			///new 
		}
		Reporter.log("*********************************************************",true);
	}
	@AfterClass
	public void aferClass(){
		Reporter.log("*********************************************************",true);
		Reporter.log("*****************  After Class  ************************",true);
		driver.quit();
		Reporter.log("*********************************************************",true);
		//  WriteExcel.getInstance().closeFile();
	}
	@AfterSuite
	public void closeBrowser() throws ParserConfigurationException, IOException, SAXException, InterruptedException {
		Reporter.log("*********************************************************",true);
		Reporter.log("*****************  After Suite  ************************",true);
		//extent.endTest(test);
		//extent.flush();
		//extent.close();
		Runtime.getRuntime().addShutdownHook(new Thread()
		{
			public void run()
			{
				try
				{
					Thread.sleep(5000);
					// ExcelReportGenerator.generateExcelReport("QAReports.xlsx",
					// ExcelReportGenerator.createDir(System.getProperty("user.dir")+"/Reports"));
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
				);
		if(driver!=null){
			driver.quit();

		}
		WriteExcel.getInstance();
		//WriteExcel.closeFile();
		Reporter.log("*********************************************************", true);
		//File sourceLocation = new File(result_FolderName+"/ELXReport.html");
		//File destinationLocation = new File(result_FolderNamePath+"/ElectroLuxReport.html");
		//FileUtils.copyFile(sourceLocation, destinationLocation);
	}
	@AfterMethod
	public void closeMenu(ITestResult result) {
		Reporter.log("*********************************************************",true);
		Reporter.log("*****************  After Method  ************************",true);
		if(result.getStatus()== ITestResult.FAILURE){
			//test.log(LogStatus.FAIL, "Test Case Failed is :"+result.getName());
			//test.log(LogStatus.FAIL, "Test Case Failed is :"+result.getThrowable().getMessage());
		}else  if(result.getStatus()== ITestResult.SKIP){
			//test.log(LogStatus.SKIP, "Test Case Skipped is :"+result.getName());
			//test.log(LogStatus.SKIP, "Test Case Skipped is :"+result.getThrowable().getMessage());
		}
		extent.endTest(test);
		extent.flush();
		Reporter.log("*********************************************************",true);
	}
}
