package com.elx.nc.junit.tests;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.TestCase;

public class JmeterSeleniumTest extends TestCase{
	
	@Test
	public void testJmeterSample() {
		
		System.setProperty("webdriver.chrome.driver","D:\\TSG\\POC\\ElectroLux\\latest_Code_9sep\\electrolux_test\\src\\main\\resources\\exe\\windowsdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://seleniumhq.org");
		assertTrue(driver.findElement(By.id("q")).isDisplayed());
		System.out.println("Successfully Executed......");
		
		driver.quit();
		
	}

}
