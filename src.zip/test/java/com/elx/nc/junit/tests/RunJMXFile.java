package com.elx.nc.junit.tests;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.Summariser;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.HashTree;

import com.elx.helper.CustomCSVReport;



public class RunJMXFile {
	public static void main(String[] args) throws IOException, InterruptedException {
		StandardJMeterEngine jmeter= new StandardJMeterEngine();
		//D:\TSG\POC\ElectroLux\apache-jmeter-4.0\bin
		//JMeterUtils.loadJMeterProperties(System.getProperty("user.dir")+"/src/main/resources/exe/apache-jmeter-3.2/bin/jmeter.properties");
		
		JMeterUtils.loadJMeterProperties("D:\\TSG\\POC\\ElectroLux\\apache-jmeter-4.0\\bin\\jmeter.properties");

		JMeterUtils.setJMeterHome("D:\\TSG\\POC\\ElectroLux\\apache-jmeter-4.0");
		JMeterUtils.initLocale();
		SaveService.loadProperties();
		File f = new File("D:\\TSG\\POC\\ElectroLux\\ElectroLuxJMX.jmx");
		HashTree testPlanTree= SaveService.loadTree(f);
		Summariser summer = null;
		String summariserName = JMeterUtils.getPropDefault(
		"summariser.name", "summary");

		if (summariserName.length() > 0) {
		summer = new Summariser(summariserName);
		}
		String reportFile = "report.jtl";
		String csvFile = "report.csv";
		String htmlFile = "report.html";
		ResultCollector logger = new ResultCollector(summer);
		logger.setFilename(reportFile);
		ResultCollector csvlogger = new ResultCollector(summer);
		csvlogger.setFilename(csvFile);
		ResultCollector htmllogger = new ResultCollector(summer);
		htmllogger.setFilename(htmlFile);
		testPlanTree.add(testPlanTree.getArray()[0], logger);
		testPlanTree.add(testPlanTree.getArray()[0], csvlogger);
		jmeter.configure(testPlanTree);
		jmeter.run();
		//afterSuite();
		

		
	}
	
	//@After
	public static void afterSuite() throws IOException, InterruptedException {
		CustomCSVReport c = new CustomCSVReport();
		c.callJmeterReport();
		String createDir = System.getProperty("user.dir") + "\\Reports\\jmeter";
		if (!new File(createDir).exists()) {
			new File(createDir).mkdirs();
		}
		FileUtils.cleanDirectory(new File(System.getProperty("user.dir") + "\\Reports\\jmeter"));

		String suiteName = "jmeter -g " + System.getProperty("user.dir") + "\\report.csv -o "
				+ System.getProperty("user.dir") + "\\Reports\\jmeter";

		String fileDir = System.getProperty("user.dir") + "\\src\\main\\resources\\exe\\apache-jmeter-3.2\\bin";

		// String fileDir="C:\\apache-maven-3.5.3-bin\\apache-maven-3.5.3\\bin";
		//Runtime.getRuntime().exec("cmd /c start cmd.exe  /k \"" + suiteName + "", null, new File(fileDir));
		Process p = Runtime.getRuntime().exec("cmd /c  "+suiteName, null, new File(fileDir));
		p.waitFor();
		Thread.sleep(10000);

		File folder = new File(System.getProperty("user.dir") + "\\Reports");
		File fList[] = folder.listFiles();

		for (File f : fList) {
			if (f.getName().endsWith(".jmx")) {
				// f.delete();
			}
			if (f.getName().endsWith(".csv")) {
				// f.delete();
			}
		}
	}

}
