package com.elx.nc.junit.tests;

import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.HashTree;

import java.io.File;
import java.io.IOException;



public class RunJMXFile111 {
	public static void main(String[] args) throws IOException {
		System.out.println("JMETER .....");
		StandardJMeterEngine jmeter= new StandardJMeterEngine();
		System.out.println("--------------------------------------------1");
		JMeterUtils.loadJMeterProperties(System.getProperty("user.dir")+"\\src\\main\\resources\\exe\\apache-jmeter-3.2\\bin\\jmeter.properties");
		//JMeterUtils.loadJMeterProperties("D:\\TSG\\POC\\ElectroLux\\apache-jmeter-4.0\\bin\\jmeter.properties");
		//JMeterUtils.setJMeterHome("D:\\TSG\\POC\\ElectroLux\\apache-jmeter-4.0");
		System.out.println(System.getProperty("user.dir")+"/src/main/resources/exe/apache-jmeter-3.2");
		
		JMeterUtils.setJMeterHome(System.getProperty("user.dir")+"\\src\\main\\resources\\exe\\apache-jmeter-3.2");
		System.out.println("--------------------------------------------2");
		JMeterUtils.initLocale();
		System.out.println("--------------------------------------------3");
		SaveService.loadProperties();
		File f = new File("D:\\TSG\\POC\\ElectroLux\\ElectroLuxJMX.jmx");
		System.out.println("--------------------------------------------4");
		HashTree testPlanTree= SaveService.loadTree(f);
		jmeter.configure(testPlanTree);
		System.out.println("--------------------------------------------5");
		jmeter.run();
		System.out.println("--------------------------------------------6");
	}
}
