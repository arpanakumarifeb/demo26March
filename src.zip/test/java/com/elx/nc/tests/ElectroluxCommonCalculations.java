package com.elx.nc.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.*;

import com.elx.common.*;
import com.elx.core.Screenshot;
import com.elx.core.util.CustomReport;
import com.elx.framework.base.SeleniumDriverUtil;
import com.elx.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;
import com.web.elx.pages.*;


import jxl.read.biff.BiffException;

/**
 * JCREW OMNITURE VERIFICATION class
 */
@Listeners({ CustomReport.class, Screenshot.class })
public class ElectroluxCommonCalculations extends WebTestCase {
	private  SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	HashMap<String, String> map  = new HashMap<String, String>();

	private Common common = new Common(driver);
	ExcelManager ex = new ExcelManager();
	ReadConfig testData = new ReadConfig();
	String ScreenshotRequire = null;

	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ElectroluxCommonCalculations.class.getName());
	private String url = null;
	String PlantName = null;
	@BeforeMethod(alwaysRun = true)
	public void initialize(ITestContext testContext) {
		driver = selenium.getDriver();		
		System.out.println("driver..>"+driver);
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
		common = new Common(driver);
		common.impicitWait(10);
		testContext.setAttribute("driver", driver);
		getDriver().manage().deleteAllCookies();
		common.impicitWait(4);
		getDriver().manage().window().maximize();
		url = testContext.getCurrentXmlTest().getParameter("URL");
		PlantName = testContext.getCurrentXmlTest().getParameter("PlantName");
		ScreenshotRequire = testContext.getCurrentXmlTest().getParameter("ScreenShotRequire");

		//url="http://coeapriso.electrolux-na.com/Apriso/start/";
		//url="http://usws4600/Apriso/Start/";
		getDriver().get(url);
		getDriver().manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateChangeOverTimeCalculation
	// * DESCRIPTION 	: Validate Change Over Time Calculation
	// * AUTHOR			: Arpana
	// * DATE 			: 4th Dec 2018 
	//***************************************************************************************************************************************


	@Test(dataProvider = "inputdata",testName = "ValidateChangeOverTimeCalculation", description = "Validate Change Over Time Calculation",enabled = true, groups = {
			"GLOBAL", "POE", })
	public void ValidateChangeOverTimeCalculation(Hashtable<String, String> data) throws IOException, InterruptedException, AWTException, ParseException, BiffException {

		String screenshot = null;
		ElectroluxCommonCalculations DT = new ElectroluxCommonCalculations();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);

		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("HeaderLineActiveStatus"),PlantName);


		test.log(LogStatus.INFO,"********Validate Change Over time calculation for Assembly lines **********");			
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);



		test.log(LogStatus.INFO,"********** Validate Login Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);

		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}					

		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("OperatorUserName"),testData.getConfig().getProperty("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for operator********");


		Thread.sleep(6000);
		WebDriver driver2= new ChromeDriver();                                    
		driver2.get(url);
		driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver2.manage().window().maximize();                
		Thread.sleep(5000);

		((JavascriptExecutor)driver2).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver2);

		test.log(LogStatus.INFO,"**********Validate Login Functionality for operator window 2********");		

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );

		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}	
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire); 

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for Supervisor********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire); 
		test.log(LogStatus.INFO, "Searched for ORD option and click" + screenshot);	
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);


		String sharedFlag=null;

		int i=0; 
		for (int j = 2; j < hm2.length; j++) {	
			for(int p=0;p<=LineActiveStatus.length;p++) {
				if(LineActiveStatus[p][0].contains(hm2[j][0])&&(LineActiveStatus[p][1].length()>1)) {
					for (int k = 0; k < 2; k++) {
						System.out.println("area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1]);
						test.log(LogStatus.INFO, "Testing started for area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1]);	
						if(hm2[j][k+1]!=null) {

							((JavascriptExecutor)driver).executeScript("window.focus();");
							pageFactory = new WebPageFactory(driver);

							String wc=hm2[j][k+1];
							if(wc!=null) {
								screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.OPRScreen"),ScreenshotRequire);
								test.log(LogStatus.INFO, "Searched for OPR screen option and click" + screenshot);			
								screenshot = getPageFactory().getWorkAreaPage().validatePageTitle(ScreenshotRequire);

								screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]),ScreenshotRequire);
								test.log(LogStatus.INFO, "Select a Line " + screenshot);

								screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][k+1]),ScreenshotRequire);
								test.log(LogStatus.INFO, "Select a work-center" + screenshot);
								String OprorderDetails= getPageFactory().getDashboardLine().selectOrderNumber(hm2[j][i],ScreenshotRequire);
								if(OprorderDetails!=null) {
									if(sharedFlag==null) {
										sharedFlag="NonShared";
									}

									getPageFactory().getDashboardLine().validateOperationPageTitle(hm2[j][i],hm2[j][k+1],sharedFlag,ScreenshotRequire);
									driver.navigate().refresh();

									String [] splits=common.splitValues(OprorderDetails,"_");

									((JavascriptExecutor)driver2).executeScript("window.focus();");
									pageFactory = new WebPageFactory(driver2); 

									getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
									//getPageFactory().getOrderCockPage().calculateChangeOverTime(splits[0],splits[1],splits[2],splits[3],splits[4],splits[5],hm2[j][i],hm2[j][k+1]);
									getPageFactory().getOrderCockPage().calculateChangeOverTime(splits[1],splits[2],splits[3],splits[4],splits[5],hm2[j][i],hm2[j][k+1]);
									getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
									Thread.sleep(5000);
									screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire); 
									getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
								}else {
									test.log(LogStatus.WARNING, "******** Orders are not available for testing**********");
									
								}
							}


						}
					}
					break;
				}
			}
		}

		test.log(LogStatus.INFO, "********Validated Change Over time calculation for Assembly lines successfully.**********");

		driver2.close();


	}

	@AfterMethod
	public void AfterMethodCleanUp(ITestContext testContext)
	{

		getDriver().manage().deleteAllCookies();
		//getDriver().close();
		//driver=null;
	}

}