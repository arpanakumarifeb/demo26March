package com.elx.nc.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ISuite;
import org.testng.ITestContext;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import com.elx.common.*;
import com.elx.core.Screenshot;
import com.elx.core.util.CustomReport;
import com.elx.framework.base.SeleniumDriverUtil;
import com.elx.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;
import com.web.elx.pages.*;
import jxl.read.biff.BiffException;

/**
 * JCREW OMNITURE VERIFICATION class
 */
@Listeners({ CustomReport.class, Screenshot.class })
public class ElectroluxMCSScreenTest extends WebTestCase {
	private  SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	HashMap<String, String> map  = new HashMap<String, String>();

	private Common common = new Common(driver);
	ReadConfig testData = new ReadConfig();
	private ExcelManager ex = new ExcelManager();
	SoftAssert softAssert = new SoftAssert();
	String ScreenshotRequire = null;
	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ElectroluxMCSScreenTest.class.getName());
	private String url = null;
	String PlantName = null;
	String WantToExecuteForAllWC = null;
	
	@BeforeMethod(alwaysRun = true)
	public void initialize(ITestContext testContext) {
		driver = selenium.getDriver();		
		System.out.println("driver..>"+driver);
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
		common = new Common(driver);
		common.impicitWait(10);
		testContext.setAttribute("driver", driver);
		getDriver().manage().deleteAllCookies();
		common.impicitWait(4);
		getDriver().manage().window().maximize();
		url = testContext.getCurrentXmlTest().getParameter("URL");
		ISuite xx= testContext.getSuite();
		PlantName = testContext.getCurrentXmlTest().getParameter("PlantName");
		ScreenshotRequire = testContext.getCurrentXmlTest().getParameter("ScreenShotRequire");
		WantToExecuteForAllWC = testContext.getCurrentXmlTest().getParameter("WantToExecuteForAllWC");
		getDriver().get(url);
		getDriver().manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateMCSScreen
	// * DESCRIPTION 	: Validate MCS Screen and their order status
	// * AUTHOR			: Arpana
	// * DATE 			: 12th Dec 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata",testName = "ValidateMCSScreen", description = "Validate MC SScreen",enabled = true	, groups = {
			"MCS", "LOCAL" })
	public void ValidateMCSScreen(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException {

		System.out.println("folder path" + result_FolderName);
		test.log(LogStatus.INFO,"**********Validate Login Functionality********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		System.out.println("pageTitle: " + pageTitle);
		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for "+data.get("searchMCSMenu")+" option and click");			
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnLeftTree(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnKILInk(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnTechnologyAreaLink(data.get("technologyArea"),ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnMachineNameLink(data.get("machineName"),ScreenshotRequire);
		getPageFactory().getMCSPage().verifyOrderStatus(data.get("technologyArea"),data.get("machineName"),ScreenshotRequire);
		getPageFactory().getMCSPage().verifyReverseProductionOrderStatus(data,"true");
		//getPageFactory().getMCSPage().verifyStartToHoldOrderStatus();
		//getPageFactory().getMCSPage().verifyHoldToStartOrderStatus();
		//getPageFactory().getMCSPage().checkOrderStatus();
		test.log(LogStatus.INFO, "********Validated MCS screen Start Order status successfully.**********");

	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateMCSScreenOrderDetailsWithORDScreenAndPOEScreenDetailsForAllWorkCenters
	// * DESCRIPTION 	: Validate MCS Screen Order Details With ORD and POE Screen For All Work Centers
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Dec 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata",enabled =true ,testName = "ValidateMCSOrderDetailsWithORDAndPOEScreenDetails", description = "Validate MCS Screen Order Details With ORD,  POE Screen",groups = {
			"MCS", "GLOBAL" ,"ORD"})
	public void ValidateMCSOrderDetailsWithORDAndPOEScreenDetails(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException, ParseException {
		String screenshot = null;
		ElectroluxMCSScreenTest DT = new ElectroluxMCSScreenTest();
		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		//String[][] hm2=new String[rowCount][];						
		String[][] hm2=new String[3][];						
		test.log(LogStatus.INFO,"********Validate MCS screen order details with ORD screen and POE Screen **********");			
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		test.log(LogStatus.INFO,"********** Validate Login Functionality ********");

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}					
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for operator********");	
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for MCS screen option and click" + screenshot);			
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);

		//ORD screen
		Thread.sleep(6000);
		WebDriver driver2= new ChromeDriver();                                    
		driver2.get(url);
		driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver2.manage().window().maximize();                
		Thread.sleep(5000);

		((JavascriptExecutor)driver2).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver2);

		test.log(LogStatus.INFO,"**********Validate Login Functionality for operator window 2********");		

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle2=getDriver().getCurrentUrl();
		if (pageTitle2.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire); 

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for Supervisor********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectORDScreen"),ScreenshotRequire); 
		test.log(LogStatus.INFO, "Searched for ORD option and click" + screenshot);	
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ORDPageTitle"),ScreenshotRequire);

		//POE screen
		Thread.sleep(6000);
		WebDriver driver3= new ChromeDriver();                                    
		driver3.get(url);
		driver3.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver3.manage().window().maximize();                
		Thread.sleep(5000);

		((JavascriptExecutor)driver3).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver3);

		test.log(LogStatus.INFO,"**********Validate Login Functionality for operator window 3********");		

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		String pageTitle3=getDriver().getCurrentUrl();
		if (pageTitle3.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire); 

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for Supervisor********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectPOEScreen"),ScreenshotRequire); 
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);	

		int i=0;
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}	
			for (int k = 0; k < TotalWCCount; k++) {
				System.out.print("area::"+hm2[j][i] + " ");

				((JavascriptExecutor)driver).executeScript("window.focus();");
				pageFactory = new WebPageFactory(driver);

				String wc=hm2[j][k+1+WCIndexToExecute];
				System.out.print("MN:: "+hm2[j][k+1+WCIndexToExecute] + " ");
				if(wc!=null) {
					getPageFactory().getMCSPage().clickOnLeftTree(ScreenshotRequire);
					getPageFactory().getMCSPage().clickOnKILInk(ScreenshotRequire);
					getPageFactory().getMCSPage().clickOnTechnologyAreaLink((hm2[j][i]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a technology area " + (hm2[j][i]));
					getPageFactory().getMCSPage().clickOnMachineNameLink((hm2[j][k+1+WCIndexToExecute]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a machine name " + (hm2[j][k+1+WCIndexToExecute]));
					getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
					HashMap<String, String> OrderCount=getPageFactory().getMCSPage().verifyMCSScreenOrderCount(hm2,rowCount,"true");

					//ORD screen testing

					test.log(LogStatus.INFO, "*****************************Validation on ORD Screen**************************");

					((JavascriptExecutor)driver2).executeScript("window.focus();");
					pageFactory = new WebPageFactory(driver2); 
					String machineName=null;
					machineName=hm2[j][k+1+WCIndexToExecute];
					if(machineName.contains("Rack Hand Scanner")){
						machineName= "RKCG_HandScan";
					}
					getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPageWithLineAndMachineDetails(data,OrderCount,hm2[j][i],machineName,"true");
					getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
					Thread.sleep(5000);
					screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectORDScreen"),ScreenshotRequire); 
					getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ORDPageTitle"),ScreenshotRequire);
					test.log(LogStatus.INFO, "*****************************Validation on POE Screen**************************");
					///POE screen testing

					((JavascriptExecutor)driver3).executeScript("window.focus();");
					pageFactory = new WebPageFactory(driver3); 
					String workcenter=null;

					if((hm2[j][k+1+WCIndexToExecute]).contains("0210_Alliance")) {
						workcenter="Front Frame";
					}
					if((hm2[j][k+1+WCIndexToExecute]).contains("0220_RWC")) {
						workcenter="Rear Frame";
					}
					if(((hm2[j][k+1+WCIndexToExecute]).contains("0230_MZM1"))||((hm2[j][k+1+WCIndexToExecute]).contains("0235_MZM2"))) {
						workcenter="Outer Door";
					}
					if((hm2[j][k+1+WCIndexToExecute]).contains("0115_DoorLine")) {
						workcenter="Plastic Door Assembly";
					}
					if(((hm2[j][k+1+WCIndexToExecute]).contains("INJ_01"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_02"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_03"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_04"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_05"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_06"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_07"))) {
						workcenter="PLTM";
					}
					if((hm2[j][k+1+WCIndexToExecute]).contains("0115_DoorLine")) {
						workcenter="Plastic Door Assembly";
					}
					if(((hm2[j][k+1+WCIndexToExecute]).contains("INJ_08"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_09"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_10"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_11"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_12"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_13"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_14"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_15"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_16"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_17"))) {
						workcenter="PLPM";
					}
					if((hm2[j][k+1+WCIndexToExecute]).contains("RKCG_HandScan") ||((hm2[j][k+1+WCIndexToExecute]).contains("Rack Hand Scanner"))) {
						workcenter="RKCG";
						hm2[j][k+1+WCIndexToExecute]="RKCG_HandScan";
					}

					System.out.println("workcenter" + workcenter);

					screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a technology area " + (hm2[j][i]));
					screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(workcenter,ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a workcenter " + workcenter);
					getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
					getPageFactory().getOrderExecution().validatePOEScreenAreaName(workcenter,ScreenshotRequire);

					getPageFactory().getOrderExecution().searchOrderOnOrderExecutionPageWithLineAndMachineDetails(data,OrderCount,hm2[j][i],hm2[j][k+1+WCIndexToExecute],"true");
					getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
					Thread.sleep(5000);
				}

			}}
		test.log(LogStatus.INFO, "********Validated MCS Screen Order Details With ORD Screen and POE Screen Details successfully.**********");
		driver2.close();
		driver3.close();

	}


	//***************************************************************************************************************************************
	// * NAME 			: ValidatePOEScreenToMCSScreenOrderDetails
	// * DESCRIPTION 	: Validate POE Screen To MCS Screen Order Details
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Dec 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata",testName = "ValidatePOEScreenToMCSScreenOrderDetails", description = "Validate POE Screen To MCS Screen OrderDetails",enabled = true, groups = {
			"MCS", "GLOBAL" ,"ORD"})
	public void ValidatePOEScreenToMCSScreenOrderDetails(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException, ParseException {
		String screenshot=null;			
		test.log(LogStatus.INFO,"********Validate POE Screen Order with MCS screen Order Details **********");			
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}					
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for operator********");	
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectPOEScreen"),ScreenshotRequire); 
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);
		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(data.get("technologyArea"),ScreenshotRequire);
		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(data.get("WorkCenter"),ScreenshotRequire);
		getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
		getPageFactory().getOrderExecution().validatePOEScreenAreaName(data.get("WorkCenter"),ScreenshotRequire);

		HashMap<Integer, String> POEScreenOrderDetails=getPageFactory().getOrderExecution().searchOrderOnOrderExecutionPageWithEquipmentDetails(data,"true");
		if(POEScreenOrderDetails.size()>0) {
			System.out.println("POEScreenOrderDetails quantity is greater than 0");
			getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
			getPageFactory().getMCSPage().validateMCSPageOrderDetails(POEScreenOrderDetails,ScreenshotRequire);
			test.log(LogStatus.INFO, "********Validated POE screen order with MCS screen Order details successfully.**********");

		}else {

			test.log(LogStatus.WARNING, "********No any started order present for "+ data.get("technologyArea")+">>>>"+data.get("WorkCenter")+"*********");

		}

	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateMCSScreenReportProductionDetails
	// * DESCRIPTION 	: Validate MCS Screen Report Production Details
	// * AUTHOR			: Arpana
	// * DATE 			: 12th Dec 2018 
	//***************************************************************************************************************************************



	@Test(dataProvider = "inputdata",enabled = true, testName = "ValidateMCSScreenReportProductionDetails", description = "Validate MCS Screen Report Production Details",groups = {
			"MCS", "LOCAL" })
	public void ValidateMCSScreenReportProductionDetails(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		ElectroluxMCSScreenTest DT = new ElectroluxMCSScreenTest();
		DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		test.log(LogStatus.INFO,"**********Validat MCS screen order good and scrap quantity with POE screen********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for "+data.get("searchMCSMenu")+" option and click");			
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
		test.log(LogStatus.INFO, "MCS page " );
		getPageFactory().getMCSPage().clickOnLeftTree(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnKILInk(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnTechnologyAreaLink(data.get("technologyArea"),ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnMachineNameLink(data.get("machineName"),ScreenshotRequire);
		getPageFactory().getMCSPage().verifyReportProductionPage(data,"true");
		test.log(LogStatus.INFO, "********Validated MCS screen good, reverse and scrap quantity error message successfully.**********");


	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateMCSRepProdQtyDetailsForFabAndPlasticsWithPOE
	// * DESCRIPTION 	: Validate MCS Screen Report Production Quantity Details for Fabrication and Plastic with POE Screen
	// * AUTHOR			: Arpana
	// * DATE 			: 12th Dec 2018 
	//***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",enabled = true,testName = "ValidateMCSRepProdQtyDetailsForFabAndPlasticsWithPOE", description = "Validate MCS Screen Report Production Details", groups = {
			"MCS", "LOCAL" })
	public void ValidateMCSRepProdQtyDetailsForFabAndPlasticsWithPOE(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;
		ElectroluxMCSScreenTest DT = new ElectroluxMCSScreenTest();
		DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		//String[][] hm2=new String[rowCount][];						
		String[][] hm2=new String[3][];						
		test.log(LogStatus.INFO,"**********Validat MCS screen order good and scrap quantity with POE screen********");		
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}					
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"),ScreenshotRequire);
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
		Thread.sleep(6000);
		WebDriver driver2= new ChromeDriver();                                    
		driver2.get(url);
		driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver2.manage().window().maximize();                
		Thread.sleep(5000);
		((JavascriptExecutor)driver2).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver2);
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		String pageTitle2=getDriver().getCurrentUrl();
		if (pageTitle2.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		}
		else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}		
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire); 
		test.log(LogStatus.INFO, "Login successfully" );
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectPOEScreen"),ScreenshotRequire); 
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);	
		int i=0;
		int flag=0;
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}	
			for (int k = 0; k < TotalWCCount; k++) {
				System.out.print("area:"+hm2[j][i] + " ");

				((JavascriptExecutor)driver).executeScript("window.focus();");
				pageFactory = new WebPageFactory(driver);

				String wc=hm2[j][k+1+WCIndexToExecute];
				System.out.print("MN: "+hm2[j][k+1+WCIndexToExecute] + " ");
				if(wc!=null) {
					test.log(LogStatus.INFO, "Verification for :" + (hm2[j][i])+">>>>>"+(hm2[j][k+1+WCIndexToExecute]));

					getPageFactory().getMCSPage().clickOnLeftTree(ScreenshotRequire);
					getPageFactory().getMCSPage().clickOnKILInk(ScreenshotRequire);
					getPageFactory().getMCSPage().clickOnTechnologyAreaLink((hm2[j][i]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a technology area: "+(hm2[j][i]),ScreenshotRequire);
					getPageFactory().getMCSPage().clickOnMachineNameLink((hm2[j][k+1+WCIndexToExecute]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a machine name: " + (hm2[j][k+1+WCIndexToExecute]));
					//softAssert.asserttrue(getPageFactory().getMCSPage().verifyReportProductionPage(data));
					int listSize=getPageFactory().getMCSPage().verifyOrderStatus(hm2[j][i],hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
					if(listSize>0) {
						getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
						getPageFactory().getMCSPage().verifyReverseProductionOrderStatus(data,ScreenshotRequire);
						HashMap<String, String> MCScreenOrderDetails=getPageFactory().getMCSPage().verifyReportProductionOrderDetails(data,hm2[j][i],ScreenshotRequire);
						((JavascriptExecutor)driver2).executeScript("window.focus();");
						pageFactory = new WebPageFactory(driver2); 

						String workcenter=null;
						if((hm2[j][k+1+WCIndexToExecute]).contains("0210_Alliance")) {
							workcenter="Front Frame";
						}
						if((hm2[j][k+1+WCIndexToExecute]).contains("0220_RWC")) {
							workcenter="Rear Frame";
						}
						if(((hm2[j][k+1+WCIndexToExecute]).contains("0230_MZM1"))||((hm2[j][k+1+WCIndexToExecute]).contains("0235_MZM2"))) {
							workcenter="Outer Door";
						}
						if((hm2[j][k+1+WCIndexToExecute]).contains("0115_DoorLine")) {
							workcenter="Plastic Door Assembly";
						}
						if(((hm2[j][k+1+WCIndexToExecute]).contains("INJ_01"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_02"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_03"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_04"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_05"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_06"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_07"))) {
							workcenter="PLTM";
						}
						if((hm2[j][k+1+WCIndexToExecute]).contains("0115_DoorLine")) {
							workcenter="Plastic Door Assembly";
						}
						if(((hm2[j][k+1+WCIndexToExecute]).contains("INJ_08"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_09"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_10"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_11"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_12"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_13"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_14"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_15"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_16"))||((hm2[j][k+1+WCIndexToExecute]).contains("INJ_17"))) {
							workcenter="PLPM";
						}
						if((hm2[j][k+1+WCIndexToExecute]).contains("RKCG_HandScan")) {
							workcenter="RKCG";
						}

						System.out.println("workcenter: " + workcenter);

						screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]),ScreenshotRequire);
						screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(workcenter,ScreenshotRequire);
						getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
						getPageFactory().getOrderExecution().validatePOEScreenAreaName(workcenter,"true");
						getPageFactory().getOrderExecution().validateOrderAndQtyOnOrderExecutionPage(MCScreenOrderDetails,hm2[j][k+1+WCIndexToExecute],"true");
						getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
						Thread.sleep(5000);
						flag=1;
					}else {
						flag=0;
						test.log(LogStatus.WARNING, "******** No orders are available for testing.**********");

					}
				}
			}}
		if(flag>0) {
			test.log(LogStatus.INFO, "********Validated MCS Screen Order Details With POE Screen Details successfully.**********");
		}
		driver2.close();;
	}

	//***************************************************************************************************************************************
	// * NAME 			ValidateMCSRepProdQtyDetailsForRacksWithPOEScreen
	// * DESCRIPTION 	: ValidateMCSRepProdQtyDetailsForRacksWithPOEScreen
	// * AUTHOR			: Arpana
	// * DATE 			: 28th Dec 2018 //// i will check tomorrow
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata",enabled = true,testName = "ValidateMCSRepProdQtyDetailsForRacksWithPOEScreen", description = "Validate MCS Screen Report Production Details for Racks", groups = {
			"MCS", "LOCAL" })
	public void ValidateMCSRepProdQtyDetailsForRacksWithPOEScreen(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;
		ElectroluxMCSScreenTest DT = new ElectroluxMCSScreenTest();
		DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		//String[][] hm2=new String[rowCount][];						
		String[][] hm2=new String[3][];						
		test.log(LogStatus.INFO,"**********Validat MCS screen Racks order good and scrap quantity with POE screen ********");		
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {

			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}					

		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"),ScreenshotRequire);
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);

		Thread.sleep(6000);
		WebDriver driver2= new ChromeDriver();                                    
		driver2.get(url);
		driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver2.manage().window().maximize();                
		Thread.sleep(5000);

		((JavascriptExecutor)driver2).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver2);

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);

		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		String pageTitle1=getDriver().getCurrentUrl();
		if (pageTitle1.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire); 

		test.log(LogStatus.INFO, "Login successfully" );
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectPOEScreen"),ScreenshotRequire); 
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);	


		int flag=0;
		int i=0;
		for (int j = 2; j < 3; j++) {	
			for (int k = 0; k < 2; k++) {
				System.out.print("area:"+hm2[j][i] + " ");

				((JavascriptExecutor)driver).executeScript("window.focus();");
				pageFactory = new WebPageFactory(driver);

				String wc=hm2[j][k+1];
				System.out.print("MN: "+hm2[j][k+1] + " ");
				if(wc!=null) {
					test.log(LogStatus.INFO, "Verification for :" + (hm2[j][i])+">>>>>"+(hm2[j][k+1]));

					getPageFactory().getMCSPage().clickOnLeftTree(ScreenshotRequire);
					getPageFactory().getMCSPage().clickOnKILInk(ScreenshotRequire);
					getPageFactory().getMCSPage().clickOnTechnologyAreaLink((hm2[j][i]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a technology area: "+(hm2[j][i]));
					getPageFactory().getMCSPage().clickOnMachineNameLink((hm2[j][k+1]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a machine name: " + (hm2[j][k+1]));
					int orderCount= getPageFactory().getMCSPage().verifyRacksOrderStatus(ScreenshotRequire);
					if(orderCount>0) {
						getPageFactory().getMCSPage().verifyReverseProductionOrderStatus(data,ScreenshotRequire);

						HashMap<String, String> MCScreenOrderDetails=getPageFactory().getMCSPage().verifyReportProductionOrderDetails(data,hm2[j][i],"true");

						((JavascriptExecutor)driver2).executeScript("window.focus();");
						pageFactory = new WebPageFactory(driver2); 

						String workcenter="RKCG";
						hm2[j][k+1]="RKCG";	

						screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]),ScreenshotRequire);
						screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(workcenter,ScreenshotRequire);
						getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
						getPageFactory().getOrderExecution().validatePOEScreenAreaName(workcenter,"true");
						getPageFactory().getOrderExecution().validateOrderAndQtyOnOrderExecutionPage(MCScreenOrderDetails,hm2[j][k+1],"true");
						getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
						flag=1;
					}else {

						flag=0;
						test.log(LogStatus.WARNING, "********No start order available for Racks **********");
					}
				}

			}}
		if(flag>0) {
			test.log(LogStatus.INFO, "********Validated MCS Screen racks Order Details With POE Screen Details successfully.**********");
		}
		driver2.close();
	}

	//***************************************************************************************************************************************
	// * NAME 			ValidateMCSRepProdQtyDetailsWithORDScreen
	// * DESCRIPTION 	: ValidateMCSScrenReportProductionQtyDetailsWithORDScreenDetailsForAllWorkCenters
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Dec 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata",enabled = true,testName ="ValidateMCSRepProdQtyDetailsWithORDScreen", description = "ValidateMCSScrenReportProductionQtyDetailsWithORDScreenDetailsForAllWorkCenters"	, groups = {
			"MCS", "LOCAL" })
	public void ValidateMCSRepProdQtyDetailsWithORDScreen(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException, ParseException {
		String screenshot = null;
		ElectroluxMCSScreenTest DT = new ElectroluxMCSScreenTest();
		DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		//String[][] hm2=new String[rowCount][];						
		String[][] hm2=new String[3][];						
		test.log(LogStatus.INFO,"********Validate MCS screen order details with ORD screen **********");			
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		test.log(LogStatus.INFO,"********** Validate Login Functionality ********* ");

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {

			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}					

		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for operator********");	
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for MCS screen option and click" + screenshot);			
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);


		Thread.sleep(6000);
		WebDriver driver2= new ChromeDriver();                                    
		driver2.get(url);
		driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver2.manage().window().maximize();                
		Thread.sleep(5000);

		((JavascriptExecutor)driver2).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver2);

		test.log(LogStatus.INFO,"**********Validate Login Functionality for operator window 2********");		

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );

		String pageTitle2=getDriver().getCurrentUrl();
		if (pageTitle2.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		}
		else {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"N",ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire); 

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for Supervisor********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectORDScreen"),ScreenshotRequire); 
		test.log(LogStatus.INFO, "Searched for ORD option and click" + screenshot);	
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ORDPageTitle"),ScreenshotRequire);

		int flag=0;
		int i=0;
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length-1; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}	
			for (int k = 0; k < TotalWCCount; k++) {
				System.out.print("area:"+hm2[j][i] + " ");

				((JavascriptExecutor)driver).executeScript("window.focus();");
				pageFactory = new WebPageFactory(driver);

				String wc=hm2[j][k+1+WCIndexToExecute];
				System.out.print("MN: "+hm2[j][k+1+WCIndexToExecute] + " ");
				if(wc!=null) {

					getPageFactory().getMCSPage().clickOnLeftTree(ScreenshotRequire);
					getPageFactory().getMCSPage().clickOnKILInk(ScreenshotRequire);
					getPageFactory().getMCSPage().clickOnTechnologyAreaLink((hm2[j][i]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a technology area: " + (hm2[j][i]));
					getPageFactory().getMCSPage().clickOnMachineNameLink((hm2[j][k+1+WCIndexToExecute]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a machine name: " + (hm2[j][k+1+WCIndexToExecute]));
					//HashMap<String, String> OrderCount=getPageFactory().getMCSPage().verifyMCSScreenOrderCount(hm2,rowCount);
					HashMap<String, String> MCScreenOrderDetails=getPageFactory().getMCSPage().verifyReportProductionOrderDetails(data,hm2[j][i],"true");
					if(MCScreenOrderDetails.get("OrderNo")!=null) {
						((JavascriptExecutor)driver2).executeScript("window.focus();");
						pageFactory = new WebPageFactory(driver2); 

						getPageFactory().getOrderCockPage().validateOrderAndQtyOnOrderCockpitPage(MCScreenOrderDetails,"true");
						getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
						Thread.sleep(5000);
						screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectORDScreen"),ScreenshotRequire); 
						getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ORDPageTitle"),ScreenshotRequire);
						flag=1;
					}else {
						flag=0;
						test.log(LogStatus.WARNING, "********No orders are available for testing.**********");

					}
				}

			}}
		if(flag>0) {
			test.log(LogStatus.INFO, "********Validated MCS Screen Order Details With ORD Screen Details successfully.**********");
		}

		driver2.close();

	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateMCSScreenWorkCentersAndMachines
	// * DESCRIPTION 	: Validate MCS Screen WorkCenters And Machines
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Dec 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata",enabled = true, testName = "ValidateMCSScreenWorkCentersAndMachines", description = "Validate MCS Screen Work Centers And Machines",groups = {
			"MCS", "GLOBAL" ,"ORD"})
	public void ValidateMCSScreenWorkCentersAndMachines(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException, ParseException {
		String screenshot = null;
		ElectroluxMCSScreenTest DT = new ElectroluxMCSScreenTest();
		DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		//String[][] hm2=new String[rowCount][];						
		String[][] hm2=new String[3][];						
		test.log(LogStatus.INFO,"********Validate MCS screen work centers and machine details **********");			
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {

			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),
					"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}					

		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for operator********");	
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for MCS screen option and click" + screenshot);			
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnLeftTree(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnKILInk(ScreenshotRequire);
		//getPageFactory().getMCSPage().expandAllCloseIcon();

		int i=0;
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length-1; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}
			getPageFactory().getMCSPage().validateTechnologyAreaLink((hm2[j][i]),ScreenshotRequire);
			for (int k = 0; k < TotalWCCount; k++) {
				System.out.print("area:"+hm2[j][i] + " ");

				String wc=hm2[j][k+1+WCIndexToExecute];
				System.out.print("MN: "+hm2[j][k+1+WCIndexToExecute] + " ");
				if(wc!=null) {
					getPageFactory().getMCSPage().validateMachineNameLink((hm2[j][k+1+WCIndexToExecute]),"true");
				}
			}
			getPageFactory().getMCSPage().collapseTechnologyAreaLink((hm2[j][i]),"true");
		}
		test.log(LogStatus.INFO, "********Validated MCS Screen WorkCenters And Machines successfully.**********");
	}


	//***************************************************************************************************************************************
	// * NAME 			: ValidateMCSScreenHeaderAndButtons
	// * DESCRIPTION 	: Validate MCS Screen and their Header , Buttons
	// * AUTHOR			: Arpana
	// * DATE 			: 26th Dec 2018 
	//***************************************************************************************************************************************



	@Test(dataProvider = "inputdata",enabled = true,testName = "ValidateMCSScreenHeaderAndButtons", description = "Validate MC SScreen", groups = {
			"MCS", "LOCAL" })
	public void ValidateMCSScreenHeaderAndButtons(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		test.log(LogStatus.INFO,"**********Validate Login Functionality********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for "+data.get("searchMCSMenu")+" option and click");			
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
		ElectroluxMCSScreenTest DT = new ElectroluxMCSScreenTest();
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header1"), PlantName);
		getPageFactory().getMCSPage().validateMCSScreenHeader(hm,ScreenshotRequire);
		getPageFactory().getMCSPage().validateMCSScreenProductionHeader(hm,"true");
		test.log(LogStatus.INFO, "********Validated MCS screen successfully.**********");

	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateMCSScreenForRacks
	// * DESCRIPTION 	: Validate MCS Screen and the racks  order status
	// * AUTHOR			: Arpana
	// * DATE 			: 12th Dec 2018 
	//***************************************************************************************************************************************



	@Test(dataProvider = "inputdata",enabled = true, testName = "ValidateMCSScreenForRacks", description = "ValidateMCSScreenForRacks",groups = {
			"MCS", "LOCAL" })
	public void ValidateMCSScreenForRacks(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException {
		test.log(LogStatus.INFO,"**********Validate Login Functionality********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for "+data.get("searchMCSMenu")+" option and click");			
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnLeftTree(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnKILInk(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnTechnologyAreaLink(data.get("technologyArea"),ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnMachineNameLink(data.get("machineName"),ScreenshotRequire);
		getPageFactory().getMCSPage().verifyRacksOrderStatus("true");
		//getPageFactory().getMCSPage().verifyHoldToStartOrderStatus();
		//getPageFactory().getMCSPage().checkOrderStatus();
		test.log(LogStatus.INFO, "********Validated MCS screen Start racks order status successfully.***********");

	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateMCSBuildPalletQtyDetailsForRacksWithPOEAndORDScreen
	// * DESCRIPTION 	: Validate MCS Screen Pallet Qty Details For Racks with POE and ORD screen
	// * AUTHOR			: Arpana
	// * DATE 			: 28th Dec 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata" ,testName = "ValidateMCSBuildPalletQtyDetailsForRacksWithPOEAndORDScreen", description = "ValidateMCSScreenBuildPalletQtyDetailsForRacksWithPOEScreen",enabled = true	, groups = {
			"MCS", "LOCAL" })
	public void ValidateMCSBuildPalletQtyDetailsForRacksWithPOEAndORDScreen(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;
		ElectroluxMCSScreenTest DT = new ElectroluxMCSScreenTest();
		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		//String[][] hm2=new String[rowCount][];						
		String[][] hm2=new String[rowCount][];						
		test.log(LogStatus.INFO,"**********Validate Racks Build pallet screen parts id and quantity  ********");		
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}					
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"),ScreenshotRequire);
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnLeftTree(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnKILInk(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnTechnologyAreaLink(data.get("technologyArea"),ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnMachineNameLink(data.get("machineName"),ScreenshotRequire);
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
		HashMap<String, String> OrderDetails=getPageFactory().getMCSPage().verifyMCSScreenStartOrderCount(hm2,rowCount,ScreenshotRequire);
		if(OrderDetails.get("StartedDisplayOrder").length()>0) {
			getPageFactory().getMCSPage().clickBuildPalletButton(ScreenshotRequire);
			String buildPalletQtyAndOrderId=getPageFactory().getBuildPallet().validateQuantityOnBuildPalletPage(data.get("PalletPageTitle"),OrderDetails,ScreenshotRequire);
			//getPageFactory().getMCSPage().clickOnMCSPage();
			getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
			getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"),ScreenshotRequire);
			HashMap<String, String> MCScreenOrderDetails=getPageFactory().getMCSPage().validateMCSPageOrderQtyDetailsAfterBuildPallet(buildPalletQtyAndOrderId,ScreenshotRequire);

			//validation with POE screen
			Thread.sleep(6000);
			WebDriver driver2= new ChromeDriver();                                    
			driver2.get(url);
			driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
			driver2.manage().window().maximize();                
			Thread.sleep(5000);

			((JavascriptExecutor)driver2).executeScript("window.focus();");
			pageFactory = new WebPageFactory(driver2);

			test.log(LogStatus.INFO,"**********Validate Login Functionality for operator window 2********");		

			getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
			screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);

			String pageTitle2=getDriver().getCurrentUrl();
			if (pageTitle2.contains("apriso.electrolux-na")) {
				screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
			}
			else {
				screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
			}
			screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire); 
			Thread.sleep(5000);
			screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectPOEScreen"),ScreenshotRequire); 
			screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(data.get("technologyArea"),ScreenshotRequire);
			screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(data.get("WorkArea"),ScreenshotRequire);
			getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
			getPageFactory().getOrderExecution().validatePOEScreenAreaName(data.get("WorkArea"),ScreenshotRequire);
			getPageFactory().getOrderExecution().validateOrderAndQtyOnOrderExecutionPageAfterBuildPallet(MCScreenOrderDetails,"true");


			/////ORD screen 

			Thread.sleep(6000);
			WebDriver driver3= new ChromeDriver();                                    
			driver3.get(url);
			driver3.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
			driver3.manage().window().maximize();                
			Thread.sleep(5000);

			((JavascriptExecutor)driver3).executeScript("window.focus();");
			pageFactory = new WebPageFactory(driver3);

			test.log(LogStatus.INFO,"**********Validate Login Functionality for operator window 3********");		

			getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
			screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);

			String pageTitle3=getDriver().getCurrentUrl();
			if (pageTitle3.contains("apriso.electrolux-na")) {
				screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
			} else {
				screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
			}
			screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire); 
			Thread.sleep(5000);
			screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectORDScreen"),ScreenshotRequire); 
			getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ORDPageTitle"),ScreenshotRequire);
			getPageFactory().getOrderCockPage().validateOrderAndQtyOnOrderCockpitPageAfterBuildPallet(MCScreenOrderDetails,"true");
			driver2.close();
			driver3.close();
			test.log(LogStatus.INFO, "********Validated Racks order quantity details after build pallet successfully in ORD and POE Screen.**********");
		}
	}
	/*//***************************************************************************************************************************************
	// * NAME 			: ValidateMCSScreenBuildPalletPartsQtyDetailsForRacks
	// * DESCRIPTION 	: Validate MCS Screen Pallet Qty and parts default qty Details For Racks
	// * AUTHOR			: Arpana
	// * DATE 			: 28th Dec 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata" ,testName = "ValidateMCSScreenBuildPalletPartsQtyDetailsForRacks", description = "ValidateMCSScreenBuildPalletPartsQtyDetailsForRacks",enabled = true	, groups = {
			"MCS", "LOCAL" })
	public void ValidateMCSScreenBuildPalletPartsQtyDetailsForRacks(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;
		ElectroluxMCSScreenTest DT = new ElectroluxMCSScreenTest();
		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		//String[][] hm2=new String[rowCount][];						
		String[][] hm2=new String[rowCount][];						
		test.log(LogStatus.INFO,"**********Validate Racks Build pallet screen parts id and quantity  ********");		
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {

			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),
					"Y");
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}					
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchMCSMenu"));
		getPageFactory().getMCSPage().validateMCSPageTitle(data.get("MCSpageTitle"));
		getPageFactory().getMCSPage().clickOnLeftTree(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnKILInk(ScreenshotRequire);
		getPageFactory().getMCSPage().clickOnTechnologyAreaLink(data.get("technologyArea"));
		getPageFactory().getMCSPage().clickOnMachineNameLink(data.get("machineName"));
		HashMap<String, String> OrderCount=null;
		getPageFactory().getMCSPage().clickBuildPalletButton();
		getPageFactory().getBuildPallet().validateBuildPalletPage(data.get("PalletPageTitle"));
		getPageFactory().getBuildPallet().validatePartsDetailsOnBuildPalletPage(hm2,OrderCount,rowCount);
		//getPageFactory().getBuildPallet().validateQuantityOnBuildPalletPage(OrderCount);

		test.log(LogStatus.INFO, "********Validated racks build pallet details successfully. **********");
	}*/

	@AfterMethod
	public void AfterMethodCleanUp(ITestContext testContext)
	{

		getDriver().manage().deleteAllCookies();
		//getDriver().close();
		//driver=null;
	}

}
