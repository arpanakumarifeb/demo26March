package com.elx.nc.tests;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.testng.*;
import org.testng.annotations.*;

import com.elx.common.*;
import com.elx.framework.base.SeleniumDriverUtil;
import com.elx.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;
import com.web.elx.pages.*;

import jxl.read.biff.BiffException;

public class ElectroluxNCMScreenValidation extends WebTestCase{
	//s
	private SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	HashMap<String, String> map = new HashMap<String, String>();

	private Common common = new Common(driver);
	private ExcelManager ex = new ExcelManager();
	ReadConfig testData = new ReadConfig();
	String ScreenshotRequire = null;
	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ElectroluxNCMScreenValidation.class.getName());
	private String url = null;
	String PlantName = null;

	@BeforeMethod(alwaysRun = true)
	public void initialize(ITestContext testContext) {
		driver = selenium.getDriver();
		System.out.println("driver..>" + driver);
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
		common = new Common(driver);
		common.impicitWait(10);
		testContext.setAttribute("driver", driver);
		getDriver().manage().deleteAllCookies();
		common.impicitWait(4);
		getDriver().manage().window().maximize();
		url = testContext.getCurrentXmlTest().getParameter("URL");
		PlantName = testContext.getCurrentXmlTest().getParameter("PlantName");
		ScreenshotRequire = testContext.getCurrentXmlTest().getParameter("ScreenShotRequire");

		// url="http://coeapriso.electrolux-na.com/Apriso/start/";
		getDriver().get(url);
		getDriver().manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
	}
	// ***************************************************************************************************************************************
	// * NAME : validateFieldsAndIcons
	// * DESCRIPTION : This method is validating All fields in NCM page
	// * AUTHOR : Chinmay
	// * DATE : 30-Nov-2018
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  testName = "validateFieldsAndIconsNCMPage", description = "Validating All fields in NCM page", enabled = true, groups = {
			"NC", "GLOBAL" })
	public void validateFieldsAndIconsNCMPage(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;

		test.log(LogStatus.INFO, "**********Validate Login Functionality********");

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");

		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwith.NCM"),ScreenshotRequire);
		
		if (!data.get("Header1").toLowerCase().equals("NCMTableHeader") && data.get("Header1") != null) {
			ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header1"), PlantName);
			System.out.println("Data driven working fine");

			System.out.println("data for plant name " + PlantName + " is:" + hm);
			getPageFactory().getNCInfoPage().validateNCMPageTableHeader(hm,"true");
		}
		test.log(LogStatus.INFO, "*********Validated Available Icons in NCM page table Header Section ******* ");

	}
	
	// ***************************************************************************************************************************************
		// * NAME : validateExportFunctionality
		// * DESCRIPTION : This method is validating Export Button in NCM page
		// * AUTHOR : Arpana
		// * DATE : 11-mar-2019
		// ***************************************************************************************************************************************
		@Test(dataProvider = "inputdata",  testName = "validateExport Functionality in NCM page", description = "Validating Export Function in NCM page", enabled = true, groups = {
				"NC", "GLOBAL" })
		public void validateExportButtonInNCMPage(Hashtable<String, String> data)
				throws InterruptedException, AWTException, IOException, BiffException {
			String screenshot = null;

			test.log(LogStatus.INFO, "**********Validate the NCM page export button functionality********");

			getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
			test.log(LogStatus.INFO,
					"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
			screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
			test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
			String pageTitle = getDriver().getCurrentUrl();
			if (pageTitle.contains("apriso.electrolux-na")) {
				getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
			} else {
				getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
			}
			screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);

			test.log(LogStatus.INFO, "Login successfully" );

			test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");

			screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwith.NCM"),ScreenshotRequire);
			test.log(LogStatus.INFO, "NCM Screen appearing" );
			getPageFactory().getNCInfoPage().clickonExport("true");
			
			test.log(LogStatus.INFO, "*********Verified Export Button Functionality in NCM page******* ");
			File getLatestFile = getPageFactory().getOrderExecution().getLatestFilefromDir(System.getProperty("user.home")+"/Downloads/");
			String fileName = getLatestFile.getName();
		    Assert.assertTrue(fileName.contains("export_page"), "Downloaded file name is not matching with expected file name");
			test.log(LogStatus.INFO, "*********Validated EXPORT button Functionality in NCM page successfully ******* ");

		}

	// ***************************************************************************************************************************************
	// * NAME : validateNCdetailsPageFields
	// * DESCRIPTION : This method is validating All fields in NCM page
	// * AUTHOR : Chinmay
	// * DATE : 30-Nov-2018
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  testName = "validateFields", description = "Validating All fields in NCM page", enabled = true, groups = {
			"NC", "GLOBAL" })
	public void validateNCdetailsPageFields(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;

		test.log(LogStatus.INFO, "**********Validate Login Functionality********");

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");

		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwith.NCM"),ScreenshotRequire);

		test.log(LogStatus.INFO, "*********Verification on create NC Functionality******" + screenshot);

		screenshot = getPageFactory().getNCInfoPage().clickonStatus(ScreenshotRequire);
		test.log(LogStatus.INFO, "**********Clicked on Status********");
		screenshot = getPageFactory().getNCInfoPage().selectstatus(data.get("elx.statusName"),ScreenshotRequire);
		test.log(LogStatus.INFO, "**********Expected Status Selected********");

		String ncDetails = getPageFactory().getNCInfoPage().searchNcOnNcListPage(ScreenshotRequire);
		String separator = new String("_");
		String[] splits = ncDetails.split(separator);

		test.log(LogStatus.INFO, "Selected Order Status " + splits[0] + " from NC Community List Page");

		/*ElectroluxNCMScreenValidation DT = new ElectroluxNCMScreenValidation();
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header1"), PlantName);
		System.out.println("Data driven working fine");

		System.out.println("data for plant name " + PlantName + " is:" + hm);*/
		//getPageFactory().getNCInfoPage().validateStatusFields(hm);


		ElectroluxNCMScreenValidation DT11 = new ElectroluxNCMScreenValidation();
		HashMap<Integer, String> hm11 = new HashMap<Integer, String>();
		hm11 = DT11.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header7"), PlantName);
		System.out.println("Data driven working fine");

		System.out.println("data for plant name " + PlantName + " is:" + hm11);
		getPageFactory().getNCInfoPage().criticalityFields(hm11,"true");

		/*ElectroluxNCMScreenValidation DT12 = new ElectroluxNCMScreenValidation();
		HashMap<Integer, String> hm12 = new HashMap<Integer, String>();
		hm12 = DT12.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header4"), PlantName);
		System.out.println("Data driven working fine");

		System.out.println("data for plant name " + PlantName + " is:" + hm12);*/
		//getPageFactory().getNCInfoPage().cprSequenceNoFields(hm12);
		//getPageFactory().getAprisoCommonPage().clickHomeIcon();

	}


	@AfterMethod
	public void AfterMethodCleanUp(ITestContext testContext) {
		Reporter.log("*********************************************************",true);
		Reporter.log("*****************  AfterMethod  *************************",true);
		getDriver().manage().deleteAllCookies();
		//getDriver().close();
		// driver=null;
	}
}
