package com.elx.nc.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.testng.ITestContext;
import org.testng.annotations.*;

import com.elx.common.*;
import com.elx.core.Screenshot;
import com.elx.core.util.CustomReport;
import com.elx.framework.base.SeleniumDriverUtil;
import com.elx.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;
import com.web.elx.pages.*;

import jxl.read.biff.BiffException;

/**
 * JCREW OMNITURE VERIFICATION class
 */
@Listeners({ CustomReport.class, Screenshot.class })
public class ElectroluxOPRScreenValidation extends WebTestCase {
	private  SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	HashMap<String, String> map  = new HashMap<String, String>();

	private Common common = new Common(driver);
	ExcelManager ex = new ExcelManager();
	ReadConfig testData = new ReadConfig();

	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ElectroluxOPRScreenValidation.class.getName());
	private String url = null;
	String PlantName = null;
	String ScreenshotRequire = null;
	
	@BeforeMethod(alwaysRun = true)
	public void initialize(ITestContext testContext) {
		driver = selenium.getDriver();		
		System.out.println("driver..>"+driver);
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
		common = new Common(driver);
		common.impicitWait(10);
		testContext.setAttribute("driver", driver);
		getDriver().manage().deleteAllCookies();
		common.impicitWait(4);
		getDriver().manage().window().maximize();
		url = testContext.getCurrentXmlTest().getParameter("URL");
		PlantName = testContext.getCurrentXmlTest().getParameter("PlantName");
		ScreenshotRequire = testContext.getCurrentXmlTest().getParameter("ScreenShotRequire");

		//url="http://coeapriso.electrolux-na.com/Apriso/start/";
		getDriver().get(url);
		getDriver().manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateOPRScreenAreaDetails
	// * DESCRIPTION 	: Validate OPR Screen Area Details and their respective workcenters.
	// * AUTHOR			: Arpana
	// * DATE 			: 4th Dec 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata",testName = "ValidateOPRScreenAreaDetails", description = "ValidateOPRScreenAreaDetails",enabled = true, groups = {
			"OPR", "GLOBAL"  })
	public void ValidateOPRScreenAreaDetails(Hashtable<String, String> data) throws IOException, InterruptedException, AWTException, BiffException {

		String screenshot = null;
		test.log(LogStatus.INFO,"********** Validate Login Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		}
		else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("OperatorUserName"),testData.getConfig().getProperty("password"),ScreenshotRequire); 

		test.log(LogStatus.INFO, "Login successfully" );


		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.ScreenName"),ScreenshotRequire); 
		test.log(LogStatus.INFO, "Searched for OPR option and click" + screenshot);	


		ElectroluxOPRScreenValidation DT = new ElectroluxOPRScreenValidation();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		String[][] hm2=new String[rowCount][];

		test.log(LogStatus.INFO,"********Validated "+rowCount+" area are present **********");

		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		getPageFactory().getWorkAreaPage().ValidateAreaAndWorkCenter(hm2,rowCount, "true");
		test.log(LogStatus.INFO,"********Validated work center successfully**********");

	}

	public void AfterMethodCleanUp(ITestContext testContext)
	{

		getDriver().manage().deleteAllCookies();
		//getDriver().close();
		//driver=null;
	}




}