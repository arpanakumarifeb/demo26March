package com.elx.nc.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.testng.ITestContext;
import org.testng.annotations.*;

import com.elx.common.*;
import com.elx.core.Screenshot;
import com.elx.core.util.CustomReport;
import com.elx.framework.base.SeleniumDriverUtil;
import com.elx.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;
import com.web.elx.pages.*;

import jxl.read.biff.BiffException;

/**
 * JCREW OMNITURE VERIFICATION class
 */
@Listeners({ CustomReport.class, Screenshot.class })
public class ElectroluxORDScreenValidation extends WebTestCase {
	private SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	HashMap<String, String> map = new HashMap<String, String>();

	private Common common = new Common(driver);
	private ExcelManager ex = new ExcelManager();
	ReadConfig testData = new ReadConfig();
	
	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ElectroluxORDScreenValidation.class.getName());
	private String url = null;
	String PlantName = null;
	String ScreenshotRequire = null;

	@BeforeMethod
	public void initialize(ITestContext testContext) {
		driver = selenium.getDriver();
		System.out.println("driver..>" + driver);
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
		common = new Common(driver);
		common.impicitWait(10);
		testContext.setAttribute("driver", driver);
		getDriver().manage().deleteAllCookies();
		common.impicitWait(4);
		getDriver().manage().window().maximize();
		url = testContext.getCurrentXmlTest().getParameter("URL");
		PlantName = testContext.getCurrentXmlTest().getParameter("PlantName");
		ScreenshotRequire = testContext.getCurrentXmlTest().getParameter("ScreenShotRequire");
		//url="http://usws4600/Apriso/Start/";
		getDriver().get(url);
		getDriver().manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
	}

	// ***************************************************************************************************************************************
	// * NAME : ValidateOperationScreen
	// * DESCRIPTION : This method is validating operation screen
	// * AUTHOR : Arpana
	// * DATE : 20-Nov-2018
	// ***************************************************************************************************************************************


	@Test(dataProvider = "inputdata",  testName = "ValidateOperationScreen", description = "ValidateOperationScreen", enabled = true, groups = {
			"OPR", "GLOBAL" })
	public void ValidateOperationScreen(Hashtable<String, String> data)
			throws IOException, InterruptedException, AWTException, BiffException {
		test.log(LogStatus.INFO, "**********Validate Login Functionality********");

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		getPageFactory().getElxLogin().loginToElx(data.get("username"), data.get("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
		ElectroluxORDScreenValidation DT = new ElectroluxORDScreenValidation();
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName1"), data.get("Header"), PlantName);
		int flag= 0;
		for (int i = 2; i < hm.size(); i++) {
			System.out.println("i value " + i + "value of data " + hm.get(i+1));

			String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPagewithLine(hm.get(i + 1),ScreenshotRequire);
			if(orderDetails!=null) {
			getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("elx.ordOperationTitle"),ScreenshotRequire);
			String headerDetails = "OperationDetails_" + hm.get(i + 1);
			System.out.println("header selection:" + headerDetails);
			int rowCount = DT.ex.calculateRowCount(data.get("GlobalDataFileName"), data.get("SheetName"), headerDetails,
					PlantName);

			String[][] hm2 = new String[rowCount][];

			test.log(LogStatus.INFO, "********Validated " + rowCount + " work centers are present **********");

			hm2 = DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"), data.get("SheetName"), headerDetails,
					PlantName);
			getPageFactory().getOrderOperationPage().ValidateWorkCenterAndOperation(hm2, rowCount,"true");
			getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
			// getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"));
			getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
			flag=1;
			test.log(LogStatus.INFO, "********Validated Area and work center successfully for Operation Page********** "+ hm.get(i+1) );
			
		}else
			test.log(LogStatus.WARNING, "*********No order available for Testing for *******"+ hm.get(i+1) );
		}
		test.log(LogStatus.INFO, "********Validated Area and work center for Operation Page**********");
		
	}
		

	//////////////////////// Added by Chinmay//////////////////////////

	// ***************************************************************************************************************************************
	// * NAME : validateORDScreenTableHeaderValidation
	// * DESCRIPTION : This method is validating All table place holders in ORD
	// screen
	// * AUTHOR : Chinmay
	// * DATE : 27-Nov-2018
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata", priority = 2, testName = "validateORDScreenIconsDropdownsAndButtons", description = "validateORDScreenIconsDropdownsAndButtons", enabled = true, groups = {
			"ORD", "GLOBAL" })
	public void validateORDScreenIconsDropdownsAndButtonsValidation(Hashtable<String, String> data)
			throws IOException, InterruptedException, AWTException, BiffException {

		test.log(LogStatus.INFO, "********** Validate Login Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {

			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);

		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		getPageFactory().getElxLogin().loginToElx(data.get("username"), data.get("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");

		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
		ElectroluxORDScreenValidation DT = new ElectroluxORDScreenValidation();
		// Added By Chinmay
		if (!data.get("Header3").toLowerCase().equals("20FieldsIcons") && data.get("Header3") != null) {
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header3"), PlantName);
			getPageFactory().getOrderCockPage().validateallORDScreenSearchHeaderValidation(hm,"true");
		}
		if (!data.get("Header4").toLowerCase().equals("ORDStatusDropdownValues") && data.get("Header4") != null) {
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header4"), PlantName);
			getPageFactory().getOrderCockPage().validateStatusFields(hm,"true");
		}
		if (!data.get("Header5").toLowerCase().equals("ProductLineDropdownValues") && data.get("Header5") != null) {
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header5"), PlantName);
			getPageFactory().getOrderCockPage().validateProductLineFieldContains(hm,"true");
		}
		/*if (!data.get("Header6").toLowerCase().equals("ORDScreenHeaderValues") && data.get("Header6") != null) {
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header6"), PlantName);
			getPageFactory().getOrderCockPage().validateORDScreenHeaderButtons(hm);
		}*/

		test.log(LogStatus.INFO,
				"*********Validated ORD Screen Table Header,Buttons,Icons And DropDown Values   Successfully******* ");
	}

	// ***************************************************************************************************************************************
		// * NAME : validateNewStartedHoldAllDetailsValidationORDScreen
		// * DESCRIPTION : This method is validating All details for New ,Started
		// And Hold Orders
		// screen
		// * AUTHOR : Chinmay
		// * DATE : 27-Nov-2018
		// ***************************************************************************************************************************************
		@Test(dataProvider = "inputdata",  testName = "validateNewStartedHoldAllDetailsValidationORDScreen", description = "ValidateButtons", enabled = true, groups = {
				"ORD", "LOCAL" })
		public void validateNewStartedHoldAllDetailsValidationORDScreen(Hashtable<String, String> data)
				throws InterruptedException, AWTException, IOException, BiffException {
			int flag=0;
			ElectroluxORDScreenValidation DT = new ElectroluxORDScreenValidation();
			int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);
			
			String[][] hm2=new String[rowCount][];						
			hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);
			
			
			test.log(LogStatus.INFO, "**********Validate New, Started,  Hold, Details Validation for ORD Screen Functionality********");
			getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
			test.log(LogStatus.INFO,
					"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
			getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
			test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
			String pageTitle = getDriver().getCurrentUrl();
			if (pageTitle.contains("apriso.electrolux-na")) {
				getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
			} else {
				getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
			}
			getPageFactory().getElxLogin().loginToElx(data.get("username"), data.get("password"),ScreenshotRequire);

			test.log(LogStatus.INFO, "Login successfully" );

			test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");

			getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
			test.log(LogStatus.INFO, "Searched for ORD option and click");
			getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
			
			///testing for Started
			
			String orderDetails = getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPagewthStatus(
					data.get("elx.orderSatusStarted"), "", hm2[0][0],ScreenshotRequire);
			if(orderDetails!=null) {
				String separator = new String("_");
				String[] splits = orderDetails.split(separator);
				test.log(LogStatus.INFO, "Selected Order Status " + splits[9] + " from Order Cockpit Page");
				getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("elx.ordOperationTitle"),ScreenshotRequire);
				getPageFactory().getOrderOperationPage().validateStatusDetails(splits[9],ScreenshotRequire);
				HashMap<Integer, String> ButtonStatusFor_Started = new HashMap<Integer, String>();
				ButtonStatusFor_Started = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header2"), PlantName);
				getPageFactory().getOrderOperationPage().validateFooterButtonsWithStatus("Started",ButtonStatusFor_Started,ScreenshotRequire);
				test.log(LogStatus.INFO, "**********************");
				flag=1;
			}else {
				flag=0;
				test.log(LogStatus.WARNING, "*************No order available for Testing***********");
				
			}
			getPageFactory().getOrderOperationPage().clickHomeIcon(ScreenshotRequire);
			getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
			test.log(LogStatus.INFO, "Searched for ORD option and click");
			getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
			
			///testing for Hold
			String orderDetails2 = getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPagewthStatus(
					data.get("elx.orderSatusHold"), "", hm2[0][0],ScreenshotRequire);
			if(orderDetails2!=null) {
				String separator2 = new String("_");
				String[] splits2 = orderDetails2.split(separator2);
				test.log(LogStatus.INFO, "Selected Order Status " + splits2[9] + " from Order Cockpit Page");
				getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("elx.ordOperationTitle"),ScreenshotRequire);
				getPageFactory().getOrderOperationPage().validateStatusDetails(splits2[9],ScreenshotRequire);
				HashMap<Integer, String> ButtonStatusFor_Held = new HashMap<Integer, String>();
				ButtonStatusFor_Held = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header3"), PlantName);
				getPageFactory().getOrderOperationPage().validateFooterButtonsWithStatus("Held",ButtonStatusFor_Held,ScreenshotRequire);
				flag=1;
			}else {
				flag=0;
				test.log(LogStatus.WARNING, "*************No order available for Testing***********");
			}
			getPageFactory().getOrderOperationPage().clickHomeIcon(ScreenshotRequire);
			getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
			test.log(LogStatus.INFO, "Searched for ORD option and click");
			getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
			
			///testing for off-hold
			String orderDetails3 = getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPagewthStatus(
					data.get("elx.orderSatusOffHold"), "", hm2[0][0],"true");
			if(orderDetails3!=null) {
				String separator2 = new String("_");
				String[] splits2 = orderDetails3.split(separator2);
				test.log(LogStatus.INFO, "Selected Order Status " + splits2[9] + " from Order Cockpit Page");
				getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("elx.ordOperationTitle"),ScreenshotRequire);
				getPageFactory().getOrderOperationPage().validateStatusDetails(splits2[9],ScreenshotRequire);
				HashMap<Integer, String> ButtonEnableStatusFor_OffHold = new HashMap<Integer, String>();
				ButtonEnableStatusFor_OffHold = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header5"), PlantName);
				getPageFactory().getOrderOperationPage().validateFooterButtonsWithStatus("Off-Hold",ButtonEnableStatusFor_OffHold,"true");
				flag=1;
			}else {
				flag=0;
				test.log(LogStatus.WARNING, "*************No order available for Testing***********");
				
			}
			if(flag>0) {
				test.log(LogStatus.INFO,
					"*********Validated Operation Screen Footer buttons For New , Started, off-hold  And Held Status Successfully******* ");
		}}

	

	// ***************************************************************************************************************************************
	// * NAME : validatingOperationScreenGeneralFieldcontnsORDMorder
	// * DESCRIPTION : This method is validating All header buttons And General tabs in Operation for M order
	// page //Modified
	// * AUTHOR : Chinmay
	// * DATE : 4-March-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata", testName = "MOrder_OperationPage", description = "MOrder_OperationPage", enabled = true, groups = {
			"ORD", "GLOBAL" })
	public void validatingOperationScreenGeneralFieldcontnsORDMorder(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		
		if(PlantName.contains("Kinston")) {
		test.log(LogStatus.INFO, "**********Validate Login Functionality********");

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {

			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);

		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		getPageFactory().getElxLogin().loginToElx(data.get("username"), data.get("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");

		test.log(LogStatus.INFO, "**********Selection on S order Serial no  with status as Started********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
		String orderDetails = getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(
				data.get("elx.orderSatusStarted"), data.get("orderSearch"), data.get("elx.work.area.L1"),ScreenshotRequire);
		if(orderDetails!=null) {
		String separator = new String("_");
		String[] splits = orderDetails.split(separator);

		test.log(LogStatus.INFO, "Selected Order Id " + splits[0] + " from Order Cockpit Page");
		getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("elx.ordOperationTitle"),ScreenshotRequire);

		new HashMap<String, Boolean>();
		ElectroluxORDScreenValidation DT = new ElectroluxORDScreenValidation();
		HashMap<String, String> hm2 = new HashMap<String, String>();
		if (!data.get("Header7").toLowerCase().equals("OperartionScreenHeaderValues") && data.get("Header7") != null) {
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header7"), PlantName);
			HashMap<String, String> OrderCount = getPageFactory().getOrderCockPage().validateOperationSceenHeaderButtons(hm,"true");
			Iterator<Map.Entry<String, String>> itr1 = OrderCount.entrySet().iterator();
			while (itr1.hasNext()) {
				Map.Entry<String, String> entry = itr1.next();
				hm2.put(entry.getKey(),entry.getValue());
			}
		}
		if (!data.get("Header8").toLowerCase().equals("GeneralTabFileldValues") && data.get("Header8") != null) {
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header8"), PlantName);
			HashMap<String, String> OrderCount1 = getPageFactory().getOrderCockPage().validateGeneralTabContains(hm,"true");
			Iterator<Map.Entry<String, String>> itr1 = OrderCount1.entrySet().iterator();
			while (itr1.hasNext()) {
				Map.Entry<String, String> entry = itr1.next();
				hm2.put(entry.getKey(),entry.getValue());
			}
		}
		}else {
			test.log(LogStatus.WARNING,"********No order available for Testing**********");
		}
		}else {
			test.log(LogStatus.INFO,"********This Script is not applicable for the plant **********");
		}
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateStatusLegendColorCodeInORDScreen
	// * DESCRIPTION 	: Validate Status Legend Color Code In ORD Screen
	// * AUTHOR			: Arpana
	// * DATE 			: 04-02-2019 
	//***************************************************************************************************************************************


	@Test(dataProvider = "inputdata",testName = "ValidateStatusLegendColorCodeInORDScreen", description = "ValidateStatusLegendColorCodeInORDScreen",enabled = true, groups = {
			"ORD", "LOCAL" })
	public void ValidateStatusLegendColorCodeInORDScreen(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException {
		@SuppressWarnings("unused")
		String screenshot = null;

		test.log(LogStatus.INFO,"**********Validate Status Legend Color Code In ORD Screen Functionality********");

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(data.get("username"),data.get("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");			
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
		String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPageWithOId("",ScreenshotRequire);
		test.log(LogStatus.INFO, "order count:  " + orderDetails + " on Order Cockpit Page");
		if(orderDetails!=null) {
			HashMap<Integer,String> colorfilter=new HashMap<Integer,String>();
			colorfilter.put(0, "Green");
			colorfilter.put(1, "Red");
			colorfilter.put(2, "Purple");
			colorfilter.put(3, "Yellow");
			for(int i=0;i<colorfilter.size();i++) {
				getPageFactory().getOrderCockPage().selectColorFilter(colorfilter.get(i),ScreenshotRequire);
				getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
				if(colorfilter.get(i).contains("Green") ||colorfilter.get(i).contains("Red")) {
					getPageFactory().getOrderCockPage().validateOrderDetailsWithGreenAndRedColorFilter(colorfilter.get(i),"true");
				} if(colorfilter.get(i).contains("Yellow")) {
					getPageFactory().getOrderCockPage().validateOrderDetailsWithYellowColorFilter(colorfilter.get(i),"true");
				}if(colorfilter.get(i).contains("Purple")) {
					getPageFactory().getOrderCockPage().clickOrder(colorfilter.get(i),ScreenshotRequire);
					getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("elx.ordOperationTitle"),ScreenshotRequire);
					String nonConformanceCount = getPageFactory().getOrderOperationPage().validateNCCountOnOrderOperationPage("s","true");
					if(Integer.parseInt(nonConformanceCount)==0) {
						test.log(LogStatus.FAIL, "*********Purple order doesn't contains NC *******");
					}else {
						test.log(LogStatus.PASS, "*********Purple order contains NC : "+nonConformanceCount );
					}
					getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
					Thread.sleep(10000);
				}
			}
			test.log(LogStatus.INFO, "*********Validated Status Legend Color Code in ORD Screen Successfully*******" );
		}else
			test.log(LogStatus.WARNING, "*********No order available for Testing *******" );
	}
	// ***************************************************************************************************************************************
	// * NAME : ValidateORDOrderStatus
	// * DESCRIPTION : This method is validating All header buttons in Operation
	// page //Modified
	// * AUTHOR : Chinmay
	// * DATE : 30-Nov-2018
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata", priority = 4, testName = "ValidateORDOrderStatus", description = "ValidateORDOrderStatus", enabled = true, groups = {
			"ORD", "GLOBAL" })
	public void ValidateORDOrderStatus(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		test.log(LogStatus.INFO, "**********Validate Login Functionality********");

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {

			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);

		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		getPageFactory().getElxLogin().loginToElx(data.get("username"), data.get("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");

		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
		String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPageWithOId("",ScreenshotRequire);
		test.log(LogStatus.INFO, "order count:  " + orderDetails + " on Order Cockpit Page");
		if(orderDetails!=null) {
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusStarted"),"true");
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusHold"),"true");
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusNew"),"true");
			/*getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusCompleted"));
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusCancelled"));
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusClosed"));
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusReleased"));
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusPicked"));
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusDiscrepancy"));*/
			test.log(LogStatus.INFO, "*********verified order status in order list according to status Dropdown***********");
		}else {
			test.log(LogStatus.WARNING, "*********No order available to perform the operation***********");
		}

	}

	@AfterMethod
	public void AfterMethodCleanUp(ITestContext testContext) {

		getDriver().manage().deleteAllCookies();
		// getDriver().close();
		// driver=null;
	}

}