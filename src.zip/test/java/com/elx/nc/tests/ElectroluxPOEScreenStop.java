package com.elx.nc.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.*;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import com.elx.common.Common;
import com.elx.common.ExcelManager;
import com.elx.core.Screenshot;
import com.elx.core.util.CustomReport;
import com.elx.framework.base.SeleniumDriverUtil;
import com.elx.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;
import com.web.elx.pages.*;

import jxl.read.biff.BiffException;

/**
 * JCREW OMNITURE VERIFICATION class
 */
@Listeners({ CustomReport.class, Screenshot.class })
public class ElectroluxPOEScreenStop extends WebTestCase {
	private SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	HashMap<String, String> map = new HashMap<String, String>();

	private Common common = new Common(driver);
	private ExcelManager ex = new ExcelManager();
	ReadConfig testData = new ReadConfig();
	String WantToExecuteForAllWC = null;

	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ElectroluxPOEScreenStop.class.getName());
	private String url = null;
	String PlantName = null;
	SoftAssert softAssert = new SoftAssert();
	String ScreenshotRequire = null;

	@BeforeMethod
	public void initialize(ITestContext testContext) {
		driver = selenium.getDriver();
		System.out.println("driver..>" + driver);
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
		common = new Common(driver);
		common.impicitWait(10);
		testContext.setAttribute("driver", driver);
		getDriver().manage().deleteAllCookies();
		common.impicitWait(4);
		getDriver().manage().window().maximize();
		url = testContext.getCurrentXmlTest().getParameter("URL");
		PlantName = testContext.getCurrentXmlTest().getParameter("PlantName");
		ScreenshotRequire = testContext.getCurrentXmlTest().getParameter("ScreenShotRequire");
		//url="http://usws4600/Apriso/Start/";
		getDriver().get(url);
		getDriver().manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		WantToExecuteForAllWC = testContext.getCurrentXmlTest().getParameter("WantToExecuteForAllWC");
	}

	@Test(dataProvider = "inputdata",testName = "ValidateStopPOEAndOPRScreenFlow", description = "Validate NC POE And OPR Screen Flow Line",enabled = true, groups = {
			"LINE1", "POE", "LOCAL" , "NC", "OPR"  })
	public void ValidateStopPOEAndOPRScreenFlow(Hashtable<String, String> data) throws IOException, InterruptedException, AWTException, BiffException {
		ElectroluxPOEScreenStop DT = new ElectroluxPOEScreenStop();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);


		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("HeaderLineActiveStatus"),PlantName);


		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);
		String sharedFlag=null;

		String screenshot = null;
		test.log(LogStatus.INFO,"********** Validate Login Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire); 

		test.log(LogStatus.INFO, "Login successfully" );


		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for Supervisor********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("POEScreen"),ScreenshotRequire); 
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);	

		//operator window
		Thread.sleep(6000);
		WebDriver driver2= new ChromeDriver();                                    
		driver2.get(url);
		driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver2.manage().window().maximize();                
		Thread.sleep(5000);

		((JavascriptExecutor)driver2).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver2);

		test.log(LogStatus.INFO,"**********Validate Login Functionality for operator window 2********");		

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );

		String pageTitle2=getDriver().getCurrentUrl();
		if (pageTitle2.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}	
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("OperatorUserName"),testData.getConfig().getProperty("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for operator********");


		//POE screen
		((JavascriptExecutor)driver).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver);
		int flag=0;
		int i=0;
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}
			for(int p=0;p<=LineActiveStatus.length;p++) {
				if(LineActiveStatus[p][0].contains(hm2[j][0])&&LineActiveStatus[p][1].length()>1) {
					
					for (int k = 0; k < TotalWCCount; k++) {
						System.out.println("area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);
						test.log(LogStatus.INFO, "Testing started for area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);	
						if(hm2[j][k+1+WCIndexToExecute]!=null) {

					if(SharedWCRule.length>0) {
						sharedFlag= common.validateSharedWC(hm2[j][k+1+WCIndexToExecute].trim().toLowerCase(),SharedWCRule);
					}else {
						sharedFlag="nonShared";
					}
					screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Selected a Line " + screenshot);

					screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
					test.log(LogStatus.INFO, "Selected a work-center" + screenshot);
					getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
					getPageFactory().getOrderExecution().validatePOEScreenAreaName(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
					String ncCount1= getPageFactory().getOrderExecution().vaidateStopIconCount(ScreenshotRequire);

					//move to OPERATOR screen
					((JavascriptExecutor)driver2).executeScript("window.focus();");
					pageFactory = new WebPageFactory(driver2);

					screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("OPRScreen"),ScreenshotRequire);
					test.log(LogStatus.INFO, "Searched for OPR screen option and click" + screenshot);			
					screenshot = getPageFactory().getWorkAreaPage().validatePageTitle(ScreenshotRequire);

					screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]),ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a Line " + screenshot);

					screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
					test.log(LogStatus.INFO, "Select a work-center" + screenshot);

					String OprorderDetails= getPageFactory().getDashboardLine().selectOrderNumber(hm2[j][i],ScreenshotRequire);
					if(OprorderDetails!=null) {
						if(sharedFlag==null) {
							sharedFlag="NonShared";
						}
						getPageFactory().getDashboardLine().validateOperationPageTitle(hm2[j][i],hm2[j][k+1+WCIndexToExecute],sharedFlag,ScreenshotRequire);
						getPageFactory().getDashboardLine().validateProductLine(hm2[j][i],hm2[j][k+1+WCIndexToExecute],sharedFlag, ScreenshotRequire);
							
						screenshot = getPageFactory().getDashboardLine().clickOnButton(data.get("reasonButton.Stop"),ScreenshotRequire);
						String ncReasonCodes=getPageFactory().getOperatorReasonPage().selectReasonCodes(ScreenshotRequire);
						String [] NCReason=common.splitValues(ncReasonCodes,"_");
						driver2.navigate().refresh();

						//Move to POE screen
						((JavascriptExecutor)driver).executeScript("window.focus();");
						pageFactory = new WebPageFactory(driver); 

						getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
						String ncCount2=getPageFactory().getOrderExecution().clickAndValidateOnStopIconAndClose(NCReason,"Critical",ScreenshotRequire);
						getPageFactory().getOrderExecution().clickAndValidateOnStopIconAndClick(NCReason,"Critical","true");

						if(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount1)) {
							test.log(LogStatus.INFO, "Previous Work center count was:--"+ncCount1+" , Current Work center count after NC increased to:--"+ncCount2);	
						}else {
							softAssert.assertTrue(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount1),"NC count not increased") ;
							test.log(LogStatus.INFO, "Previous Work center count was:--"+ncCount1+" , Current Work center count after NC created increased to:--"+ncCount2);
						}
						getPageFactory().getNCInfoPage().clickOnResolveButton(ScreenshotRequire);
						getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);

						String ncCount3= getPageFactory().getOrderExecution().vaidateStopIconCount("true");
						getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);

						if(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount3)) {

							test.log(LogStatus.INFO, "Previous Work center count before resolve was:--"+ncCount2+" , Current Work center count after resolve its decreased to:--"+ncCount3);
						}else {
							softAssert.assertTrue(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount3),"NC count not decreased") ;
							test.log(LogStatus.INFO, "Previous Work center count before resolve was:--"+ncCount2+" , Current Work center count after resolve its decreased to:--"+ncCount3);
						}
						flag=1;
					}else {
						flag=0;
						test.log(LogStatus.WARNING,"********No order available for Testing**********");
					}
				}

			}
			break;
		}
	}
			if(flag>0) {
				test.log(LogStatus.INFO, "*************Validation of POE and OPR screen completed for Stop successfully***********");
			}else {
				test.log(LogStatus.WARNING, "*************No order available for Testing***********");
				
			}
		}
		driver2.close();
	}


	@AfterMethod
	public void AfterMethodCleanUp(ITestContext testContext)
	{

		getDriver().manage().deleteAllCookies();

	}



}