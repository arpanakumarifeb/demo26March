package com.elx.nc.tests;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import com.elx.common.Common;
import com.elx.core.Screenshot;
import com.elx.core.util.CustomReport;
import com.elx.framework.base.SeleniumDriverUtil;
import com.elx.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;
import com.web.elx.pages.*;
import com.elx.common.ExcelManager;

import jxl.read.biff.BiffException;

/**
 * JCREW OMNITURE VERIFICATION class
 */
@Listeners({ CustomReport.class, Screenshot.class })
public class ElectroluxPOEScreenValidation extends WebTestCase {
	//private static final boolean true = true;
	private SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	HashMap<String, String> map = new HashMap<String, String>();

	private Common common = new Common(driver);
	ExcelManager ex = new ExcelManager();
	ReadConfig testData = new ReadConfig();

	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ElectroluxPOEScreenValidation.class.getName());
	private String url = null;
	SoftAssert softAssert = new SoftAssert();
	String PlantName = null;
	String ScreenshotRequire = null;
	String WantToExecuteForAllWC = null;

	@BeforeMethod(alwaysRun = true)
	public void initialize(ITestContext testContext) {
		driver = selenium.getDriver();
		System.out.println("driver..>" + driver);
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
		common = new Common(driver);
		common.impicitWait(10);
		testContext.setAttribute("driver", driver);
		getDriver().manage().deleteAllCookies();
		common.impicitWait(4);
		getDriver().manage().window().maximize();
		url = testContext.getCurrentXmlTest().getParameter("URL");
		PlantName = testContext.getCurrentXmlTest().getParameter("PlantName");
		ScreenshotRequire = testContext.getCurrentXmlTest().getParameter("ScreenShotRequire");
		getDriver().get(url);
		getDriver().manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		WantToExecuteForAllWC = testContext.getCurrentXmlTest().getParameter("WantToExecuteForAllWC");
	}

	// ***************************************************************************************************************************************
	// * NAME : ValidatePOEScreenFieldsAndStatusDropDown
	// * DESCRIPTION : This method is validating POE screen
	// * AUTHOR : Arpana
	// * DATE : 27-Nov-2018
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  enabled = true,testName = "ValidatePOEScreenFieldsAndStatusDropDown", description = "ValidatePOEScreenFieldsAndStatusDropDown",  groups = {
			"POE", "GLOBAL" })
	public void ValidatePOEScreenFieldsAndStatusDropDown(Hashtable<String, String> data)
			throws IOException, InterruptedException, AWTException, BiffException {

		String screenshot = null;
		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		test.log(LogStatus.INFO, "********** Validate Login Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);


		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][0],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select Area" + hm2[0][0]+"**" + screenshot);
		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][1],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select a work-center " + hm2[0][1] + screenshot);
		getPageFactory().getOrderExecution().validatePOEScreen(data.get("elx.poe.header"),ScreenshotRequire);

		if (!data.get("Header3").toLowerCase().equals("17FieldsIcons") && data.get("Header3") != null) {
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header3"), PlantName);
			System.out.println("data for Header3 is " + PlantName + " is:" + hm);
			getPageFactory().getOrderExecution().validateAllPOEScreenSearchHeaderValidation(hm,"true");
			test.log(LogStatus.INFO,"*********Validated POE Screen header fields successfully******* ");
		}
		if (!data.get("Header4").toLowerCase().equals("StatusDropdownValues") && data.get("Header4") != null) {
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header4"), PlantName);
			System.out.println("data for Header4: " + PlantName + " is:" + hm);
			getPageFactory().getOrderExecution().validateStatusFields(hm,"true");
			test.log(LogStatus.INFO,"*********Validated POE Screen Status Drop down Values successfully******* ");
		}
	}

	// ***************************************************************************************************************************************
	// * NAME : ValidatePOEScreenFooterButtons
	// * DESCRIPTION : This method is validating All footer buttons in POE screen
	// * AUTHOR : Arpana
	// * DATE : 6-Dec-2018
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata", enabled = true, testName = "ValidatePOEScreenButtons", description = "ValidatePOEScreenButtons",  groups = {
			"POE", "LOCAL" })
	public void ValidatePOEScreenFooterButtons(Hashtable<String, String> data)
			throws IOException, InterruptedException, AWTException, BiffException {

		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String screenshot = null;
		test.log(LogStatus.INFO, "********** Validate Login Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {

			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);

		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);

		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][0],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select an Area " + hm2[0][0]  + screenshot);
		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][1],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select a work-center " + hm2[0][1] + screenshot);
		getPageFactory().getOrderExecution().validatePOEScreen(data.get("elx.poe.header"),ScreenshotRequire);

		HashMap<Integer, String> ButtonStatusFor_Started = new HashMap<Integer, String>();
		ButtonStatusFor_Started = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header2"), PlantName);


		HashMap<Integer, String> ButtonStatusFor_ON_Hold = new HashMap<Integer, String>();
		ButtonStatusFor_ON_Hold = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header3"), PlantName);

		HashMap<Integer, String> ButtonStatusFor_New = new HashMap<Integer, String>();
		ButtonStatusFor_New = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header4"), PlantName);

		HashMap<Integer, String> ButtonStatusFor_Off_Hold = new HashMap<Integer, String>();
		ButtonStatusFor_Off_Hold = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header5"), PlantName);

		int totalOrder = getPageFactory().getOrderExecution().validateTotalOrderDetails(ScreenshotRequire);
		if(totalOrder>0) {
			getPageFactory().getOrderExecution().validatePrimaryButtonsWithStatus("Started",ButtonStatusFor_Started,"true");
			test.log(LogStatus.INFO, "**********************");
			getPageFactory().getOrderExecution().validatePrimaryButtonsWithStatus("On Hold",ButtonStatusFor_ON_Hold,"true");
			test.log(LogStatus.INFO, "**************************");
			getPageFactory().getOrderExecution().validatePrimaryButtonsWithStatus("New",ButtonStatusFor_New,"true");

			getPageFactory().getOrderExecution().validatePrimaryButtonsWithStatus("Off-Hold",ButtonStatusFor_Off_Hold,"true");

			test.log(LogStatus.INFO, "*******************************");
			test.log(LogStatus.INFO, "*********Validated POE Screen Footer Buttons  Successfully******* ");
		}else {
			test.log(LogStatus.WARNING, "*********Orders are not available for testing******* ");
		}
	}

	// ***************************************************************************************************************************************
	// * NAME : operatorConsoleHeaderButtonValidationPOEScreen
	// * DESCRIPTION : This method is validating All buttons in footer sections
	// of operatorConsole screen
	// * AUTHOR : Chinmay
	// * DATE : 29-Nov-2018
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  enabled = true, testName = "operatorConsoleHeaderFotterButtonValidation", description = "operatorConsoleHeaderFotterButtonValidation", groups = {
			"OPERATORCONSOLE", "GOBAL" })
	public void operatorConsoleHeaderButtonValidationPOEScreen(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();
		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);
		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String screenshot = null;
		test.log(LogStatus.INFO, "********** Validate Login Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {

			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);

		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);
		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][0],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select a Line " + hm2[0][0] + screenshot);

		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][1],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select a work-center " + hm2[0][0] + screenshot);
		getPageFactory().getOrderExecution().validatePOEScreen(data.get("elx.poe.header"),ScreenshotRequire);
		String orderDetails = getPageFactory().getOrderExecution().searchOrderOnOrderCockpitPage(
				data.get("elx.orderSatusStarted"), "", hm2[0][0],ScreenshotRequire);
		if(orderDetails!=null) {
			if (!data.get("Header1").toLowerCase().equals("HeaderIconDetails") && data.get("Header1") != null) {
				HashMap<Integer, String> hm = new HashMap<Integer, String>();
				hm = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header1"), PlantName);
				getPageFactory().getOperatorConsole().validateHeaderButtons(hm,"true");
			}
			if (!data.get("Header2").toLowerCase().equals("OprcIcon Details") && data.get("Header2") != null) {
				ElectroluxPOEScreenValidation DT1 = new ElectroluxPOEScreenValidation();
				HashMap<Integer, String> hm = new HashMap<Integer, String>();
				hm = DT1.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header2"), PlantName);
				//*** i will change later
				getPageFactory().getOperatorConsole().validatefooterbuttons(hm,"true");
				test.log(LogStatus.INFO, "*********Validated Operator Console Header and Footer button  Successfully******* ");

			}
		}else{
			test.log(LogStatus.WARNING, "*********Orders are not available for testing******* ");
		}
	}

	// ***************************************************************************************************************************************
	// * NAME : startAndHoldAssemblyLinesOrderFromProductionOrderExecutionOfPOEScreen
	// * DESCRIPTION : This method is validating to start and hold Assembly Lines order from order execution page in POE screen
	// * AUTHOR : Arpana
	// * DATE : 15-Jan-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",enabled = true,  testName = "startAndHoldAssemblyLinesOrderFromProductionOrderExecutionOfPOEScreen", description = "startAndHoldAssemblyLinesOrderFromProductionOrderExecutionOfPOEScreen",  groups = {
			"OPERATORCONSOLE", "GOBAL" })
	public void startAndHoldAssemblyLinesOrderFromProductionOrderExecutionOfPOEScreen(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);

		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("HeaderLineActiveStatus"),PlantName);

		String screenshot = null;
		test.log(LogStatus.INFO, "********** Validate to start order from order execution page in POE screen Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);
		int i=0;
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}
			for(int p=0;p<=LineActiveStatus.length-1;p++) {
				if(LineActiveStatus[p][0].contains(hm2[j][0])&&LineActiveStatus[p][1].length()>1) {

					for (int k = 0; k < TotalWCCount; k++) {
						System.out.println("area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);
						test.log(LogStatus.INFO, "Testing started for area:: "+hm2[j][0] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);	
						if(hm2[j][k+1+WCIndexToExecute]!=null) {
							test.log(LogStatus.INFO, "Select:: "+ hm2[j][k+1+WCIndexToExecute]);

							System.out.print("area:"+hm2[j][0] + " ");
							screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]).trim(),ScreenshotRequire);
							test.log(LogStatus.INFO, "Selected a Line " + screenshot);
							System.out.print("WC: "+hm2[j][k+1+WCIndexToExecute] + " ");

							screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[j][k+1+WCIndexToExecute].trim(),ScreenshotRequire);
							test.log(LogStatus.INFO, "Selected a work-center" + screenshot);
							getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
							getPageFactory().getOrderExecution().validatePOEScreenAreaName(hm2[j][k+1+WCIndexToExecute].trim(),ScreenshotRequire);
							int totalOrder = getPageFactory().getOrderExecution().validateTotalOrderDetails(ScreenshotRequire);
							if(totalOrder>0) {
								getPageFactory().getOrderExecution().searchOrderOnOrderExecutionPageAndOffHoldStart("Off-Hold","true");
								getPageFactory().getOrderExecution().searchOrderOnOrderExecutionPageAndHoldToOffHold("On Hold","true");
								getPageFactory().getOrderExecution().searchOrderOnOrderExecutionPageAndStart("New","true");
								getPageFactory().getOrderExecution().searchOrderOnOrderExecutionPageAndHold("Started","true");
							}else {
								test.log(LogStatus.WARNING, "*********No order available to perform the operation***********");
							}
							getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);

						}
					}
					break;
				}
			}
		}

		test.log(LogStatus.INFO, "*********Validated start and hold Assembly Lines Order From Production Order Execution Of POE Screen Successfully******* ");
	}


	// ***************************************************************************************************************************************
	// * NAME : createNCFromPOEScreenAndResolve
	// * DESCRIPTION : This method is validating to createNC from POE screen, validate and resolve
	// * AUTHOR : Arpana
	// * DATE : 23-Jan-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",enabled = true,   testName = "createNCFromPOEScreenAndResolve", description = "createNCFromPOEScreenAndResolve", groups = {
			"POE", "GOBAL" })
	public void createNCFromPOEScreenAndResolve(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);


		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("HeaderLineActiveStatus"),PlantName);


		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);

		String screenshot = null;
		test.log(LogStatus.INFO, "********** Validate to createNC and resolve NC from POE screen Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);


		Thread.sleep(6000);
		WebDriver driver2= new ChromeDriver();                                    
		driver2.get(url);
		driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver2.manage().window().maximize();                
		Thread.sleep(5000);

		((JavascriptExecutor)driver2).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver2);

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);

		String pageTitle2=getDriver().getCurrentUrl();
		if (pageTitle2.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire); 
		Thread.sleep(5000);


		int i=0;
		String serialNumber=null;
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}
			for(int p=0;p<LineActiveStatus.length-1;p++) {
				if(LineActiveStatus[p][0].contains(hm2[j][i])&&LineActiveStatus[p][1].length()>1) {

					for (int k = 0; k < TotalWCCount; k++) {
						System.out.println("area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);
						test.log(LogStatus.INFO, "Testing started for area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);	
						if(hm2[j][k+1+WCIndexToExecute]!=null) {

							((JavascriptExecutor)driver2).executeScript("window.focus();");
							pageFactory = new WebPageFactory(driver2);

							String sharedFlag=null;
							if(SharedWCRule.length>0) {
								sharedFlag= common.validateSharedWC(hm2[j][k+1+WCIndexToExecute].trim().toLowerCase(),SharedWCRule);
							}else {
								sharedFlag="nonShared";
							}
							screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectORDScreen"),ScreenshotRequire); 
							getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ORDPageTitle"),ScreenshotRequire);
							String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("elx.orderSatusStarted"),"", (hm2[j][i]),ScreenshotRequire);
							if(orderDetails!=null) {
								String [] splits=common.splitValues(orderDetails,"_");		
								String oId=splits[0].trim();
								getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("elx.ordOperationTitle"),ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateGeneralTabOrderDetails(oId,ScreenshotRequire);
								String nonConformanceCount = getPageFactory().getOrderOperationPage().validateNCCountOnOrderOperationPage(oId,ScreenshotRequire);
								map.put("NCCOUNT", nonConformanceCount);			
								serialNumber= getPageFactory().getOrderOperationPage().validateSerialNoTabDetails(oId,ScreenshotRequire);
								test.log(LogStatus.INFO, "Selected serial no " + serialNumber + " from Order operation Page");
								System.out.println("value of serial no:" + serialNumber);
								getPageFactory().getOrderOperationPage().clickHomeIcon(ScreenshotRequire);
							}
							((JavascriptExecutor)driver).executeScript("window.focus();");
							pageFactory = new WebPageFactory(driver);

							System.out.print("area:"+hm2[j][i] + " ");
							screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]),ScreenshotRequire);
							test.log(LogStatus.INFO, "Selected a Line " + screenshot);
							System.out.print("WC: "+hm2[j][k+1+WCIndexToExecute] + " ");

							screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
							test.log(LogStatus.INFO, "Selected a work-center" + screenshot);
							getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
							getPageFactory().getOrderExecution().validatePOEScreenAreaName(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
							String ncCount1= getPageFactory().getOrderExecution().vaidateNonConformityIconCount(ScreenshotRequire);
							screenshot = getPageFactory().getOrderExecution().clickCreateNC(ScreenshotRequire);		
							getPageFactory().getNCInfoPage().validateNCInfoPageTitle(data.get("createNCPageTitle"),ScreenshotRequire);
							test.log(LogStatus.INFO, "*********Select reason code******");

							String ncReasonCodes=getPageFactory().getCreateNC().reasonCodesSelection(data.get("elx.reason.code"),ScreenshotRequire);
							String [] NCReason=common.splitValues(ncReasonCodes,"_");
							getPageFactory().getCreateNC().selectWorkCenter(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
							getPageFactory().getCreateNC().enterSerialNumber(serialNumber,sharedFlag,ScreenshotRequire);
							getPageFactory().getCreateNC().ClickSaveBtn(ScreenshotRequire);
							String ncCount2= getPageFactory().getOrderExecution().vaidateNonConformityIconCount(ScreenshotRequire);
							if(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount1)) {
								test.log(LogStatus.INFO, "Previous NC count was:--"+ncCount1+" , Current NC count after NC increased to:--"+ncCount2);	
							}else {
								softAssert.assertTrue(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount1),"NC count not increased") ;
								test.log(LogStatus.INFO, "Previous NC count was:--"+ncCount1+" , Current NC count after NC created increased to:--"+ncCount2);
							}
							getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
							getPageFactory().getOrderExecution().clickAndValidateOnNCIconAndClose(NCReason,data.get("elx.reasoncode.nonConformity.status"),ScreenshotRequire);
							getPageFactory().getOrderExecution().clickAndValidateOnNCIconAndClick(NCReason,data.get("elx.reasoncode.nonConformity.status"),ScreenshotRequire);
							getPageFactory().getNCInfoPage().clickOnResolveButton("true");
							getPageFactory().getOrderExecution().validatePOEScreen(data.get("elx.poe.header"),ScreenshotRequire);

							String ncCount4= getPageFactory().getOrderExecution().vaidateNonConformityIconCount("true");

							if(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount4)) {
								System.out.println("Previous NC count before resolve was:--"+ncCount2+" , Current NC count after resolve its decreased to:--"+ncCount4);
								test.log(LogStatus.INFO, "Previous NC count before resolve was:--"+ncCount2+" , Current NC count after resolve its decreased to:--"+ncCount4);
							}else {
								System.out.println("Previous NC count before resolve was:--"+ncCount2+" , Current NC count after resolve its decreased to:--"+ncCount4);
								softAssert.assertTrue(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount4),"NC count not decreased") ;
								test.log(LogStatus.INFO, "Previous NC count before resolve was:--"+ncCount2+" , Current Work center count after resolve its decreased to:--"+ncCount4);
							}
							getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
						}
						break;
					}
				}
			}
		}
		driver2.close();


		test.log(LogStatus.INFO, "*********Validated create and resolve NC from POE Screen Successfully******* ");
	}


	// ***************************************************************************************************************************************
	// * NAME : createNCFromOperatorConsoleScreenAndResolve
	// * DESCRIPTION : This method is validating to createNC from operator console screen, validate and resolve
	// * AUTHOR : Arpana
	// * DATE : 23-Jan-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  enabled = true,testName = "createNCFromOperatorConsoleScreenAndResolve", description = "createNCFromOperatorConsoleScreenAndResolve",  groups = {
			"POE", "GOBAL" })
	public void createNCFromOperatorConsoleScreenAndResolve(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;
		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);
		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);


		test.log(LogStatus.INFO, "********** Validate to createNC and resolve NC from operator console screen Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");

		Thread.sleep(6000);
		WebDriver driver2= new ChromeDriver();                                    
		driver2.get(url);
		driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver2.manage().window().maximize();                
		Thread.sleep(5000);

		((JavascriptExecutor)driver2).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver2);

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);

		String pageTitle2=getDriver().getCurrentUrl();
		if (pageTitle2.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire); 
		Thread.sleep(5000);
		String serialNumber=null;
		String sharedFlag=null;
		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("HeaderLineActiveStatus"),PlantName);

		int i=0;
		String oId=null;
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}
			for(int p=0;p<=LineActiveStatus.length;p++) {
				if(LineActiveStatus[p][0].contains(hm2[j][0])&&LineActiveStatus[p][1].length()>1) {

					for (int k = 0; k < TotalWCCount; k++) {
						System.out.println("area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);
						test.log(LogStatus.INFO, "Testing started for area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);	
						if(hm2[j][k+1+WCIndexToExecute]!=null) {
							((JavascriptExecutor)driver2).executeScript("window.focus();");
							pageFactory = new WebPageFactory(driver2);if(SharedWCRule.length>0) {
								sharedFlag= common.validateSharedWC(hm2[j][k+1+WCIndexToExecute].trim().toLowerCase(),SharedWCRule);
							}else {
								sharedFlag="nonShared";
							}

							screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectORDScreen"),ScreenshotRequire); 
							getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ORDPageTitle"),ScreenshotRequire);
							String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("elx.orderSatusStarted"),"", (hm2[j][i]),ScreenshotRequire);
							if(orderDetails!=null) {
								String [] splits=common.splitValues(orderDetails,"_");		
								oId=splits[0].trim();
								getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("elx.ordOperationTitle"),ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateGeneralTabOrderDetails(oId,ScreenshotRequire);
								String nonConformanceCount = getPageFactory().getOrderOperationPage().validateNCCountOnOrderOperationPage(oId,ScreenshotRequire);
								map.put("NCCOUNT", nonConformanceCount);			
								serialNumber= getPageFactory().getOrderOperationPage().validateSerialNoTabDetails(oId,ScreenshotRequire);
								test.log(LogStatus.INFO, "Selected serial no " + serialNumber + " from Order operation Page");
								System.out.println("value of serial no:" + serialNumber);
								getPageFactory().getOrderOperationPage().clickHomeIcon(ScreenshotRequire);
							}else {
								test.log(LogStatus.WARNING, "Orders are not available for testing");

							}
							((JavascriptExecutor)driver).executeScript("window.focus();");
							pageFactory = new WebPageFactory(driver);

							screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);
							test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);
							System.out.print("area:"+hm2[j][i] + " ");
							screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]),ScreenshotRequire);
							test.log(LogStatus.INFO, "Selected a Line " + screenshot);
							System.out.print("WC: "+hm2[j][k+1+WCIndexToExecute] + " ");

							screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
							test.log(LogStatus.INFO, "Selected a work-center" + screenshot);
							getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
							getPageFactory().getOrderExecution().validatePOEScreenAreaName(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
							//String ncCount1= getPageFactory().getOrderExecution().vaidateNonConformityIconCount();
							String orderIdDetails= getPageFactory().getOrderExecution().searchOrderOnOrderCockpitPage(data.get("elx.orderSatusStarted"),oId,hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
							if(orderIdDetails!=null) {
								getPageFactory().getOperatorConsole().validateOperatorConsolePageTitle(data.get("OperatorConsolePageTitle"),ScreenshotRequire);
								String ncCount1= getPageFactory().getOperatorConsole().vaidateNonConformityIconCount(ScreenshotRequire);
								screenshot = getPageFactory().getOperatorConsole().clickCreateNC(ScreenshotRequire);
								if(!(hm2[j][k+1+WCIndexToExecute]).contains("WT")&&!(hm2[j][k+1+WCIndexToExecute]).contains("PO")) {
									String selectOperation = getPageFactory().getOperatorConsole().selectOperation(ScreenshotRequire);
								}
								getPageFactory().getNCInfoPage().validateNCInfoPageTitle(data.get("createNCPageTitle"),ScreenshotRequire);
								test.log(LogStatus.INFO, "*********Select reason code******");

								String ncReasonCodes=getPageFactory().getCreateNC().reasonCodesSelection(data.get("elx.reason.code"),ScreenshotRequire);
								String [] NCReason=common.splitValues(ncReasonCodes,"_");
								getPageFactory().getCreateNC().selectWorkCenter(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
								getPageFactory().getCreateNC().enterSerialNumber(serialNumber,sharedFlag,ScreenshotRequire);
								getPageFactory().getCreateNC().ClickSaveBtn(ScreenshotRequire);
								getPageFactory().getOperatorConsole().validateOperatorConsolePageTitle(data.get("OperatorConsolePageTitle"),ScreenshotRequire);
								String ncCount2= getPageFactory().getOperatorConsole().vaidateNonConformityIconCount("true");
								if(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount1)) {
									test.log(LogStatus.INFO, "Previous NC count was:--"+ncCount1+" , Current NC count after NC increased to:--"+ncCount2);	
								}else {
									softAssert.assertTrue(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount1),"NC count not increased") ;
									test.log(LogStatus.FAIL, "Previous NC count was:--"+ncCount1+" , Current NC count after NC created increased to:--"+ncCount2);
								}
								getPageFactory().getOrderExecution().clickAndValidateOnNCIconAndClose(NCReason,data.get("elx.reasoncode.nonConformity.status"),"true");
								getPageFactory().getOrderExecution().clickAndValidateOnNCIconAndClick(NCReason,data.get("elx.reasoncode.nonConformity.status"),"true");
								getPageFactory().getNCInfoPage().clickOnResolveButton(ScreenshotRequire);
								getPageFactory().getOperatorConsole().validateOperatorConsolePageTitle(data.get("OperatorConsolePageTitle"),ScreenshotRequire);

								String ncCount4= getPageFactory().getOrderExecution().vaidateNonConformityIconCount("true");

								if(Integer.parseInt(ncCount2)>Integer.parseInt(ncCount4)) {
									System.out.println("Previous NC count before resolve was:--"+ncCount2+" , Current NC count after resolve its decreased to:--"+ncCount4);
									test.log(LogStatus.INFO, "Previous NC count before resolve was:--"+ncCount2+" , Current NC count after resolve its decreased to:--"+ncCount4);
								}else {
									System.out.println("Previous NC count before resolve was:--"+ncCount2+" , Current NC count after resolve its decreased to:--"+ncCount4);
									test.log(LogStatus.FAIL, "Previous NC count before resolve was:--"+ncCount2+" , Current Work center count after resolve its decreased to:--"+ncCount4);
								}
							}else {
								test.log(LogStatus.WARNING, "Orders are not available for testing");

							}
							getPageFactory().getAprisoCommonPage().clickHomeIcon(ScreenshotRequire);
						}
					}
					break;
				}
			}
		}

		test.log(LogStatus.INFO, "*********Validated create and resolve NC from operator console Screen Successfully******* ");
	}

	// ***************************************************************************************************************************************
	// * NAME : validateProgressBarInPOEScreen
	// * DESCRIPTION : This method is validating Progress Bar in POE Screen
	// * AUTHOR : Arpana
	// * DATE : 15-Jan-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  enabled = true,testName = "validateProgressBarInPOEScreen", description = "validateProgressBarInPOEScreen",  groups = {
			"OPERATORCONSOLE", "GOBAL" })
	public void validateProgressBar(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String screenshot = null;
		test.log(LogStatus.INFO, "********** Validate to Progress Bar in POE Screen Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);

		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("HeaderLineActiveStatus"),PlantName);

		int i=0;
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}
			for(int p=0;p<=LineActiveStatus.length;p++) {
				if(LineActiveStatus[p][0].contains(hm2[j][0])&&LineActiveStatus[p][1].length()>1) {

					for (int k = 0; k < TotalWCCount; k++) {
						System.out.println("area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);
						test.log(LogStatus.INFO, "Testing started for area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);	
						if(hm2[j][k+1+WCIndexToExecute]!=null) {
							screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]),ScreenshotRequire);
							test.log(LogStatus.INFO, "Selected a Line " + screenshot);
							System.out.print("WC: "+hm2[j][k+1+WCIndexToExecute] + " ");

							screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
							test.log(LogStatus.INFO, "Selected a work-center" + screenshot);
							getPageFactory().getOrderExecution().validatePOEScreen(data.get("POEPageTitle"),ScreenshotRequire);
							getPageFactory().getOrderExecution().validatePOEScreenAreaName(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
							int totalOrder = getPageFactory().getOrderExecution().validateTotalOrderDetails(ScreenshotRequire);
							if(totalOrder>0) {
								getPageFactory().getOrderExecution().searchOrderOnOrderExecutionPageWithStatus("Started",ScreenshotRequire);
								getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
							}else {
								test.log(LogStatus.WARNING, "*********No order available to perform the operation***********");
							}
						}
					}
					break;
				}
			}
		}

		test.log(LogStatus.INFO, "*********validated Progress Bar  Button Functionality for  Order In POE Screen Successfully******* ");
	}


	// ***************************************************************************************************************************************
	// * NAME : validateColorCodeforAssemblyLinesOrderInPOEScreen
	// * DESCRIPTION : This method is validating color code in Assembly Lines Order in POE Screen
	// * AUTHOR : Arpana
	// * DATE : 15-Jan-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  enabled = true, testName = "validateColorCodeforAssemblyLinesOrderInPOEScreen", description = "validateColorCodeforAssemblyLinesOrderInPOEScreen", groups = {
			"OPERATORCONSOLE", "GOBAL" })
	public void validateColorCodeforAssemblyLinesOrderInPOEScreen(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String screenshot = null;
		test.log(LogStatus.INFO, "********** Validate to Progress Bar for Assembly Lines Order in POE Screen Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);
		driver.getWindowHandle();
		Thread.sleep(6000);
		WebDriver driver2= new ChromeDriver();                                    
		driver2.get(url);
		driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver2.manage().window().maximize();                
		driver2.getWindowHandles();                        
		Thread.sleep(5000);

		((JavascriptExecutor)driver2).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver2);

		test.log(LogStatus.INFO,"**********Validate Login Functionality for operator window 2********");		

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );

		String pageTitle2=getDriver().getCurrentUrl();
		if (pageTitle2.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");

		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwith.NCM"),ScreenshotRequire);
		test.log(LogStatus.INFO, "*********Verification on create NC Functionality******" + screenshot);

		((JavascriptExecutor)driver).executeScript("window.focus();");
		pageFactory = new WebPageFactory(driver); 

		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][0],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select Area" + hm2[0][0] + screenshot);
		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][1],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select a work-center " + hm2[0][1] + screenshot);
		getPageFactory().getOrderExecution().validatePOEScreen(data.get("elx.poe.header"),ScreenshotRequire);

		getPageFactory().getOrderExecution().validatePOEScreenAreaName(hm2[0][1],ScreenshotRequire);
		int totalOrder = getPageFactory().getOrderExecution().validateTotalOrderDetails(ScreenshotRequire);
		if(totalOrder>0) {
			/*getPageFactory().getOrderExecution().searchOrderOnOrderExecutionPageWithColorCodeGreen();
			//purple order verification
			String purpleOid=getPageFactory().getOrderExecution().searchOrderOnOrderExecutionPageWithColorCodePurple();
			if(purpleOid!=null) {
				((JavascriptExecutor)driver2).executeScript("window.focus();");
				pageFactory = new WebPageFactory(driver2); 
				test.log(LogStatus.INFO, "Searched for NCM option and click");
				getPageFactory().getNCListPage().validateNCListPageTitle();
				int NCCount= getPageFactory().getNCListPage().searchOrderIdAndValidateNCCount(purpleOid);
			}
			((JavascriptExecutor)driver).executeScript("window.focus();");
			pageFactory = new WebPageFactory(driver);*/
			//red order verification

			String redOid=getPageFactory().getOrderExecution().searchOrderOnOrderExecutionPageWithColorCodeRed(ScreenshotRequire);
			if(redOid!=null) {
				//ORD screen
				Thread.sleep(6000);
				WebDriver driver3= new ChromeDriver();                                    
				driver3.get(url);
				driver3.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
				driver3.manage().window().maximize();                
				Thread.sleep(5000);

				((JavascriptExecutor)driver3).executeScript("window.focus();");
				pageFactory = new WebPageFactory(driver3);

				test.log(LogStatus.INFO,"**********Validate Login Functionality for operator window ********");		

				getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
				test.log(LogStatus.INFO,
						"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
				screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
				test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
				String pageTitle3=getDriver().getCurrentUrl();
				if (pageTitle2.contains("apriso.electrolux-na")) {
					screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
				} else {
					screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
				}
				screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire); 

				test.log(LogStatus.INFO, "Login successfully" );
				test.log(LogStatus.INFO,"**********Validated Login Functionality successfully for Supervisor********");
				Thread.sleep(5000);
				screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("selectORDScreen"),ScreenshotRequire); 
				test.log(LogStatus.INFO, "Searched for ORD option and click" + screenshot);	
				getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ORDPageTitle"),ScreenshotRequire);
				getPageFactory().getOrderCockPage().validateOrderColor(redOid,"true");
				driver3.close();
			}
			driver2.close();
			test.log(LogStatus.INFO, "*********Validated order color code in POE screen successfully***********");
		}else {
			test.log(LogStatus.WARNING, "*********No order available to perform the operation***********");
		}
	}

	// ***************************************************************************************************************************************
	// * NAME : validateExpstartDateAndExpEndDateOfPOEScreenWithORDScreen
	// * DESCRIPTION : This method is validating  exp start /end date of POE screen with ORD screen
	// * AUTHOR : Arpana
	// * DATE : 11-Mar-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  enabled = true, testName = "validateExpStartDateAndExpEndDateOfPOEScreenWithORDScreen", description = "validateExpStartDateAndExpEndDateOfPOEScreenWithORDScreen", groups = {
			"POE", "LOCAL" })
	public void validateExpstartDateAndExpEndDateOfPOEScreenWithORDScreen (Hashtable<String, String> data)
			throws IOException, InterruptedException, AWTException, BiffException {
		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);


		String screenshot = null;
		test.log(LogStatus.INFO, "********** Validate Login Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);

		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][0],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select Area" + hm2[0][0] + screenshot);
		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][1],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select a work-center " + hm2[0][1] + screenshot);
		getPageFactory().getOrderExecution().validatePOEScreen(data.get("elx.poe.header"),ScreenshotRequire);

		int totalOrder = getPageFactory().getOrderExecution().validateTotalOrderDetails(ScreenshotRequire);
		if(totalOrder>0) {
			HashMap<String, String> poeData = new HashMap<String, String>();
			poeData=getPageFactory().getOrderExecution().getFirstPOEScreenOrderDetails(ScreenshotRequire);
			getPageFactory().getAprisoCommonPage().clickHomeIcon(ScreenshotRequire);
			getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
			test.log(LogStatus.INFO, "Searched for ORD option and click");
			getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);
			getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPageWithOId(poeData.get("orderNo"),"true");
			getPageFactory().getOrderCockPage().validatePOEScreenWithORDScreen(poeData,"true");
			test.log(LogStatus.INFO, "*********Validated Dates from POE and ORD screen Successfully for order****"+poeData.get("orderNo"),ScreenshotRequire);		
		}else {
			test.log(LogStatus.WARNING,"********no order available for operation *********");
		}
	}

	// ***************************************************************************************************************************************
	// * NAME : ValidatePOEOrderStatus
	// * DESCRIPTION : select status dropdown in POE screen and order status will appear accordingly
	// * AUTHOR : Chinmay
	// * DATE : 20-Feb-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  testName = "ValidatePOEOrderStatus", description = "ValidatePOEOrderStatus", enabled = true, groups = {
			"POE", "LOCAL" })
	public void ValidatePOEOrderStatus(Hashtable<String, String> data)
			throws IOException, InterruptedException, AWTException, BiffException {
		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);


		String screenshot = null;
		test.log(LogStatus.INFO, "********** Validate Login Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}

		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");
		Thread.sleep(5000);
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);


		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][0],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select Area" + hm2[0][0] + screenshot);
		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][1],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select a work-center " + hm2[0][1] + screenshot);
		getPageFactory().getOrderExecution().validatePOEScreen(data.get("elx.poe.header"),ScreenshotRequire);


		int totalOrder = getPageFactory().getOrderExecution().validateTotalOrderDetails("true");
		if(totalOrder>0) {
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusStarted"),"true");
			test.log(LogStatus.INFO, "*********Compared order status from List with Order status From Status dropdown for order type Started***********");
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusHold"),"true");
			test.log(LogStatus.INFO, "*********Compared order status from List with Order status From Status dropdown for order type Hold***********");
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusNew"),"true");
			test.log(LogStatus.INFO, "*********Compared order status from List with Order status From Status dropdown for order type New***********");
			getPageFactory().getOrderExecution().compareorderStatusWithStatusDropdown(data.get("elx.orderSatusOffHold"),"true");
			test.log(LogStatus.INFO, "*********Compared order status from List with Order status From Status dropdown for order type Off-Hold***********");

		}else {
			test.log(LogStatus.WARNING, "*********No order available to perform the operation***********");
		}


		test.log(LogStatus.INFO, "*********Compared Orders status  from  tables with respective Status dropdown values  Successfully******* ");
	}

	// ***************************************************************************************************************************************
	// * NAME : ValidateFooterButtonsMordersPOEScreen
	// * DESCRIPTION : This method is validating All buttons in POE screen For M Order
	// * AUTHOR : Chinmay
	// * DATE : 6-March-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  enabled = true, testName = "ValidateFooterButtonsMordersPOEScreen", description = "ValidateFooterButtonsMordersPOEScreen", groups = {
			"POE", "LOCAL" })
	public void ValidateFooterButtonsMordersPOEScreen(Hashtable<String, String> data)
			throws IOException, InterruptedException, AWTException, BiffException {

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		if(!(PlantName.contains("Anderson"))) {

			String screenshot = null;
			test.log(LogStatus.INFO, "********** Validate Login Functionality ********");
			getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
			test.log(LogStatus.INFO,
					"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
			screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
			test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
			String pageTitle = getDriver().getCurrentUrl();
			if (pageTitle.contains("apriso.electrolux-na")) {

				screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);

			} else {
				screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
			}

			screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);

			test.log(LogStatus.INFO, "Login successfully" );

			test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");
			Thread.sleep(5000);
			screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);

			test.log(LogStatus.INFO, "Searched for POE option and click" + screenshot);

			screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[3][0],ScreenshotRequire);
			test.log(LogStatus.INFO, "Select Area" + hm2[3][0] + screenshot);
			screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[3][1],ScreenshotRequire);
			test.log(LogStatus.INFO, "Select a work-center " + hm2[3][1] + screenshot);
			getPageFactory().getOrderExecution().validatePOEScreen(data.get("elx.poe.header"),ScreenshotRequire);


			HashMap<Integer, String> ButtonStatusFor_Started = new HashMap<Integer, String>();
			ButtonStatusFor_Started = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header2"), PlantName);


			HashMap<Integer, String> ButtonStatusFor_ON_Hold = new HashMap<Integer, String>();
			ButtonStatusFor_ON_Hold = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header3"), PlantName);

			HashMap<Integer, String> ButtonStatusFor_New = new HashMap<Integer, String>();
			ButtonStatusFor_New = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header4"), PlantName);

			HashMap<Integer, String> ButtonStatusFor_Off_Hold = new HashMap<Integer, String>();
			ButtonStatusFor_Off_Hold = ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header5"), PlantName);

			int totalOrder = getPageFactory().getOrderExecution().validateTotalOrderDetails(ScreenshotRequire);
			if(totalOrder>0) {
				getPageFactory().getOrderExecution().validatePrimaryButtonsWithStatus("Started",ButtonStatusFor_Started,"true");
				test.log(LogStatus.INFO, "**********************");
				getPageFactory().getOrderExecution().validatePrimaryButtonsWithStatus("On Hold",ButtonStatusFor_ON_Hold,"true");
				test.log(LogStatus.INFO, "**************************");

				getPageFactory().getOrderExecution().validatePrimaryButtonsWithStatus("New",ButtonStatusFor_New,"true");

				getPageFactory().getOrderExecution().validatePrimaryButtonsWithStatus("Off-Hold",ButtonStatusFor_Off_Hold,"true");
			}

			test.log(LogStatus.INFO, "*********Validated POE Screen Footer Buttons  Successfully For M Order******* ");
		}else {
			test.log(LogStatus.INFO, "*********This test script is not applicable for Anderson plant******* ");
		}
	}
	// * NAME : validateExportFunctionality
	// * DESCRIPTION : This method is validating Export Button in POE page
	// * AUTHOR : Arpana
	// * DATE : 11-mar-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata", enabled = true, testName = "validateExport Functionality in POE page", description = "Validating Export Function in POE page",  groups = {
			"NC", "GLOBAL" })
	public void validateExportButtonInPOEPage(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;
		ElectroluxPOEScreenValidation DT = new ElectroluxPOEScreenValidation();

		int rowCount=ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetNameArea"),data.get("Header"),PlantName);
		test.log(LogStatus.INFO, "**********Validate the POE page export button functionality********");

		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);

		test.log(LogStatus.INFO, "Login successfully" );

		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");

		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.POEScreen"),ScreenshotRequire);

		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][0],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select Area" + hm2[0][0] + screenshot);
		screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][1],ScreenshotRequire);
		test.log(LogStatus.INFO, "Select a work-center " + hm2[0][1] + screenshot);
		getPageFactory().getOrderExecution().validatePOEScreen(data.get("elx.poe.header"),ScreenshotRequire);

		getPageFactory().getNCInfoPage().clickonExport(ScreenshotRequire);
		test.log(LogStatus.INFO, "*********Verified Export Button Functionality in POE page******* ");
		File getLatestFile = getPageFactory().getOrderExecution().getLatestFilefromDir(System.getProperty("user.home")+"/Downloads/");
		String fileName = getLatestFile.getName();
		Assert.assertTrue(fileName.contains("export_page"), "Downloaded file name is not matching with expected file name");
		test.log(LogStatus.INFO, "*********Validated EXPORT button Functionality in POE page successfully ********");

	}

	@AfterMethod
	public void AfterMethodCleanUp(ITestContext testContext) {

		getDriver().manage().deleteAllCookies();
		// getDriver().close();
		// driver=null;
	}

}