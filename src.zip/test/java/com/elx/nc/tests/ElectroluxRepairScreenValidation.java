package com.elx.nc.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.*;

import com.elx.common.Common;
import com.elx.core.Screenshot;
import com.elx.core.util.CustomReport;
import com.elx.framework.base.SeleniumDriverUtil;
import com.elx.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;
import com.web.elx.pages.*;
import com.elx.common.ExcelManager;

import jxl.read.biff.BiffException;

/**
 * JCREW OMNITURE VERIFICATION class
 */
@Listeners({ CustomReport.class, Screenshot.class })
public class ElectroluxRepairScreenValidation extends WebTestCase {
	private SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	HashMap<String, String> map = new HashMap<String, String>();

	private Common common = new Common(driver);
	ExcelManager ex = new ExcelManager();
	ReadConfig testData = new ReadConfig();

	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ElectroluxRepairScreenValidation.class.getName());
	private String url = null;
	String PlantName = null;
	String ScreenshotRequire = null;

	@BeforeMethod(alwaysRun = true)
	public void initialize(ITestContext testContext) {
		driver = selenium.getDriver();
		System.out.println("driver..>" + driver);
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
		common = new Common(driver);
		common.impicitWait(10);
		testContext.setAttribute("driver", driver);
		getDriver().manage().deleteAllCookies();
		common.impicitWait(4);
		getDriver().manage().window().maximize();
		url = testContext.getCurrentXmlTest().getParameter("URL");
		PlantName = testContext.getCurrentXmlTest().getParameter("PlantName");
		ScreenshotRequire = testContext.getCurrentXmlTest().getParameter("ScreenShotRequire");
		//url="http://gautasan:home%40801@ppkinapriso.electrolux-na.com/apriso/start";
		getDriver().get(url);
		getDriver().manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
	}

	// ***************************************************************************************************************************************
	// * NAME : validateRepairWorkAreaSelectionScreen
	// * DESCRIPTION : This method is validating repair work area selection page
	// * AUTHOR : Arpana
	// * DATE : 15-Jan-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  testName = "validateRepairWorkAreaSelectionScreen", description = "validateRepairWorkAreaSelectionScreen", enabled = true, groups = {
			"RPC", "GOBAL" })
	public void validateRepairWorkAreaSelectionScreen(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		test.log(LogStatus.INFO, "********** Validate repair work area selection page Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link");
		getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("RPCScreenUserName"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("RPCScreen"),ScreenshotRequire);
		ElectroluxRepairScreenValidation DT = new ElectroluxRepairScreenValidation();
		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName1"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName1"),data.get("Header"),PlantName);
		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName1"),data.get("HeaderLineActiveStatus"),PlantName);
		int i=0;
		for (int j = 0; j < hm2.length; j++) {	

			test.log(LogStatus.INFO, "Testing started for area:: "+hm2[j][i]);	
			if(hm2[j][i]!=null) {
				getPageFactory().getWorkAreaPage().clickOnLineItem((hm2[j][i]),ScreenshotRequire);
				test.log(LogStatus.INFO, "********clicked on **********"+hm2[j][i]);
				String headerDetails = "OperationDetails_" + hm2[j][i];
				System.out.println("header selection:" + headerDetails);
				int rowCount1 = DT.ex.calculateRowCount(data.get("GlobalDataFileName"), data.get("SheetName"), headerDetails,
						PlantName);
				String[][] hm = new String[rowCount1][];
				test.log(LogStatus.INFO, "********Validated work centers are present **********");
				hm = DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"), data.get("SheetName"), headerDetails,
						PlantName);
				getPageFactory().getWorkAreaPage().ValidateRPCWorkCenterAndRepairStation(hm, rowCount,ScreenshotRequire);
			}}
		test.log(LogStatus.INFO, "*********Validated Repair work area selection page details Successfully******* ");
	}
	// ***************************************************************************************************************************************
	// * NAME : closedNCFromRPCScreenAndVerifyInPOEScreen
	// * DESCRIPTION : This method is validating close New NC from RPC screen and validate in RPC
	// * AUTHOR : Arpana
	// * DATE : 17-Jan-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  testName = "createNCFromNCMScreenAndCloseNCFromRPCScreen", description = "createNCFromNCMScreenAndCloseNCFromRPCScreenLine1", enabled = true, groups = {
			"RPC", "GOBAL" })
	public void createNCFromNCMScreenAndCloseNCFromRPCScreen(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		ElectroluxRepairScreenValidation DT = new ElectroluxRepairScreenValidation();
		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName1"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName1"),data.get("Header"),PlantName);

		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName1"),data.get("HeaderLineActiveStatus"),PlantName);

		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);

		String sharedFlag=null;
		if(SharedWCRule.length>0) {
			sharedFlag= common.validateSharedWC(hm2[0][1].trim().toLowerCase(),SharedWCRule);
		}

		String screenshot = null;
		test.log(LogStatus.INFO, "********** Validate repair work area selection page Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");			
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);		
		String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("elx.orderSatusStarted"),"", hm2[0][0],ScreenshotRequire);
		if(orderDetails!=null) {
			String [] splits=common.splitValues(orderDetails,"_");
			String oId=splits[0].trim();
			test.log(LogStatus.INFO, "Selected Order Id " + oId + " from Order Cockpit Page");
			getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("elx.ordOperationTitle"),ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateGeneralTabOrderDetails(oId,ScreenshotRequire);
			String nonConformanceCount = getPageFactory().getOrderOperationPage().validateNCCountOnOrderOperationPage(oId,ScreenshotRequire);
			map.put("NCCOUNT", nonConformanceCount);			

			String serialNumber= getPageFactory().getOrderOperationPage().validateSerialNoTabDetails(oId,ScreenshotRequire);
			test.log(LogStatus.INFO, "Selected serial no " + serialNumber + " from Order operation Page");
			System.out.println("value of serial no:" + serialNumber);
			getPageFactory().getOrderOperationPage().clickHomeIcon(ScreenshotRequire);

			screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwith.NCM"),ScreenshotRequire);
			test.log(LogStatus.INFO, "*********Verification on create NC Functionality******" + screenshot);
			screenshot = getPageFactory().getAprisoCommonPage().clickCreateNCButton(ScreenshotRequire);		
			getPageFactory().getNCInfoPage().validateNCInfoPageTitle(data.get("elx.createNC"),ScreenshotRequire);
			//getPageFactory().getCreateNC().enterSerialNumber(serialNumber);
			test.log(LogStatus.INFO, "*********Select reason code******" + screenshot);
			getPageFactory().getCreateNC().verifyReasonCodesSelection(data.get("elx.reason.code"),ScreenshotRequire);
			getPageFactory().getCreateNC().selectWorkCenter(hm2[0][1],ScreenshotRequire);
			getPageFactory().getCreateNC().enterSerialNumber(serialNumber,sharedFlag,ScreenshotRequire);
			getPageFactory().getCreateNC().ClickSaveBtn(ScreenshotRequire);
			String ncID=getPageFactory().getNCListPage().validateNcDetailsOnNcListPage(serialNumber,oId,data.get("elx.loginUser"),hm2[0][1],data,"true");
			test.log(LogStatus.INFO, "*********Validated new NC details successfully, new NC created ******* "+ ncID );

			driver.getWindowHandle();
			Thread.sleep(6000);
			WebDriver driver2= new ChromeDriver();                                    
			driver2.get(url);
			driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
			driver2.manage().window().maximize();                
			driver2.getWindowHandles();                        
			Thread.sleep(5000);

			((JavascriptExecutor)driver2).executeScript("window.focus();");
			pageFactory = new WebPageFactory(driver2);

			getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
			test.log(LogStatus.INFO,
					"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
			screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
			test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
			String pageTitle2 = getDriver().getCurrentUrl();
			if (pageTitle2.contains("apriso.electrolux-na")) {
				screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
			} else {
				screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
			}
			screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("RPCScreenUserName"), testData.getConfig().getProperty("password"),ScreenshotRequire);
			test.log(LogStatus.INFO, "Login successfully" );
			test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");
			screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("RPCScreen"),ScreenshotRequire);
			screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][0],ScreenshotRequire);
			screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][1],ScreenshotRequire);
			String headerDetails = "OperationDetails_" + hm2[0][0];
			String[][] hmRepairSt = new String[1][];
			hmRepairSt = DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"), data.get("SheetName"), headerDetails,
					PlantName);

			screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hmRepairSt[0][1],ScreenshotRequire);
			String NCID=getPageFactory().getRPCNCList().searchNcDetailsOnNcListPage(data, ncID,serialNumber,hm2[0][1],ScreenshotRequire);
			if(NCID!=null) {
				getPageFactory().getNCInfoPage().validateNCInfoPageTitle(ncID,ScreenshotRequire);
				getPageFactory().getNCInfoPage().clickOnCompleteButton(ScreenshotRequire);
				getPageFactory().getRPCNCList().validateCompletedNCDetailsOnRPCPage(ncID,"true");
				test.log(LogStatus.PASS, "*********Validated New to Closed NC functionality on repair NC page******* ");
			}else {
				test.log(LogStatus.INFO,"********NC details is not appearing in RPC list page**********");
			}
			driver2.close();

		}else{
			test.log(LogStatus.WARNING,"********No order available for Testing**********");

		}

	}

	// ***************************************************************************************************************************************
	// * NAME : validateScanSerialNumberInRPCScreen
	// * DESCRIPTION : This method is validating scan serial number in RPC page
	// * AUTHOR : Arpana
	// * DATE : 15-Jan-2019
	// ***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",  testName = "validateScanSerialNumberInRPCScreen", description = "validateScanSerialNumberInRPCScreen", enabled = true, groups = {
			"RPC", "GOBAL" })
	public void validateScanSerialNumberInRPCScreen(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;

		ElectroluxRepairScreenValidation DT = new ElectroluxRepairScreenValidation();
		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName1"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName1"),data.get("Header"),PlantName);


		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName1"),data.get("HeaderLineActiveStatus"),PlantName);


		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);

		String sharedFlag=null;
		WebDriver driver2= new ChromeDriver(); 
		try {
		if(SharedWCRule.length>0) {
			sharedFlag= common.validateSharedWC(hm2[0][1].trim().toLowerCase(),SharedWCRule);
		}
		test.log(LogStatus.INFO, "********** Validate repair work area selection page Functionality ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle = getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");			
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("elx.ordTitle"),ScreenshotRequire);

		String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("elx.orderSatusStarted"),"", hm2[0][0],ScreenshotRequire);
		if(orderDetails!=null) {
			String [] splits=common.splitValues(orderDetails,"_");

			String oId=splits[0].trim();

			test.log(LogStatus.INFO, "Selected Order Id " + oId + " from Order Cockpit Page");
			getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("elx.ordOperationTitle"),ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateGeneralTabOrderDetails(oId,ScreenshotRequire);
			String nonConformanceCount = getPageFactory().getOrderOperationPage().validateNCCountOnOrderOperationPage(oId,ScreenshotRequire);
			map.put("NCCOUNT", nonConformanceCount);			

			String serialNumber= getPageFactory().getOrderOperationPage().validateSerialNoTabDetails(oId,ScreenshotRequire);
			test.log(LogStatus.INFO, "Selected serial no " + serialNumber + " from Order operation Page");
			System.out.println("value of serial no:" + serialNumber);
			getPageFactory().getOrderOperationPage().clickHomeIcon(ScreenshotRequire);

			screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("elx.searchwith.NCM"),ScreenshotRequire);
			test.log(LogStatus.INFO, "*********Verification on create NC Functionality******" + screenshot);
			screenshot = getPageFactory().getAprisoCommonPage().clickCreateNCButton(ScreenshotRequire);		
			getPageFactory().getNCInfoPage().validateNCInfoPageTitle(data.get("elx.createNC"),ScreenshotRequire);
			getPageFactory().getCreateNC().verifyReasonCodesSelection(data.get("elx.reason.code"),ScreenshotRequire);
			getPageFactory().getCreateNC().selectWorkCenter(hm2[0][1],ScreenshotRequire);
			getPageFactory().getCreateNC().enterSerialNumber(serialNumber,sharedFlag,ScreenshotRequire);
			getPageFactory().getCreateNC().ClickSaveBtn(ScreenshotRequire);
			String ncID=getPageFactory().getNCListPage().validateNcDetailsOnNcListPage(serialNumber,oId,data.get("elx.loginUser"),hm2[0][1],data,ScreenshotRequire);
			test.log(LogStatus.INFO, "*********Validated new NC details successfully, new NC created ******* "+ ncID );

			driver.getWindowHandle();
			Thread.sleep(6000);
			driver2.get(url);
			driver2.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
			driver2.manage().window().maximize();                
			driver2.getWindowHandles();                        
			Thread.sleep(5000);

			((JavascriptExecutor)driver2).executeScript("window.focus();");
			pageFactory = new WebPageFactory(driver2);

			getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
			test.log(LogStatus.INFO,
					"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
			screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
			test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
			String pageTitle2 = getDriver().getCurrentUrl();
			if (pageTitle2.contains("apriso.electrolux-na")) {
				screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
			} else {
				screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
			}
			screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("RPCScreenUserName"), testData.getConfig().getProperty("password"),ScreenshotRequire);
			test.log(LogStatus.INFO, "Login successfully" );
			test.log(LogStatus.INFO, "**********Validated Login Functionality successfully**********");
			screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("RPCScreen"),ScreenshotRequire);
			test.log(LogStatus.INFO, "RPC Screen ::" );
			screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][0],ScreenshotRequire);
			screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hm2[0][1],ScreenshotRequire);
			String headerDetails = "OperationDetails_" + hm2[0][0];
			String[][] hmRepairSt = new String[1][];
			hmRepairSt = DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"), data.get("SheetName"), headerDetails,
					PlantName);

			screenshot = getPageFactory().getWorkAreaPage().clickOnLineItem(hmRepairSt[0][1],ScreenshotRequire);
			String NCID=getPageFactory().getRPCNCList().searchNcDetailsOnNcListPage(data, ncID,serialNumber,hm2[0][1],"true");
			if(NCID!=null) {
				test.log(LogStatus.INFO, "*********Validated NC Details with Serail number on repair NC page******* ");
			}else {
				test.log(LogStatus.INFO,"********NC details is not appearing in RPC list page**********");
			}
			

		}else{
			test.log(LogStatus.WARNING,"********No order available for testing**********");

		}
		}catch(Exception e1){
			test.log(LogStatus.INFO,"Error" + e1);
		}finally {
			driver2.close();
		}
	}


	@AfterMethod
	public void AfterMethodCleanUp(ITestContext testContext) {

		getDriver().manage().deleteAllCookies();
		// getDriver().close();
		// driver=null;
	}

}