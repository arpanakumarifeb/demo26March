package com.elx.nc.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.junit.Assert;
import org.testng.ITestContext;
import org.testng.annotations.*;

import com.elx.common.Common;
import com.elx.common.ExcelManager;
import com.elx.core.Screenshot;
import com.elx.core.util.CustomReport;
import com.elx.framework.base.SeleniumDriverUtil;
import com.elx.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;
import com.web.elx.pages.*;

import jxl.read.biff.BiffException;

/**
 * JCREW OMNITURE VERIFICATION class
 */
@Listeners({ CustomReport.class, Screenshot.class })
public class ElectroluxSmokeALTest extends WebTestCase {
	private SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	HashMap<String, String> map = new HashMap<String, String>();

	private Common common = new Common(driver);
	ExcelManager ex = new ExcelManager();
	ReadConfig testData = new ReadConfig();

	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ElectroluxSmokeALTest.class.getName());
	private String url = null;
	String PlantName = null;
	String ScreenshotRequire = null;
	String WantToExecuteForAllWC = null;

	@BeforeMethod
	public void initialize(ITestContext testContext) {
		driver = selenium.getDriver();
		System.out.println("driver..>" + driver);
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
		common = new Common(driver);
		common.impicitWait(10);
		testContext.setAttribute("driver", driver);
		getDriver().manage().deleteAllCookies();
		common.impicitWait(4);
		getDriver().manage().window().maximize();
		url = testContext.getCurrentXmlTest().getParameter("URL");
		PlantName = testContext.getCurrentXmlTest().getParameter("PlantName");
		ScreenshotRequire = testContext.getCurrentXmlTest().getParameter("ScreenShotRequire");
		WantToExecuteForAllWC = testContext.getCurrentXmlTest().getParameter("WantToExecuteForAllWC");
		getDriver().get(url);
		getDriver().manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
	}
	//***************************************************************************************************************************************
	// * NAME 			: ValidateReasonCodeNCFlow
	// * DESCRIPTION 	: Validate reason code in  NC Flow for 
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Nov 2018 
	//***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",testName = "ValidateReasonCodeNCFlow", description = "ValidateReasonCodeNCFlow",enabled = true, groups = {
			"", "NC", "LOCAL" })
	public void ValidateReasonCodeNCFlow(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		ElectroluxSmokeALTest DT = new ElectroluxSmokeALTest();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);

		String sharedFlag=null;
		if(SharedWCRule.length>0) {
			sharedFlag= common.validateSharedWC(hm2[0][1].trim().toLowerCase(),SharedWCRule);
		}

		String screenshot = null;
		test.log(LogStatus.INFO,"**********Validate Create NC Flow for  Functionality********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");			
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);
		String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),"", hm2[0][0],ScreenshotRequire);
		if(orderDetails!=null) {
			String [] splits=common.splitValues(orderDetails,"_");
			String oId=splits[0].trim();
			test.log(LogStatus.INFO, "Selected Order Id " + oId + " from Order Cockpit Page");
			getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateGeneralTabOrderDetails(oId,ScreenshotRequire);
			String nonConformanceCount = getPageFactory().getOrderOperationPage().validateNCCountOnOrderOperationPage(oId,ScreenshotRequire);
			map.put("NCCOUNT", nonConformanceCount);			
			String serialNumber= getPageFactory().getOrderOperationPage().validateSerialNoTabDetails(oId,ScreenshotRequire);
			test.log(LogStatus.INFO, "Selected serial no " + serialNumber + " from Order operation Page");
			System.out.println("value of serial no:" + serialNumber);
			getPageFactory().getOrderOperationPage().clickHomeIcon(ScreenshotRequire);
			screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchNCM"),ScreenshotRequire);
			test.log(LogStatus.INFO, "*********Verification on create NC Functionality******" + screenshot);
			screenshot = getPageFactory().getAprisoCommonPage().clickCreateNCButton(ScreenshotRequire);		
			getPageFactory().getNCInfoPage().validateNCInfoPageTitle(data.get("createNC"),ScreenshotRequire);
			//getPageFactory().getCreateNC().enterSerialNumber(serialNumber);
			test.log(LogStatus.INFO, "*********Select reason code******" + screenshot);
			getPageFactory().getCreateNC().verifyReasonCodesSelection(data.get("reason.code"),ScreenshotRequire);
			getPageFactory().getCreateNC().selectWorkCenter(hm2[0][1],ScreenshotRequire);
			getPageFactory().getCreateNC().enterSerialNumber(serialNumber,sharedFlag,ScreenshotRequire);
			getPageFactory().getCreateNC().ClickSaveBtn(ScreenshotRequire);
			test.log(LogStatus.INFO, "*********Validated that NC cannot be created without selecting Lowest level reason code *******" );
		}else
			test.log(LogStatus.WARNING, "*********No started order available for Testing *******" );
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateCreateNCFlow
	// * DESCRIPTION 	: Validate Create NC Flow for 
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Nov 2018 
	//***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",enabled = true, testName = "ValidateCreateNCFlow", description = "Validate Create NC Flow ",groups = {
			"", "NC", "LOCAL" })
	public void ValidateCreateNCFlow(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;
		ElectroluxSmokeALTest DT = new ElectroluxSmokeALTest();
		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);
		String sharedFlag=null;
		if(SharedWCRule.length>0) {
			sharedFlag= common.validateSharedWC(hm2[0][1].trim().toLowerCase(),SharedWCRule);
		}
		test.log(LogStatus.INFO,"**********Validate Create NC Flow for  Functionality********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO, "**********Validated Login Functionality successfully for Supervisor********");

		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");			
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);

		String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),"", hm2[0][0],ScreenshotRequire);
		if(orderDetails!=null) {
			String [] splits=common.splitValues(orderDetails,"_");
			String oId=splits[0].trim();
			test.log(LogStatus.INFO, "Selected Order Id " + oId + " from Order Cockpit Page");
			getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateGeneralTabOrderDetails(oId,ScreenshotRequire);
			String nonConformanceCount = getPageFactory().getOrderOperationPage().validateNCCountOnOrderOperationPage(oId,ScreenshotRequire);
			map.put("NCCOUNT", nonConformanceCount);			
			String serialNumber= getPageFactory().getOrderOperationPage().validateSerialNoTabDetails(oId,ScreenshotRequire);
			test.log(LogStatus.INFO, "Selected serial no " + serialNumber + " from Order operation Page");
			System.out.println("value of serial no:" + serialNumber);
			getPageFactory().getOrderOperationPage().clickHomeIcon(ScreenshotRequire);
			screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchNCM"),ScreenshotRequire);
			test.log(LogStatus.INFO, "*********Verification on create NC Functionality******" + screenshot);
			screenshot = getPageFactory().getAprisoCommonPage().clickCreateNCButton(ScreenshotRequire);		
			getPageFactory().getNCInfoPage().validateNCInfoPageTitle(data.get("createNC"),ScreenshotRequire);
			//getPageFactory().getCreateNC().enterSerialNumber(serialNumber);
			test.log(LogStatus.INFO, "*********Select reason code******" + screenshot);
			getPageFactory().getCreateNC().reasonCodesSelection(data.get("reason.code"),ScreenshotRequire);
			getPageFactory().getCreateNC().selectWorkCenter(hm2[0][1],ScreenshotRequire);
			getPageFactory().getCreateNC().enterSerialNumber(serialNumber,sharedFlag,ScreenshotRequire);
			getPageFactory().getCreateNC().ClickSaveBtn(ScreenshotRequire);


			String ncID=getPageFactory().getNCListPage().validateNcDetailsOnNcListPage(serialNumber,oId,testData.getConfig().getProperty("username"),hm2[0][1],data,ScreenshotRequire);
			test.log(LogStatus.INFO, "*********Validated new NC details successfully, new NC created: "+serialNumber+"----"+ ncID );
			test.log(LogStatus.INFO, "*********Verification on create another NC with same serial number Functionality******" + screenshot);
			screenshot = getPageFactory().getAprisoCommonPage().clickCreateNCButton(ScreenshotRequire);		
			getPageFactory().getNCInfoPage().validateNCInfoPageTitle(data.get("createNC"),ScreenshotRequire);
			//getPageFactory().getCreateNC().enterSerialNumber(serialNumber);
			test.log(LogStatus.INFO, "*********Select reason code******" + screenshot);
			getPageFactory().getCreateNC().reasonCodesSelection(data.get("reason.code"),ScreenshotRequire);
			getPageFactory().getCreateNC().selectWorkCenter(hm2[0][1],ScreenshotRequire);
			getPageFactory().getCreateNC().enterSerialNumber(serialNumber,sharedFlag,ScreenshotRequire);
			getPageFactory().getCreateNC().ClickSaveBtn(ScreenshotRequire);
			getPageFactory().getNCListPage().validateNewNCDetailsWithSameSerialNumber(serialNumber,ScreenshotRequire);
			test.log(LogStatus.INFO, "*********More than one NC has been created with same serial Number successfully*******" );
		}else
			test.log(LogStatus.WARNING, "*********No started order available for Testing *******" );
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateCancelNCFlow
	// * DESCRIPTION 	: Validate Cancel NC Flow
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Nov 2018 
	//***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",testName = "ValidateCancelNCFlow",enabled = true,description = "Validate Cancel NC Flow",groups = {
			"", "NC", "LOCAL" })
	public void ValidateCancelNCFlow(Hashtable<String, String> data) throws InterruptedException, AWTException, BiffException, IOException {
		ElectroluxSmokeALTest DT = new ElectroluxSmokeALTest();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);

		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("HeaderLineActiveStatus"),PlantName);
		
		
		String screenshot = null;
		test.log(LogStatus.INFO,"**********Validate Cancel NC Flow********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		String sharedFlag=null;
		int flag=0;
		int i=0; 
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}
			for(int p=0;p<=LineActiveStatus.length;p++) {
				if(LineActiveStatus[p][0].contains(hm2[j][0])&&LineActiveStatus[p][1].length()>1) {
					
					for (int k = 0; k < TotalWCCount; k++) {
						System.out.println("area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);
						test.log(LogStatus.INFO, "Testing started for area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);	
						if(hm2[j][k+1+WCIndexToExecute]!=null) {

							sharedFlag= common.validateSharedWC(hm2[j][k+1+WCIndexToExecute].trim().toLowerCase(),SharedWCRule);
							screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
							test.log(LogStatus.INFO, "Searched for ORD option and click");			
							getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);

							String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),"", hm2[j][i],ScreenshotRequire);
							if(orderDetails!=null) {
								String [] splits=common.splitValues(orderDetails,"_");
								String oId=splits[0].trim();
								test.log(LogStatus.INFO, "Selected Order Id " + oId + " from Order Cockpit Page");
								getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateGeneralTabOrderDetails(oId,ScreenshotRequire);
								String nonConformanceCount = getPageFactory().getOrderOperationPage().validateNCCountOnOrderOperationPage(oId,ScreenshotRequire);
								map.put("NCCOUNT", nonConformanceCount);			
								String serialNumber= getPageFactory().getOrderOperationPage().validateSerialNoTabDetails(oId,ScreenshotRequire);
								test.log(LogStatus.INFO, "Selected serial no " + serialNumber + " from Order operation Page");
								System.out.println("value of serial no:" + serialNumber);
								getPageFactory().getOrderOperationPage().clickHomeIcon(ScreenshotRequire);
								screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem("NCM",ScreenshotRequire);
								test.log(LogStatus.INFO, "*********Verification on create NC Functionality******" + screenshot);
								screenshot = getPageFactory().getAprisoCommonPage().clickCreateNCButton(ScreenshotRequire);
								getPageFactory().getNCInfoPage().validateNCInfoPageTitle(data.get("createNC"),ScreenshotRequire);

								test.log(LogStatus.INFO, "*********Select reason code******" + screenshot);
								getPageFactory().getCreateNC().reasonCodesSelection(data.get("reason.code"),ScreenshotRequire);
								getPageFactory().getCreateNC().selectWorkCenter(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
								getPageFactory().getCreateNC().enterSerialNumber(serialNumber,sharedFlag,ScreenshotRequire);
								getPageFactory().getCreateNC().ClickSaveBtn(ScreenshotRequire);
								String ncID=getPageFactory().getNCListPage().validateNcDetailsOnNcListPage(serialNumber,oId,testData.getConfig().getProperty("username"),hm2[j][k+1+WCIndexToExecute],data, ScreenshotRequire);
								test.log(LogStatus.INFO, "*********Validated new NC details successfully and new NC created ******* "+ ncID );
								map.put("NCID", ncID);
								getPageFactory().getAprisoCommonPage().clickHomeIcon(ScreenshotRequire);
								screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
								test.log(LogStatus.INFO, "Searched for ORD option and click");	
								getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);
								getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),oId,hm2[j][i],ScreenshotRequire);
								test.log(LogStatus.INFO, "Selected Order Id " + oId + " is appearing in Order cockpit page");
								getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
								int newNcCount= getPageFactory().getOrderOperationPage().validateNCTabOrderDetails(ncID,nonConformanceCount,serialNumber,oId,data.get("status.new"),ScreenshotRequire);
								test.log(LogStatus.INFO, "*****New NC Details are verified successfully on order Operation page with NC count:"+newNcCount+"  *****");
								getPageFactory().getAprisoCommonPage().clickHomeIcon(ScreenshotRequire);
								screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchNCM"),ScreenshotRequire);
								test.log(LogStatus.INFO,"********Testing Cancel NC Test Functionality**********");
								getPageFactory().getNCListPage().validateNCListPageTitle(ScreenshotRequire);
								getPageFactory().getNCListPage().validateCancelNC(map.get("NCID"),data.get("status.cancelled"),ScreenshotRequire);
								getPageFactory().getNCListPage().validateNCNumberAndStatusAfterNCClose(map.get("NCID"),ScreenshotRequire); 
								test.log(LogStatus.INFO,"********Validated Cancel NC  Functionality successfully on NC Page**********");
								test.log(LogStatus.INFO,"********Validate Cancel NC  Functionality on ORD page**********");
								getPageFactory().getAprisoCommonPage().clickHomeIcon(ScreenshotRequire);
								screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
								getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);
								getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),oId,hm2[j][i],ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateNCTabOrderDetailsAfterNCResolve(map.get("NCID"),newNcCount,map.get("SERIALNO"),oId,ScreenshotRequire);
								getPageFactory().getAprisoCommonPage().clickHomeIcon(ScreenshotRequire);
								flag=1;
							}else {
								flag=0;
								test.log(LogStatus.WARNING,"********No order available for Testing**********");
							}
						}
					}
					break;
				}
			}
		}
		if(flag>0) {
			test.log(LogStatus.INFO,"********Validated cancel NC  Functionality successfully**********");
		}else {
			test.log(LogStatus.WARNING,"******** Cancel NC Functionality not validated **********");
		}
	}

	//***************************************************************************************************************************************
	// * NAME 			: CreateAndResolveNC
	// * DESCRIPTION 	: Validate create and resolve NC Flow for 
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Nov 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata",testName = "CreateAndResolveNC", description = "Create and Resolve NC ", enabled = true, groups = {
			"", "NC", "LOCAL" })
	public void CreateAndResolveNC(Hashtable<String, String> data) throws InterruptedException, AWTException, BiffException, IOException {
		ElectroluxSmokeALTest DT = new ElectroluxSmokeALTest();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);


		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("HeaderLineActiveStatus"),PlantName);


		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);

		String screenshot = null;
		test.log(LogStatus.INFO,"**********Validate Cancel NC Flow********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");


		String sharedFlag=null;
		int flag=0;
		int i=0; 
		int WCIndexToExecute=0;
		int TotalWCCount=0;
		for (int j = 0; j < hm2.length; j++) {
			int totalWC=0;
			for(int w=0;w<hm2[j].length-1;w++) {
				if(hm2[j][w+1]!=null) {
					totalWC++;
				}
			}
			if(WantToExecuteForAllWC.equalsIgnoreCase("Yes")) {
				TotalWCCount=totalWC;
			}else {
				TotalWCCount=1;
				WCIndexToExecute=Common.generateRandomIntIntRange(0, totalWC-1);
				System.out.println("Randon Index :: " + WCIndexToExecute);
			}
			for(int p=0;p<=LineActiveStatus.length;p++) {
				if(LineActiveStatus[p][0].contains(hm2[j][0])&&LineActiveStatus[p][1].length()>1) {
					
					for (int k = 0; k < TotalWCCount; k++) {
						System.out.println("area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);
						test.log(LogStatus.INFO, "Testing started for area:: "+hm2[j][i] + " WC:: " + hm2[j][k+1+WCIndexToExecute]);	
						if(hm2[j][k+1+WCIndexToExecute]!=null) {

							sharedFlag= common.validateSharedWC(hm2[j][k+1+WCIndexToExecute].trim().toLowerCase(),SharedWCRule);
							screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
							test.log(LogStatus.INFO, "Searched for ORD option and click");			
							getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);

							String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),"", hm2[j][i],ScreenshotRequire);
							if(orderDetails!=null) {
								String [] splits=common.splitValues(orderDetails,"_");
								String oId=splits[0].trim();
								test.log(LogStatus.INFO, "Selected Order Id " + oId + " from Order Cockpit Page");
								getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateGeneralTabOrderDetails(oId,ScreenshotRequire);
								String nonConformanceCount = getPageFactory().getOrderOperationPage().validateNCCountOnOrderOperationPage(oId,ScreenshotRequire);
								map.put("NCCOUNT", nonConformanceCount);			
								String serialNumber= getPageFactory().getOrderOperationPage().validateSerialNoTabDetails(oId,ScreenshotRequire);
								test.log(LogStatus.INFO, "Selected serial no " + serialNumber + " from Order operation Page");
								System.out.println("value of serial no:" + serialNumber);
								getPageFactory().getOrderOperationPage().clickHomeIcon(ScreenshotRequire);
								screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem("NCM",ScreenshotRequire);
								test.log(LogStatus.INFO, "*********Verification on create NC Functionality******" + screenshot);
								screenshot = getPageFactory().getAprisoCommonPage().clickCreateNCButton(ScreenshotRequire);
								getPageFactory().getNCInfoPage().validateNCInfoPageTitle(data.get("createNC"),ScreenshotRequire);

								test.log(LogStatus.INFO, "*********Select reason code******" + screenshot);
								getPageFactory().getCreateNC().reasonCodesSelection(data.get("reason.code"),ScreenshotRequire);
								getPageFactory().getCreateNC().selectWorkCenter(hm2[j][k+1+WCIndexToExecute],ScreenshotRequire);
								getPageFactory().getCreateNC().enterSerialNumber(serialNumber,sharedFlag,ScreenshotRequire);
								getPageFactory().getCreateNC().ClickSaveBtn(ScreenshotRequire);
								String ncID=getPageFactory().getNCListPage().validateNcDetailsOnNcListPage(serialNumber,oId,testData.getConfig().getProperty("username"),hm2[j][k+1+WCIndexToExecute],data,ScreenshotRequire);
								test.log(LogStatus.INFO, "*********Validated new NC details successfully and new NC created ******* "+ ncID );
								map.put("NCID", ncID);
								getPageFactory().getAprisoCommonPage().clickHomeIcon(ScreenshotRequire);
								screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
								test.log(LogStatus.INFO, "Searched for ORD option and click");	
								getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);
								getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),oId,hm2[j][i],ScreenshotRequire);
								test.log(LogStatus.INFO, "Selected Order Id " + oId + " is appearing in Order cockpit page");
								getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
								int newNcCount= getPageFactory().getOrderOperationPage().validateNCTabOrderDetails(ncID,nonConformanceCount,serialNumber,oId,data.get("status.new"),ScreenshotRequire);
								test.log(LogStatus.INFO, "*****New NC Details are verified successfully on order Operation page with NC count:"+newNcCount+"  *****");
								getPageFactory().getAprisoCommonPage().clickHomeIcon(ScreenshotRequire);
								screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchNCM"),ScreenshotRequire);
								test.log(LogStatus.INFO,"********validate Resolve NC Test Functionality**********");
								getPageFactory().getNCListPage().searchAndclickNCDetailsButton(map.get("NCID"),ScreenshotRequire); 
								getPageFactory().getNCInfoPage().validateNCInfoPageTitle(data.get("NCInfo"),ScreenshotRequire);

								// will write code for NC info verification in NC info page
								getPageFactory().getNCInfoPage().clickOnResolveButton(ScreenshotRequire);
								getPageFactory().getNCListPage().validateNCListPageTitle(ScreenshotRequire);
								getPageFactory().getNCListPage().validateNCNumberAndStatusAfterNCResolve(map.get("NCID"),ScreenshotRequire); 
								test.log(LogStatus.INFO,"********Verified resolve NC Functionality successfully on NC Page**********");

								test.log(LogStatus.INFO,"********Validate resolve NC Functionality on ORD page**********");

								getPageFactory().getAprisoCommonPage().clickHomeIcon(ScreenshotRequire);
								screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
								getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);
								getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),oId,hm2[j][i],ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
								getPageFactory().getOrderOperationPage().validateNCTabOrderDetailsAfterNCResolve(map.get("NCID"),newNcCount,map.get("SERIALNO"),oId,"true");
								getPageFactory().getAprisoCommonPage().clickHomeIcon(ScreenshotRequire);
								flag=1;
							}else {
								flag=0;
								test.log(LogStatus.WARNING,"********No order available for Testing**********");
							}
						}

					}
					break;
				}
			}
		}
		if(flag>0) {
			test.log(LogStatus.INFO,"********Validated cancel NC  Functionality successfully**********");
		}else {
			test.log(LogStatus.WARNING,"******* cancel NC  Functionality not validated **********");
		}
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateNewAndStartedOrderOnOperationPage
	// * DESCRIPTION 	: Validate New And Started Order On Operation Page for 
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Nov 2018 
	//***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",enabled = true,testName = "Validate New And Started Order On OperationPage ", description = "Validate New And Started Order On Operation Page ", groups = {
			"", "NC", "LOCAL"})
	public void ValidateNewAndStartedOrderOnOperationPage(Hashtable<String, String> data) throws InterruptedException, AWTException, BiffException, IOException {
		ElectroluxSmokeALTest DT = new ElectroluxSmokeALTest();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("HeaderLineActiveStatus"),PlantName);

		String screenshot = null;
		test.log(LogStatus.INFO,"**********Validate New And Started Order On Operation Page for ********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"), testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");			
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);
		String orderIdDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("status.new"),"", hm2[0][0],ScreenshotRequire);
		if(orderIdDetails!=null) {
			String [] splits=common.splitValues(orderIdDetails,"_");
			String oId=splits[0].trim();
			test.log(LogStatus.INFO, "Selected Order Id " + oId + " from Order Cockpit Page");
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header"), PlantName);

			getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateLeftPanelOrderDetailsStarted(oId,data.get("status.new"),hm2[0][1],data.get("work.area.wc"),hm,"true");
			test.log(LogStatus.INFO,"********Validated New And Started Order On Operation Page Functionality successfully**********");
		}else {
			test.log(LogStatus.WARNING,"********No New order available for testing**********");

		}
	}
	//***************************************************************************************************************************************
	// * NAME 			: ValidateStartedAndHoldOrderOnOperationPage
	// * DESCRIPTION 	: Validate Started And Hold Order On Operation Page
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Nov 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata",enabled = true, testName = "Validate Started and Hold Order On OperationPage", description = "Validate Started and Hold Order On OperationPage ",groups = {
			"", "NC", "LOCAL"})
	public void ValidateStartedAndHoldOrderOnOperationPage(Hashtable<String, String> data) throws InterruptedException, AWTException, BiffException, IOException {
		ElectroluxSmokeALTest DT = new ElectroluxSmokeALTest();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String screenshot = null;
		test.log(LogStatus.INFO,"**********Validate Started and Hold Order On Operation Page for  Functionality********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");			
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);
		String orderIdDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),"",hm2[0][0],ScreenshotRequire);
		if(orderIdDetails!=null) {
			String [] splits=common.splitValues(orderIdDetails,"_");
			String oId=splits[0].trim();
			test.log(LogStatus.INFO, "Selected Order Id   " + oId + " from Order Cockpit Page");
			getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header"), PlantName);
			getPageFactory().getOrderOperationPage().validateLeftPanelOrderDetailsHoldAndStart(oId,data.get("orderSatusStarted"),hm2[0][1],data.get("work.area.wc"),hm,"true");
			test.log(LogStatus.INFO,"********Validated Started And Hold Order On Operation Page Functionality successfully**********");
		}else{
			test.log(LogStatus.WARNING,"********No order available for Testing**********");

		}
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateNCDetailsCreatedBySystem
	// * DESCRIPTION 	: Validate NC Details Created By System
	// * AUTHOR			: Arpana
	// * DATE 			: 17th Nov 2018 
	//***************************************************************************************************************************************

	@Test(dataProvider = "inputdata",testName = "Validate NC Details Created By System", description = "Validate NC Details Created By System",enabled = true, groups = {
			"", "NC", "LOCAL"})
	public void ValidateNCDetailsCreatedBySystem(Hashtable<String, String> data) throws InterruptedException, AWTException, BiffException, IOException {
		ElectroluxSmokeALTest DT = new ElectroluxSmokeALTest();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);
		String[][] LineActiveStatus=new String[rowCount][];						
		LineActiveStatus=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("HeaderLineActiveStatus"),PlantName);
		String screenshot = null;
		test.log(LogStatus.INFO,"**********Validate NC Details Created By System Functionality********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully" );
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		screenshot = getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchNCM"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for NCM option and click");
		getPageFactory().getNCListPage().validateNCListPageTitle(ScreenshotRequire);
		getPageFactory().getNCListPage().searchWithCreatedByAndTime(data.get("createdBy"),ScreenshotRequire);
		getPageFactory().getNCListPage().searchWithLine(hm2[0][0],ScreenshotRequire);
		int totalList= getPageFactory().getNCListPage().validateNCList(hm2[0][0],ScreenshotRequire);
		getPageFactory().getNCListPage().searchWithLine(hm2[0][1],ScreenshotRequire);
		int totalListLine2= getPageFactory().getNCListPage().validateNCList(hm2[0][1],ScreenshotRequire);
		getPageFactory().getNCListPage().searchWithLine(hm2[0][2],ScreenshotRequire);
		int totalListLine3= getPageFactory().getNCListPage().validateNCList(hm2[0][2],ScreenshotRequire);

		if(totalList==0) {
			test.log(LogStatus.FAIL,"**********ValidatedNC count is 0 for ********"+ hm2[0][1]);
		}

		if(totalListLine2==0) {
			test.log(LogStatus.FAIL,"**********Validated NC count is 0 for ********"+ hm2[0][2]);
		}
		if(totalListLine3==0) {
			test.log(LogStatus.FAIL,"**********Validated NC count is 0 for ********"+ hm2[0][3]);
		}
		test.log(LogStatus.INFO,"**********Validate NC Details Created By System Functionality successfully ********");
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateOrderHistoryFlow
	// * DESCRIPTION 	: ValidateOrderHistoryFlow 
	// * AUTHOR			: Arpana
	// * DATE 			: 30th oct 2019 
	//***************************************************************************************************************************************


	@Test(dataProvider = "inputdata",testName = "ValidateOrderHistoryFlow", description = "ValidateOrderHistoryFlow",enabled = true, groups = {
			"", "NC", "LOCAL" })
	public void ValidateOrderHistoryFlow(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		ElectroluxSmokeALTest DT = new ElectroluxSmokeALTest();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] SharedWCRule=new String[rowCount][];						
		SharedWCRule=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetSharedWC"),data.get("HeaderSharedWC"),PlantName);

		String sharedFlag=null;
		if(SharedWCRule.length>0) {
			sharedFlag= common.validateSharedWC(hm2[0][1].trim().toLowerCase(),SharedWCRule);
		}

		String screenshot = null;
		test.log(LogStatus.INFO,"**********Validate History tab Flow for  Functionality********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,
				"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("username"),testData.getConfig().getProperty("password"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Login successfully");
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");			
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);
		getPageFactory().getOrderCockPage().clickOnHistoryIcon(ScreenshotRequire);
		getPageFactory().getOrderCockPage().validateOrderCockpitHistoryPageTitle(data.get("historyPageTitle"),ScreenshotRequire);
		String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitHistoryPage("Closed", ScreenshotRequire);
		if(orderDetails!=null) {
			test.log(LogStatus.INFO, "Selected Order Id " + orderDetails + " from Order Cockpit Page");
			getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
			String GoogSchQuantity= getPageFactory().getOrderOperationPage().validateOrderDetails(orderDetails,ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateSerialNoTabDetails(orderDetails,"true");
			boolean flag=getPageFactory().getOrderOperationPage().validateSerialNoCycleDetails(GoogSchQuantity,"true");
		}else {
			Assert.assertTrue(orderDetails!=null);
			test.log(LogStatus.FAIL, "*********No closed previous day order available for testing *******" );
		}
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateClosedOrderHistoryFlow
	// * DESCRIPTION 	: ValidateClosedOrderHistoryFlow 
	// * AUTHOR			: Arpana
	// * DATE 			: 9th Dec 2019 
	//***************************************************************************************************************************************


	@Test(dataProvider = "inputdata",testName = "ValidateClosedOrderHistoryFlow", description = "ValidateClosedOrderHistoryFlow",enabled = true, groups = {
			"", "NC", "LOCAL" })
	public void ValidateClosedOrderHistoryFlow(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		ElectroluxSmokeALTest DT = new ElectroluxSmokeALTest();

		int rowCount=DT.ex.calculateRowCount(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String[][] hm2=new String[rowCount][];						
		hm2=DT.ex.readExcelTwoDimension(data.get("GlobalDataFileName"),data.get("SheetName"),data.get("Header"),PlantName);

		String screenshot = null;
		test.log(LogStatus.INFO,"**********Validate Closed Order History tab Functionality********");
		getPageFactory().getElxLogin().isWelcomePage(ScreenshotRequire);
		test.log(LogStatus.INFO,"Welcome page is displayed with 'Log In to DELMIA Apriso Portal' Link" );
		screenshot = getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
		test.log(LogStatus.INFO, "Click on 'Log In to DELMIA Apriso Portal' Link" );
		String pageTitle=getDriver().getCurrentUrl();
		if (pageTitle.contains("apriso.electrolux-na")) {
			screenshot = getPageFactory().getElxLogin().standardLogin(testData.getConfig().getProperty("ModalUsername"), testData.getConfig().getProperty("ModalPassword"),"Y",ScreenshotRequire);
		} else {
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
		}
		if(PlantName.contains("Anderson")) {
			screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("MSUserName"),testData.getConfig().getProperty("password"),ScreenshotRequire);
		}else{
			screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("MSUserNameKinston"),testData.getConfig().getProperty("password"),ScreenshotRequire);
		}
		test.log(LogStatus.INFO, "Login successfully");
		test.log(LogStatus.INFO,"**********Validated Login Functionality successfully********");
		getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem(data.get("searchwithORD"),ScreenshotRequire);
		test.log(LogStatus.INFO, "Searched for ORD option and click");			
		getPageFactory().getOrderCockPage().validateOrderCockpitPageTitle(data.get("ordTitle"),ScreenshotRequire);
		String orderIdDetails=null;
		if(PlantName.contains("Kinston")) {
			orderIdDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),"","",ScreenshotRequire);
		}else {
			orderIdDetails= getPageFactory().getOrderCockPage().searchOrderOnOrderCockpitPage(data.get("orderSatusStarted"),"","",ScreenshotRequire);
		}
		if(orderIdDetails!=null) {
			String [] splits=common.splitValues(orderIdDetails,"_");
			String oId=splits[0].trim();
			test.log(LogStatus.INFO, "Selected Order Id   " + oId + " from Order Cockpit Page");
			getPageFactory().getOrderOperationPage().validateOperationPageTitle(data.get("ordOperationTitle"),ScreenshotRequire);
			getPageFactory().getOrderOperationPage().validateOrderDetails(oId,ScreenshotRequire);
			HashMap<Integer, String> hm = new HashMap<Integer, String>();
			hm = DT.ex.readExcel(data.get("GlobalDataFileName"), data.get("SheetName"), data.get("Header"), PlantName);
			getPageFactory().getOrderOperationPage().validateLeftPanelOrderDetailsStartAndClosed(oId,data.get("orderSatusStarted"),hm,"true");
			test.log(LogStatus.INFO,"********Validated Started to closed Order On Operation Page Functionality successfully**********");
			getPageFactory().getAprisoCommonPage().clickReturnIcon(ScreenshotRequire);
			getPageFactory().getOrderCockPage().clickOnHistoryIcon(ScreenshotRequire);
			String orderDetails= getPageFactory().getOrderCockPage().searchOrderOnHistoryPage(data.get("historyPageTitle"),"Closed",oId, "true");
			if(orderDetails.contains("Closed")) {
				test.log(LogStatus.INFO, oId+ ":: order has been closed in Order history page successfully Page");
			}else {
				Assert.assertTrue(orderDetails!=null);
				test.log(LogStatus.FAIL, "*********No closed order available  *******" );
			}
		}else{
			test.log(LogStatus.WARNING,"********No order available for Testing**********");

		}
	}





	@AfterMethod
	public void AfterMethodCleanUp(ITestContext testContext)
	{

		getDriver().manage().deleteAllCookies();
		//getDriver().close();
		//driver=null;
	}

}
